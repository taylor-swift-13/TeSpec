

int add_two(int a, int b)
/*@ requires  -2147483648 <= a + b; a + b <= 2147483647; ensures return == a + b; @*/
{
    return a + b;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: {  add_two((-2147483647 - 1), 0); return 0; }
case 1: {  add_two((-2147483647 - 1), 401); return 0; }
case 2: {  add_two((-2147483647 - 1), 2147483647); return 0; }
case 3: {  add_two(-2147483647, 399); return 0; }
case 4: {  add_two(-2147483647, 2147483646); return 0; }
case 5: {  add_two(-2050622355, 114559393); return 0; }
case 6: {  add_two(-1704322025, -385745401); return 0; }
case 7: {  add_two(-1639313221, -224889489); return 0; }
case 8: {  add_two(-1508665636, -117367611); return 0; }
case 9: {  add_two(-1489931730, 760812310); return 0; }
case 10: {  add_two(-1424438364, -578059497); return 0; }
case 11: {  add_two(-1372959571, -749478676); return 0; }
case 12: {  add_two(-1334221323, -350540376); return 0; }
case 13: {  add_two(-1324309362, -168916292); return 0; }
case 14: {  add_two(-1284518892, -206899815); return 0; }
case 15: {  add_two(-1254340058, 1234136023); return 0; }
case 16: {  add_two(-1198357268, -594437444); return 0; }
case 17: {  add_two(-1196594033, 1638135692); return 0; }
case 18: {  add_two(-1182778868, 384909148); return 0; }
case 19: {  add_two(-1136420893, 1362524750); return 0; }
case 20: {  add_two(-1088683489, -208739429); return 0; }
case 21: {  add_two(-1078453730, -899583184); return 0; }
case 22: {  add_two(-943452480, -472078869); return 0; }
case 23: {  add_two(-932697150, -548542552); return 0; }
case 24: {  add_two(-882356487, 223406556); return 0; }
case 25: {  add_two(-771270019, -724675038); return 0; }
case 26: {  add_two(-739633975, -1303128720); return 0; }
case 27: {  add_two(-653564425, -476090976); return 0; }
case 28: {  add_two(-639629728, 1943264736); return 0; }
case 29: {  add_two(-595887025, 445292680); return 0; }
case 30: {  add_two(-590014282, -778282331); return 0; }
case 31: {  add_two(-579500865, 1628019954); return 0; }
case 32: {  add_two(-539259348, -1301003036); return 0; }
case 33: {  add_two(-527930645, -1436904439); return 0; }
case 34: {  add_two(-513319358, -610261274); return 0; }
case 35: {  add_two(-506156122, 127086514); return 0; }
case 36: {  add_two(-442817132, 925076251); return 0; }
case 37: {  add_two(-422928039, 1193296589); return 0; }
case 38: {  add_two(-419372900, -91711148); return 0; }
case 39: {  add_two(-415021520, -1526126834); return 0; }
case 40: {  add_two(-323917355, -19994936); return 0; }
case 41: {  add_two(-295441907, -448650161); return 0; }
case 42: {  add_two(-256237400, -436942621); return 0; }
case 43: {  add_two(-254728046, -1766133864); return 0; }
case 44: {  add_two(-239065941, -1420082841); return 0; }
case 45: {  add_two(-200547056, -744990657); return 0; }
case 46: {  add_two(-184254817, -918186301); return 0; }
case 47: {  add_two(-121626301, -208350282); return 0; }
case 48: {  add_two(-116904581, -1627248033); return 0; }
case 49: {  add_two(-107942484, -106392811); return 0; }
case 50: {  add_two(-88691047, -273613665); return 0; }
case 51: {  add_two(-84499789, -32313518); return 0; }
case 52: {  add_two(-69631889, -502702748); return 0; }
case 53: {  add_two(-16074954, 1083878576); return 0; }
case 54: {  add_two(-400, 2); return 0; }
case 55: {  add_two(-400, 1600); return 0; }
case 56: {  add_two(-100, -10); return 0; }
case 57: {  add_two(-100, 100); return 0; }
case 58: {  add_two(-100, 2100); return 0; }
case 59: {  add_two(-10, 1); return 0; }
case 60: {  add_two(-10, 800); return 0; }
case 61: {  add_two(-2, -400); return 0; }
case 62: {  add_two(-2, 10); return 0; }
case 63: {  add_two(-2, 2004); return 0; }
case 64: {  add_two(-1, -2); return 0; }
case 65: {  add_two(-1, 400); return 0; }
case 66: {  add_two(-1, 2147483646); return 0; }
case 67: {  add_two(0, 0); return 0; }
case 68: {  add_two(0, 800); return 0; }
case 69: {  add_two(1, (-2147483647 - 1)); return 0; }
case 70: {  add_two(1, 2); return 0; }
case 71: {  add_two(1, 1600); return 0; }
case 72: {  add_two(2, -100); return 0; }
case 73: {  add_two(2, 10); return 0; }
case 74: {  add_two(2, 2004); return 0; }
case 75: {  add_two(4, 0); return 0; }
case 76: {  add_two(4, 401); return 0; }
case 77: {  add_two(9, -2147483647); return 0; }
case 78: {  add_two(9, 9); return 0; }
case 79: {  add_two(9, 2000); return 0; }
case 80: {  add_two(10, -2); return 0; }
case 81: {  add_two(10, 400); return 0; }
case 82: {  add_two(100, (-2147483647 - 1)); return 0; }
case 83: {  add_two(100, 2); return 0; }
case 84: {  add_two(100, 1900); return 0; }
case 85: {  add_two(399, -10); return 0; }
case 86: {  add_two(399, 100); return 0; }
case 87: {  add_two(399, 2400); return 0; }
case 88: {  add_two(400, 1); return 0; }
case 89: {  add_two(400, 800); return 0; }
case 90: {  add_two(401, -100); return 0; }
case 91: {  add_two(401, 10); return 0; }
case 92: {  add_two(401, 2004); return 0; }
case 93: {  add_two(800, -1); return 0; }
case 94: {  add_two(800, 401); return 0; }
case 95: {  add_two(1600, -2147483647); return 0; }
case 96: {  add_two(1600, 4); return 0; }
case 97: {  add_two(1600, 2000); return 0; }
case 98: {  add_two(1900, -2); return 0; }
case 99: {  add_two(1900, 399); return 0; }
case 100: {  add_two(2000, (-2147483647 - 1)); return 0; }
case 101: {  add_two(2000, 2); return 0; }
case 102: {  add_two(2000, 1600); return 0; }
case 103: {  add_two(2004, -10); return 0; }
case 104: {  add_two(2004, 100); return 0; }
case 105: {  add_two(2004, 2100); return 0; }
case 106: {  add_two(2100, 1); return 0; }
case 107: {  add_two(2100, 800); return 0; }
case 108: {  add_two(2400, -400); return 0; }
case 109: {  add_two(2400, 10); return 0; }
case 110: {  add_two(2400, 2004); return 0; }
case 111: {  add_two(95870864, -111984043); return 0; }
case 112: {  add_two(113621998, 772859443); return 0; }
case 113: {  add_two(123091116, -340361175); return 0; }
case 114: {  add_two(374059776, -662961268); return 0; }
case 115: {  add_two(445927443, 34833827); return 0; }
case 116: {  add_two(473873328, -113257487); return 0; }
case 117: {  add_two(594602771, -1306193384); return 0; }
case 118: {  add_two(773647602, 916477127); return 0; }
case 119: {  add_two(933450800, -840986556); return 0; }
case 120: {  add_two(1014105484, -870926028); return 0; }
case 121: {  add_two(1114208779, 394273271); return 0; }
case 122: {  add_two(1440229869, -1364673653); return 0; }
case 123: {  add_two(1641115217, -1831128050); return 0; }
case 124: {  add_two(1688080288, -1470355435); return 0; }
case 125: {  add_two(1746369206, 191871627); return 0; }
case 126: {  add_two(2147483646, -1); return 0; }
case 127: {  add_two(2147483647, 0); return 0; }
default: return 13; } }
