unsigned int between (unsigned int p, unsigned int q)
/* --BEGIN-- */
  /*@
    requires p <= q;
    ensures return >= p;
            return <= q;
  @*/
/* --END-- */
{
  return q;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: {  between(0U, 0U); return 0; }
case 1: {  between(0U, 4U); return 0; }
case 2: {  between(0U, 100U); return 0; }
case 3: {  between(0U, 401U); return 0; }
case 4: {  between(0U, 1900U); return 0; }
case 5: {  between(0U, 2100U); return 0; }
case 6: {  between(0U, 4294967295U); return 0; }
case 7: {  between(1U, 4U); return 0; }
case 8: {  between(1U, 100U); return 0; }
case 9: {  between(1U, 401U); return 0; }
case 10: {  between(1U, 1900U); return 0; }
case 11: {  between(1U, 2100U); return 0; }
case 12: {  between(1U, 4294967295U); return 0; }
case 13: {  between(2U, 9U); return 0; }
case 14: {  between(2U, 399U); return 0; }
case 15: {  between(2U, 800U); return 0; }
case 16: {  between(2U, 2000U); return 0; }
case 17: {  between(2U, 2400U); return 0; }
case 18: {  between(4U, 4U); return 0; }
case 19: {  between(4U, 100U); return 0; }
case 20: {  between(4U, 401U); return 0; }
case 21: {  between(4U, 1900U); return 0; }
case 22: {  between(4U, 2100U); return 0; }
case 23: {  between(4U, 4294967295U); return 0; }
case 24: {  between(9U, 100U); return 0; }
case 25: {  between(9U, 401U); return 0; }
case 26: {  between(9U, 1900U); return 0; }
case 27: {  between(9U, 2100U); return 0; }
case 28: {  between(9U, 4294967295U); return 0; }
case 29: {  between(10U, 399U); return 0; }
case 30: {  between(10U, 800U); return 0; }
case 31: {  between(10U, 2000U); return 0; }
case 32: {  between(10U, 2400U); return 0; }
case 33: {  between(100U, 100U); return 0; }
case 34: {  between(100U, 401U); return 0; }
case 35: {  between(100U, 1900U); return 0; }
case 36: {  between(100U, 2100U); return 0; }
case 37: {  between(100U, 4294967295U); return 0; }
case 38: {  between(191U, 3031U); return 0; }
case 39: {  between(241U, 2536U); return 0; }
case 40: {  between(320U, 1780U); return 0; }
case 41: {  between(399U, 401U); return 0; }
case 42: {  between(399U, 1900U); return 0; }
case 43: {  between(399U, 2100U); return 0; }
case 44: {  between(399U, 4294967295U); return 0; }
case 45: {  between(400U, 800U); return 0; }
case 46: {  between(400U, 2000U); return 0; }
case 47: {  between(400U, 2400U); return 0; }
case 48: {  between(401U, 401U); return 0; }
case 49: {  between(401U, 1900U); return 0; }
case 50: {  between(401U, 2100U); return 0; }
case 51: {  between(401U, 4294967295U); return 0; }
case 52: {  between(489U, 3465U); return 0; }
case 53: {  between(521U, 537U); return 0; }
case 54: {  between(571U, 906U); return 0; }
case 55: {  between(630U, 3393U); return 0; }
case 56: {  between(665U, 3124U); return 0; }
case 57: {  between(737U, 2690U); return 0; }
case 58: {  between(800U, 1900U); return 0; }
case 59: {  between(800U, 2100U); return 0; }
case 60: {  between(800U, 4294967295U); return 0; }
case 61: {  between(845U, 3360U); return 0; }
case 62: {  between(969U, 3667U); return 0; }
case 63: {  between(982U, 2550U); return 0; }
case 64: {  between(994U, 2046U); return 0; }
case 65: {  between(1017U, 2686U); return 0; }
case 66: {  between(1045U, 1919U); return 0; }
case 67: {  between(1218U, 3872U); return 0; }
case 68: {  between(1379U, 2993U); return 0; }
case 69: {  between(1477U, 2666U); return 0; }
case 70: {  between(1551U, 3427U); return 0; }
case 71: {  between(1570U, 3773U); return 0; }
case 72: {  between(1600U, 2000U); return 0; }
case 73: {  between(1600U, 2400U); return 0; }
case 74: {  between(1645U, 3701U); return 0; }
case 75: {  between(1696U, 3520U); return 0; }
case 76: {  between(1810U, 2962U); return 0; }
case 77: {  between(1900U, 1900U); return 0; }
case 78: {  between(1900U, 2100U); return 0; }
case 79: {  between(1900U, 4294967295U); return 0; }
case 80: {  between(2000U, 2100U); return 0; }
case 81: {  between(2000U, 4294967295U); return 0; }
case 82: {  between(2004U, 2400U); return 0; }
case 83: {  between(2019U, 3697U); return 0; }
case 84: {  between(2039U, 2380U); return 0; }
case 85: {  between(2058U, 3032U); return 0; }
case 86: {  between(2100U, 2100U); return 0; }
case 87: {  between(2100U, 4294967295U); return 0; }
case 88: {  between(2317U, 3049U); return 0; }
case 89: {  between(2400U, 4294967295U); return 0; }
case 90: {  between(2624U, 2713U); return 0; }
case 91: {  between(3296U, 3921U); return 0; }
case 92: {  between(3478U, 4057U); return 0; }
case 93: {  between(3890U, 3893U); return 0; }
case 94: {  between(3934U, 4034U); return 0; }
case 95: {  between(62067097U, 1578327848U); return 0; }
case 96: {  between(96861293U, 2262043041U); return 0; }
case 97: {  between(213638651U, 989409410U); return 0; }
case 98: {  between(347962184U, 942147306U); return 0; }
case 99: {  between(657551918U, 2908295958U); return 0; }
case 100: {  between(696311059U, 2045703385U); return 0; }
case 101: {  between(701188854U, 1078201182U); return 0; }
case 102: {  between(893143590U, 3381619671U); return 0; }
case 103: {  between(950889615U, 3785619340U); return 0; }
case 104: {  between(964704780U, 2532392796U); return 0; }
case 105: {  between(1011062755U, 3510008398U); return 0; }
case 106: {  between(1204031168U, 1675404779U); return 0; }
case 107: {  between(1265127161U, 2370890204U); return 0; }
case 108: {  between(1493919223U, 1671392672U); return 0; }
case 109: {  between(1507853920U, 4090748384U); return 0; }
case 110: {  between(1551596623U, 2592776328U); return 0; }
case 111: {  between(1567982783U, 3775503602U); return 0; }
case 112: {  between(1641327526U, 2274570162U); return 0; }
case 113: {  between(1704666516U, 3072559899U); return 0; }
case 114: {  between(1724555609U, 3340780237U); return 0; }
case 115: {  between(2131408694U, 3231362224U); return 0; }
case 116: {  between(2261105646U, 2920343091U); return 0; }
case 117: {  between(2343478595U, 4055786418U); return 0; }
case 118: {  between(2499550386U, 3968710165U); return 0; }
case 119: {  between(2552338144U, 2892458620U); return 0; }
case 120: {  between(2600694561U, 3113572629U); return 0; }
case 121: {  between(2810773368U, 2963125845U); return 0; }
case 122: {  between(2921131250U, 3063960775U); return 0; }
case 123: {  between(2997944494U, 4281034965U); return 0; }
case 124: {  between(3098730350U, 3761397854U); return 0; }
case 125: {  between(3237887411U, 3988897054U); return 0; }
case 126: {  between(3989018947U, 4237298253U); return 0; }
case 127: {  between(4294967295U, 4294967295U); return 0; }
default: return 13; } }
