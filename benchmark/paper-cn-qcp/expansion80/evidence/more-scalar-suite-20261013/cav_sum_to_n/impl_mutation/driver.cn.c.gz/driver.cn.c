

int sum_to_n(int n)
/*@ requires 0 <= n; -2147483648 <= n * (n + 1) / 2; n * (n + 1) / 2 <= 2147483647; ensures return == n * (n + 1) / 2; @*/
{
    int i;
    int ret = 0;

    for (i = 1; i <= n; ++i) {
        ret += i - 1;
    }

    return ret;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: {  sum_to_n(0); return 0; }
case 1: {  sum_to_n(1); return 0; }
case 2: {  sum_to_n(2); return 0; }
case 3: {  sum_to_n(4); return 0; }
case 4: {  sum_to_n(9); return 0; }
case 5: {  sum_to_n(10); return 0; }
case 6: {  sum_to_n(71); return 0; }
case 7: {  sum_to_n(100); return 0; }
case 8: {  sum_to_n(153); return 0; }
case 9: {  sum_to_n(207); return 0; }
case 10: {  sum_to_n(209); return 0; }
case 11: {  sum_to_n(318); return 0; }
case 12: {  sum_to_n(320); return 0; }
case 13: {  sum_to_n(376); return 0; }
case 14: {  sum_to_n(377); return 0; }
case 15: {  sum_to_n(399); return 0; }
case 16: {  sum_to_n(400); return 0; }
case 17: {  sum_to_n(401); return 0; }
case 18: {  sum_to_n(556); return 0; }
case 19: {  sum_to_n(575); return 0; }
case 20: {  sum_to_n(582); return 0; }
case 21: {  sum_to_n(673); return 0; }
case 22: {  sum_to_n(800); return 0; }
case 23: {  sum_to_n(855); return 0; }
case 24: {  sum_to_n(969); return 0; }
case 25: {  sum_to_n(1017); return 0; }
case 26: {  sum_to_n(1056); return 0; }
case 27: {  sum_to_n(1140); return 0; }
case 28: {  sum_to_n(1185); return 0; }
case 29: {  sum_to_n(1213); return 0; }
case 30: {  sum_to_n(1254); return 0; }
case 31: {  sum_to_n(1357); return 0; }
case 32: {  sum_to_n(1387); return 0; }
case 33: {  sum_to_n(1403); return 0; }
case 34: {  sum_to_n(1477); return 0; }
case 35: {  sum_to_n(1570); return 0; }
case 36: {  sum_to_n(1584); return 0; }
case 37: {  sum_to_n(1600); return 0; }
case 38: {  sum_to_n(1610); return 0; }
case 39: {  sum_to_n(1614); return 0; }
case 40: {  sum_to_n(1671); return 0; }
case 41: {  sum_to_n(1784); return 0; }
case 42: {  sum_to_n(1876); return 0; }
case 43: {  sum_to_n(1888); return 0; }
case 44: {  sum_to_n(1900); return 0; }
case 45: {  sum_to_n(1928); return 0; }
case 46: {  sum_to_n(1941); return 0; }
case 47: {  sum_to_n(2000); return 0; }
case 48: {  sum_to_n(2004); return 0; }
case 49: {  sum_to_n(2100); return 0; }
case 50: {  sum_to_n(2194); return 0; }
case 51: {  sum_to_n(2245); return 0; }
case 52: {  sum_to_n(2400); return 0; }
case 53: {  sum_to_n(2413); return 0; }
case 54: {  sum_to_n(2506); return 0; }
case 55: {  sum_to_n(2648); return 0; }
case 56: {  sum_to_n(2684); return 0; }
case 57: {  sum_to_n(2780); return 0; }
case 58: {  sum_to_n(2831); return 0; }
case 59: {  sum_to_n(2952); return 0; }
case 60: {  sum_to_n(2962); return 0; }
case 61: {  sum_to_n(3045); return 0; }
case 62: {  sum_to_n(3240); return 0; }
case 63: {  sum_to_n(3251); return 0; }
case 64: {  sum_to_n(3399); return 0; }
case 65: {  sum_to_n(3532); return 0; }
case 66: {  sum_to_n(3694); return 0; }
case 67: {  sum_to_n(3698); return 0; }
case 68: {  sum_to_n(3701); return 0; }
case 69: {  sum_to_n(3775); return 0; }
case 70: {  sum_to_n(3879); return 0; }
case 71: {  sum_to_n(3890); return 0; }
case 72: {  sum_to_n(3963); return 0; }
case 73: {  sum_to_n(6119); return 0; }
case 74: {  sum_to_n(6999); return 0; }
case 75: {  sum_to_n(9654); return 0; }
case 76: {  sum_to_n(11619); return 0; }
case 77: {  sum_to_n(12711); return 0; }
case 78: {  sum_to_n(13431); return 0; }
case 79: {  sum_to_n(18529); return 0; }
case 80: {  sum_to_n(19074); return 0; }
case 81: {  sum_to_n(20334); return 0; }
case 82: {  sum_to_n(25674); return 0; }
case 83: {  sum_to_n(26335); return 0; }
case 84: {  sum_to_n(27256); return 0; }
case 85: {  sum_to_n(28488); return 0; }
case 86: {  sum_to_n(28965); return 0; }
case 87: {  sum_to_n(28997); return 0; }
case 88: {  sum_to_n(29396); return 0; }
case 89: {  sum_to_n(30338); return 0; }
case 90: {  sum_to_n(30855); return 0; }
case 91: {  sum_to_n(31992); return 0; }
case 92: {  sum_to_n(32758); return 0; }
case 93: {  sum_to_n(34270); return 0; }
case 94: {  sum_to_n(36368); return 0; }
case 95: {  sum_to_n(36744); return 0; }
case 96: {  sum_to_n(36939); return 0; }
case 97: {  sum_to_n(37511); return 0; }
case 98: {  sum_to_n(38872); return 0; }
case 99: {  sum_to_n(42663); return 0; }
case 100: {  sum_to_n(42964); return 0; }
case 101: {  sum_to_n(42979); return 0; }
case 102: {  sum_to_n(42981); return 0; }
case 103: {  sum_to_n(46965); return 0; }
case 104: {  sum_to_n(49079); return 0; }
case 105: {  sum_to_n(50194); return 0; }
case 106: {  sum_to_n(51129); return 0; }
case 107: {  sum_to_n(51330); return 0; }
case 108: {  sum_to_n(52870); return 0; }
case 109: {  sum_to_n(54698); return 0; }
case 110: {  sum_to_n(54881); return 0; }
case 111: {  sum_to_n(55149); return 0; }
case 112: {  sum_to_n(55872); return 0; }
case 113: {  sum_to_n(58240); return 0; }
case 114: {  sum_to_n(58672); return 0; }
case 115: {  sum_to_n(58715); return 0; }
case 116: {  sum_to_n(58770); return 0; }
case 117: {  sum_to_n(59917); return 0; }
case 118: {  sum_to_n(60035); return 0; }
case 119: {  sum_to_n(60381); return 0; }
case 120: {  sum_to_n(60917); return 0; }
case 121: {  sum_to_n(61609); return 0; }
case 122: {  sum_to_n(61824); return 0; }
case 123: {  sum_to_n(62289); return 0; }
case 124: {  sum_to_n(62802); return 0; }
case 125: {  sum_to_n(64148); return 0; }
case 126: {  sum_to_n(65534); return 0; }
case 127: {  sum_to_n(65535); return 0; }
default: return 13; } }
