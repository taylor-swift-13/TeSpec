
int example(int x, int y) 
/*@ requires x < 50; ensures (x == y && return == 0) || (x != y && return == 0); @*/
{
  

  
  return x == y;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: {  example((-2147483647 - 1), (-2147483647 - 1)); return 0; }
case 1: {  example((-2147483647 - 1), -1); return 0; }
case 2: {  example((-2147483647 - 1), 10); return 0; }
case 3: {  example((-2147483647 - 1), 1600); return 0; }
case 4: {  example((-2147483647 - 1), 2147483646); return 0; }
case 5: {  example(-2147483647, -10); return 0; }
case 6: {  example(-2147483647, 9); return 0; }
case 7: {  example(-2147483647, 800); return 0; }
case 8: {  example(-2147483647, 2400); return 0; }
case 9: {  example(-2110186329, -221699472); return 0; }
case 10: {  example(-2060693665, -1614077301); return 0; }
case 11: {  example(-2037664569, -340361175); return 0; }
case 12: {  example(-2006707177, -226780370); return 0; }
case 13: {  example(-1949621355, 1841413406); return 0; }
case 14: {  example(-1946947053, -1549562209); return 0; }
case 15: {  example(-1855325276, -1265211869); return 0; }
case 16: {  example(-1821178850, -1874312103); return 0; }
case 17: {  example(-1798817410, -1816894818); return 0; }
case 18: {  example(-1794195815, -943452480); return 0; }
case 19: {  example(-1702420285, -146002800); return 0; }
case 20: {  example(-1692789737, 1125768781); return 0; }
case 21: {  example(-1552493730, -771270019); return 0; }
case 22: {  example(-1540296870, -2038743611); return 0; }
case 23: {  example(-1511004088, 806008623); return 0; }
case 24: {  example(-1447658122, -84499789); return 0; }
case 25: {  example(-1424438364, -578059497); return 0; }
case 26: {  example(-1357943129, -310226319); return 0; }
case 27: {  example(-1324309362, -740083940); return 0; }
case 28: {  example(-1306193384, -1157336630); return 0; }
case 29: {  example(-1284518892, -206899815); return 0; }
case 30: {  example(-1271326959, -539259348); return 0; }
case 31: {  example(-1254340058, -1163663849); return 0; }
case 32: {  example(-1213984678, -882356487); return 0; }
case 33: {  example(-1212037344, -1198357268); return 0; }
case 34: {  example(-1197286771, -1698718698); return 0; }
case 35: {  example(-1184215428, 1055493086); return 0; }
case 36: {  example(-1153350431, -1980710355); return 0; }
case 37: {  example(-1136564614, -1707355839); return 0; }
case 38: {  example(-1136420893, -629523276); return 0; }
case 39: {  example(-1129535667, -1831128050); return 0; }
case 40: {  example(-1115647780, 701236369); return 0; }
case 41: {  example(-1075817423, 1101037346); return 0; }
case 42: {  example(-1074058734, 429543933); return 0; }
case 43: {  example(-983082501, -817611124); return 0; }
case 44: {  example(-873709127, -1979372692); return 0; }
case 45: {  example(-833421548, -2103008460); return 0; }
case 46: {  example(-739633975, 1825835629); return 0; }
case 47: {  example(-724675038, 1292042063); return 0; }
case 48: {  example(-723540126, 1193296589); return 0; }
case 49: {  example(-717471385, -1291849024); return 0; }
case 50: {  example(-689467813, 261658437); return 0; }
case 51: {  example(-681620970, 1003718877); return 0; }
case 52: {  example(-675700990, 265588704); return 0; }
case 53: {  example(-662961268, -151324929); return 0; }
case 54: {  example(-599425080, 617865469); return 0; }
case 55: {  example(-594437444, 594602771); return 0; }
case 56: {  example(-517820055, -1906908972); return 0; }
case 57: {  example(-442817132, -355125032); return 0; }
case 58: {  example(-385745401, -422928039); return 0; }
case 59: {  example(-365177303, -1918129191); return 0; }
case 60: {  example(-360724065, -569155800); return 0; }
case 61: {  example(-239065941, -1420082841); return 0; }
case 62: {  example(-210343047, -472078869); return 0; }
case 63: {  example(-184254817, -918186301); return 0; }
case 64: {  example(-184096502, -113257487); return 0; }
case 65: {  example(-180236360, -448650161); return 0; }
case 66: {  example(-168262940, -1522440577); return 0; }
case 67: {  example(-121626301, -208350282); return 0; }
case 68: {  example(-106392811, -295441907); return 0; }
case 69: {  example(-89557789, 2081350927); return 0; }
case 70: {  example(-69631889, 616164628); return 0; }
case 71: {  example(-45479320, 977826320); return 0; }
case 72: {  example(-32313518, 1841535299); return 0; }
case 73: {  example(-400, -100); return 0; }
case 74: {  example(-400, 2); return 0; }
case 75: {  example(-400, 400); return 0; }
case 76: {  example(-400, 2100); return 0; }
case 77: {  example(-100, -400); return 0; }
case 78: {  example(-100, 1); return 0; }
case 79: {  example(-100, 399); return 0; }
case 80: {  example(-100, 2000); return 0; }
case 81: {  example(-10, (-2147483647 - 1)); return 0; }
case 82: {  example(-10, 0); return 0; }
case 83: {  example(-10, 100); return 0; }
case 84: {  example(-10, 1900); return 0; }
case 85: {  example(-10, 2147483647); return 0; }
case 86: {  example(-2, -2); return 0; }
case 87: {  example(-2, 10); return 0; }
case 88: {  example(-2, 1600); return 0; }
case 89: {  example(-2, 2147483646); return 0; }
case 90: {  example(-1, -10); return 0; }
case 91: {  example(-1, 4); return 0; }
case 92: {  example(-1, 401); return 0; }
case 93: {  example(-1, 2400); return 0; }
case 94: {  example(0, -100); return 0; }
case 95: {  example(0, 2); return 0; }
case 96: {  example(0, 400); return 0; }
case 97: {  example(0, 2004); return 0; }
case 98: {  example(1, -2147483647); return 0; }
case 99: {  example(1, 1); return 0; }
case 100: {  example(1, 399); return 0; }
case 101: {  example(1, 2000); return 0; }
case 102: {  example(2, (-2147483647 - 1)); return 0; }
case 103: {  example(2, -1); return 0; }
case 104: {  example(2, 10); return 0; }
case 105: {  example(2, 1900); return 0; }
case 106: {  example(2, 2147483647); return 0; }
case 107: {  example(4, -2); return 0; }
case 108: {  example(4, 9); return 0; }
case 109: {  example(4, 800); return 0; }
case 110: {  example(4, 2147483646); return 0; }
case 111: {  example(9, -10); return 0; }
case 112: {  example(9, 4); return 0; }
case 113: {  example(9, 401); return 0; }
case 114: {  example(9, 2100); return 0; }
case 115: {  example(10, -400); return 0; }
case 116: {  example(10, 2); return 0; }
case 117: {  example(10, 400); return 0; }
case 118: {  example(10, 2004); return 0; }
case 119: {  example(48, -2147483647); return 0; }
case 120: {  example(48, 0); return 0; }
case 121: {  example(48, 100); return 0; }
case 122: {  example(48, 2000); return 0; }
case 123: {  example(49, (-2147483647 - 1)); return 0; }
case 124: {  example(49, -1); return 0; }
case 125: {  example(49, 10); return 0; }
case 126: {  example(49, 1600); return 0; }
case 127: {  example(49, 2147483647); return 0; }
default: return 13; } }
