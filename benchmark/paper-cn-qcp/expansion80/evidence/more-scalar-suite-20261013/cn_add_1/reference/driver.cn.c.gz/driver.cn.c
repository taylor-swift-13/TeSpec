int add(int x, int y)
/* --BEGIN-- */
/*@ requires let Sum = x + y;
             -2147483648 <= Sum; Sum <= 2147483647;
    ensures return == Sum;
@*/
/* --END-- */
{
  return x+y;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: {  add((-2147483647 - 1), 0); return 0; }
case 1: {  add((-2147483647 - 1), 401); return 0; }
case 2: {  add((-2147483647 - 1), 2147483647); return 0; }
case 3: {  add(-2147483647, 399); return 0; }
case 4: {  add(-2147483647, 2147483646); return 0; }
case 5: {  add(-2050622355, 114559393); return 0; }
case 6: {  add(-1704322025, -385745401); return 0; }
case 7: {  add(-1639313221, -224889489); return 0; }
case 8: {  add(-1508665636, -117367611); return 0; }
case 9: {  add(-1489931730, 760812310); return 0; }
case 10: {  add(-1424438364, -578059497); return 0; }
case 11: {  add(-1372959571, -749478676); return 0; }
case 12: {  add(-1334221323, -350540376); return 0; }
case 13: {  add(-1324309362, -168916292); return 0; }
case 14: {  add(-1284518892, -206899815); return 0; }
case 15: {  add(-1254340058, 1234136023); return 0; }
case 16: {  add(-1198357268, -594437444); return 0; }
case 17: {  add(-1196594033, 1638135692); return 0; }
case 18: {  add(-1182778868, 384909148); return 0; }
case 19: {  add(-1136420893, 1362524750); return 0; }
case 20: {  add(-1088683489, -208739429); return 0; }
case 21: {  add(-1078453730, -899583184); return 0; }
case 22: {  add(-943452480, -472078869); return 0; }
case 23: {  add(-932697150, -548542552); return 0; }
case 24: {  add(-882356487, 223406556); return 0; }
case 25: {  add(-771270019, -724675038); return 0; }
case 26: {  add(-739633975, -1303128720); return 0; }
case 27: {  add(-653564425, -476090976); return 0; }
case 28: {  add(-639629728, 1943264736); return 0; }
case 29: {  add(-595887025, 445292680); return 0; }
case 30: {  add(-590014282, -778282331); return 0; }
case 31: {  add(-579500865, 1628019954); return 0; }
case 32: {  add(-539259348, -1301003036); return 0; }
case 33: {  add(-527930645, -1436904439); return 0; }
case 34: {  add(-513319358, -610261274); return 0; }
case 35: {  add(-506156122, 127086514); return 0; }
case 36: {  add(-442817132, 925076251); return 0; }
case 37: {  add(-422928039, 1193296589); return 0; }
case 38: {  add(-419372900, -91711148); return 0; }
case 39: {  add(-415021520, -1526126834); return 0; }
case 40: {  add(-323917355, -19994936); return 0; }
case 41: {  add(-295441907, -448650161); return 0; }
case 42: {  add(-256237400, -436942621); return 0; }
case 43: {  add(-254728046, -1766133864); return 0; }
case 44: {  add(-239065941, -1420082841); return 0; }
case 45: {  add(-200547056, -744990657); return 0; }
case 46: {  add(-184254817, -918186301); return 0; }
case 47: {  add(-121626301, -208350282); return 0; }
case 48: {  add(-116904581, -1627248033); return 0; }
case 49: {  add(-107942484, -106392811); return 0; }
case 50: {  add(-88691047, -273613665); return 0; }
case 51: {  add(-84499789, -32313518); return 0; }
case 52: {  add(-69631889, -502702748); return 0; }
case 53: {  add(-16074954, 1083878576); return 0; }
case 54: {  add(-400, 2); return 0; }
case 55: {  add(-400, 1600); return 0; }
case 56: {  add(-100, -10); return 0; }
case 57: {  add(-100, 100); return 0; }
case 58: {  add(-100, 2100); return 0; }
case 59: {  add(-10, 1); return 0; }
case 60: {  add(-10, 800); return 0; }
case 61: {  add(-2, -400); return 0; }
case 62: {  add(-2, 10); return 0; }
case 63: {  add(-2, 2004); return 0; }
case 64: {  add(-1, -2); return 0; }
case 65: {  add(-1, 400); return 0; }
case 66: {  add(-1, 2147483646); return 0; }
case 67: {  add(0, 0); return 0; }
case 68: {  add(0, 800); return 0; }
case 69: {  add(1, (-2147483647 - 1)); return 0; }
case 70: {  add(1, 2); return 0; }
case 71: {  add(1, 1600); return 0; }
case 72: {  add(2, -100); return 0; }
case 73: {  add(2, 10); return 0; }
case 74: {  add(2, 2004); return 0; }
case 75: {  add(4, 0); return 0; }
case 76: {  add(4, 401); return 0; }
case 77: {  add(9, -2147483647); return 0; }
case 78: {  add(9, 9); return 0; }
case 79: {  add(9, 2000); return 0; }
case 80: {  add(10, -2); return 0; }
case 81: {  add(10, 400); return 0; }
case 82: {  add(100, (-2147483647 - 1)); return 0; }
case 83: {  add(100, 2); return 0; }
case 84: {  add(100, 1900); return 0; }
case 85: {  add(399, -10); return 0; }
case 86: {  add(399, 100); return 0; }
case 87: {  add(399, 2400); return 0; }
case 88: {  add(400, 1); return 0; }
case 89: {  add(400, 800); return 0; }
case 90: {  add(401, -100); return 0; }
case 91: {  add(401, 10); return 0; }
case 92: {  add(401, 2004); return 0; }
case 93: {  add(800, -1); return 0; }
case 94: {  add(800, 401); return 0; }
case 95: {  add(1600, -2147483647); return 0; }
case 96: {  add(1600, 4); return 0; }
case 97: {  add(1600, 2000); return 0; }
case 98: {  add(1900, -2); return 0; }
case 99: {  add(1900, 399); return 0; }
case 100: {  add(2000, (-2147483647 - 1)); return 0; }
case 101: {  add(2000, 2); return 0; }
case 102: {  add(2000, 1600); return 0; }
case 103: {  add(2004, -10); return 0; }
case 104: {  add(2004, 100); return 0; }
case 105: {  add(2004, 2100); return 0; }
case 106: {  add(2100, 1); return 0; }
case 107: {  add(2100, 800); return 0; }
case 108: {  add(2400, -400); return 0; }
case 109: {  add(2400, 10); return 0; }
case 110: {  add(2400, 2004); return 0; }
case 111: {  add(95870864, -111984043); return 0; }
case 112: {  add(113621998, 772859443); return 0; }
case 113: {  add(123091116, -340361175); return 0; }
case 114: {  add(374059776, -662961268); return 0; }
case 115: {  add(445927443, 34833827); return 0; }
case 116: {  add(473873328, -113257487); return 0; }
case 117: {  add(594602771, -1306193384); return 0; }
case 118: {  add(773647602, 916477127); return 0; }
case 119: {  add(933450800, -840986556); return 0; }
case 120: {  add(1014105484, -870926028); return 0; }
case 121: {  add(1114208779, 394273271); return 0; }
case 122: {  add(1440229869, -1364673653); return 0; }
case 123: {  add(1641115217, -1831128050); return 0; }
case 124: {  add(1688080288, -1470355435); return 0; }
case 125: {  add(1746369206, 191871627); return 0; }
case 126: {  add(2147483646, -1); return 0; }
case 127: {  add(2147483647, 0); return 0; }
default: return 13; } }
