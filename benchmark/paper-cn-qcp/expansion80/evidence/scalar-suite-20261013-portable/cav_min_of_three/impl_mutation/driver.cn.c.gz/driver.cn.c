

int min_of_three(int a, int b, int c)
/*@ requires true; ensures (return == a || return == b || return == c) && return <= a && return <= b && return <= c; @*/
{
    int m = a;

    if (b < m) {
        m = b;
    }
    if (c < m) {
        m = c;
    }

    return a;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: (void)min_of_three((-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)); return 0;
case 1: (void)min_of_three((-2147483647 - 1), 4, 1600); return 0;
case 2: (void)min_of_three((-2147483647 - 1), 2004, 9); return 0;
case 3: (void)min_of_three(-2147483647, -1, -10); return 0;
case 4: (void)min_of_three(-2147483647, 401, 2400); return 0;
case 5: (void)min_of_three(-2139387294, -1466079485, 105538557); return 0;
case 6: (void)min_of_three(-2029918152, 1536268226, 2066761359); return 0;
case 7: (void)min_of_three(-1931766999, -1413924138, -1159948663); return 0;
case 8: (void)min_of_three(-1878797016, -1739990817, -701085523); return 0;
case 9: (void)min_of_three(-1828057395, -885285868, -1974084460); return 0;
case 10: (void)min_of_three(-1797653652, -918994705, -268112641); return 0;
case 11: (void)min_of_three(-1790215614, -675007704, -960502686); return 0;
case 12: (void)min_of_three(-1750058403, 436834504, 446629310); return 0;
case 13: (void)min_of_three(-1731571275, 636194446, 1039355851); return 0;
case 14: (void)min_of_three(-1711873189, -1931281029, -1250700179); return 0;
case 15: (void)min_of_three(-1658630280, -490632841, -1879926502); return 0;
case 16: (void)min_of_three(-1620629017, 231621320, 789705261); return 0;
case 17: (void)min_of_three(-1605096892, -1615715608, -1130419149); return 0;
case 18: (void)min_of_three(-1604032201, 122258344, -383937158); return 0;
case 19: (void)min_of_three(-1574613462, -826492796, -364928154); return 0;
case 20: (void)min_of_three(-1561446182, -1293312762, -398733994); return 0;
case 21: (void)min_of_three(-1540755414, -1010053380, -124346348); return 0;
case 22: (void)min_of_three(-1455678028, -785918091, 1979621205); return 0;
case 23: (void)min_of_three(-1449012313, -1573307616, 432585782); return 0;
case 24: (void)min_of_three(-1447810875, -272567631, -1414653327); return 0;
case 25: (void)min_of_three(-1410937526, -1851638108, -1616153835); return 0;
case 26: (void)min_of_three(-1352764878, -671726075, -377240918); return 0;
case 27: (void)min_of_three(-1316836289, -1886438566, -1690428829); return 0;
case 28: (void)min_of_three(-1168422971, -1792680237, -1817291078); return 0;
case 29: (void)min_of_three(-1146779776, -791231452, 170153183); return 0;
case 30: (void)min_of_three(-1044970750, -1002691851, -1828197443); return 0;
case 31: (void)min_of_three(-891427540, -2001907067, -2123227235); return 0;
case 32: (void)min_of_three(-814067383, -1404700620, -1173500206); return 0;
case 33: (void)min_of_three(-793710096, -172332215, 1538195955); return 0;
case 34: (void)min_of_three(-732796929, -1503998230, -588153056); return 0;
case 35: (void)min_of_three(-695394967, 1438314389, -1000233141); return 0;
case 36: (void)min_of_three(-689293119, -1192371609, -1147807067); return 0;
case 37: (void)min_of_three(-671199067, -1590948425, -1723675467); return 0;
case 38: (void)min_of_three(-671137146, -2142064568, -1730074521); return 0;
case 39: (void)min_of_three(-653265941, -31167790, -2000873622); return 0;
case 40: (void)min_of_three(-603781891, 1198078735, -1857200976); return 0;
case 41: (void)min_of_three(-591634885, -1924276542, -1414598302); return 0;
case 42: (void)min_of_three(-591248698, 126705180, 875984985); return 0;
case 43: (void)min_of_three(-496822756, -1774272827, -1757578760); return 0;
case 44: (void)min_of_three(-495947444, -1762362545, -2002475821); return 0;
case 45: (void)min_of_three(-427197093, -1311635507, -1724770823); return 0;
case 46: (void)min_of_three(-401018730, 1241516720, -1191511010); return 0;
case 47: (void)min_of_three(-381808957, -2077103208, -953577041); return 0;
case 48: (void)min_of_three(-310366752, -1225249598, -1141015039); return 0;
case 49: (void)min_of_three(-198981560, 1059371044, -323642783); return 0;
case 50: (void)min_of_three(-163278638, -2093221755, -1157390234); return 0;
case 51: (void)min_of_three(-126616399, -1145603038, -1629320288); return 0;
case 52: (void)min_of_three(-106630642, -217939892, 1626024355); return 0;
case 53: (void)min_of_three(-93319748, 234511586, -1958734930); return 0;
case 54: (void)min_of_three(-90327727, -262528934, -415181075); return 0;
case 55: (void)min_of_three(-68029724, 1421224699, 448284185); return 0;
case 56: (void)min_of_three(-400, -2147483647, 401); return 0;
case 57: (void)min_of_three(-400, 10, 2); return 0;
case 58: (void)min_of_three(-400, 2400, -400); return 0;
case 59: (void)min_of_three(-100, 0, 2004); return 0;
case 60: (void)min_of_three(-100, 1600, 399); return 0;
case 61: (void)min_of_three(-10, -100, 0); return 0;
case 62: (void)min_of_three(-10, 399, (-2147483647 - 1)); return 0;
case 63: (void)min_of_three(-10, 2147483646, 1900); return 0;
case 64: (void)min_of_three(-2, 2, 10); return 0;
case 65: (void)min_of_three(-2, 2000, -2); return 0;
case 66: (void)min_of_three(-1, -10, 2147483646); return 0;
case 67: (void)min_of_three(-1, 400, 800); return 0;
case 68: (void)min_of_three(0, (-2147483647 - 1), 4); return 0;
case 69: (void)min_of_three(0, 9, -100); return 0;
case 70: (void)min_of_three(0, 2004, 2100); return 0;
case 71: (void)min_of_three(1, -1, 400); return 0;
case 72: (void)min_of_three(1, 800, 1); return 0;
case 73: (void)min_of_three(2, -400, -2147483647); return 0;
case 74: (void)min_of_three(2, 10, 2000); return 0;
case 75: (void)min_of_three(2, 2400, 100); return 0;
case 76: (void)min_of_three(4, 1, -1); return 0;
case 77: (void)min_of_three(4, 1600, 2147483647); return 0;
case 78: (void)min_of_three(9, -100, 1600); return 0;
case 79: (void)min_of_three(9, 399, 9); return 0;
case 80: (void)min_of_three(9, 2147483647, -10); return 0;
case 81: (void)min_of_three(10, 2, 2400); return 0;
case 82: (void)min_of_three(10, 2000, 401); return 0;
case 83: (void)min_of_three(100, -2, 1); return 0;
case 84: (void)min_of_three(100, 401, -2147483647); return 0;
case 85: (void)min_of_three(399, (-2147483647 - 1), 2000); return 0;
case 86: (void)min_of_three(399, 9, 100); return 0;
case 87: (void)min_of_three(399, 2100, -1); return 0;
case 88: (void)min_of_three(400, -1, 2147483647); return 0;
case 89: (void)min_of_three(400, 800, 1600); return 0;
case 90: (void)min_of_three(401, -400, 9); return 0;
case 91: (void)min_of_three(401, 100, -10); return 0;
case 92: (void)min_of_three(401, 2400, 2400); return 0;
case 93: (void)min_of_three(800, 1, 401); return 0;
case 94: (void)min_of_three(800, 1900, 2); return 0;
case 95: (void)min_of_three(1600, -10, -400); return 0;
case 96: (void)min_of_three(1600, 399, 2004); return 0;
case 97: (void)min_of_three(1600, 2147483647, 399); return 0;
case 98: (void)min_of_three(1900, 4, 0); return 0;
case 99: (void)min_of_three(1900, 2004, (-2147483647 - 1)); return 0;
case 100: (void)min_of_three(2000, -2, 1900); return 0;
case 101: (void)min_of_three(2000, 401, 10); return 0;
case 102: (void)min_of_three(2004, -2147483647, -2); return 0;
case 103: (void)min_of_three(2004, 9, 2147483646); return 0;
case 104: (void)min_of_three(2004, 2100, 800); return 0;
case 105: (void)min_of_three(2100, 0, 4); return 0;
case 106: (void)min_of_three(2100, 1600, -100); return 0;
case 107: (void)min_of_three(2400, -400, 2100); return 0;
case 108: (void)min_of_three(2400, 100, 400); return 0;
case 109: (void)min_of_three(2400, 2147483646, 1); return 0;
case 110: (void)min_of_three(107555884, -1062758967, -220429608); return 0;
case 111: (void)min_of_three(812143922, -1569384265, 443323213); return 0;
case 112: (void)min_of_three(1207602394, 1285298451, -1432784013); return 0;
case 113: (void)min_of_three(1261999031, 333695958, 212673041); return 0;
case 114: (void)min_of_three(1480290550, 1098840568, 871973265); return 0;
case 115: (void)min_of_three(1647751680, 2044162935, -1179847817); return 0;
case 116: (void)min_of_three(1721576840, -13304952, 1786124984); return 0;
case 117: (void)min_of_three(1728500648, 608311664, -2085872320); return 0;
case 118: (void)min_of_three(1738124632, -137300129, -426388867); return 0;
case 119: (void)min_of_three(1824146759, 876980393, -187871731); return 0;
case 120: (void)min_of_three(2056917199, 161143905, 1080925866); return 0;
case 121: (void)min_of_three(2073463628, 627181172, -1476357480); return 0;
case 122: (void)min_of_three(2115134328, -1920245344, -1401208178); return 0;
case 123: (void)min_of_three(2147483646, 2, -2147483647); return 0;
case 124: (void)min_of_three(2147483646, 1900, 2000); return 0;
case 125: (void)min_of_three(2147483647, -10, 100); return 0;
case 126: (void)min_of_three(2147483647, 400, -1); return 0;
case 127: (void)min_of_three(2147483647, 2147483647, 2147483647); return 0;
default: return 13; } }
