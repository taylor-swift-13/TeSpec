/*@
function [rec] (integer) PowerSearch(integer x, integer n, integer p, integer fuel) {
  if (p == x) { 1 }
  else { if (p > x || fuel <= 0) { 0 }
         else { PowerSearch(x,n,p*n,fuel-1) } }
}
@*/
int p076_is_simple_power(int x, int n)
/*@ requires 1 <= x; x <= 2147483647; 1 <= n; n <= 2147483647; x*n <= 2147483647;
    ensures (1-return != 0) == (PowerSearch(x,n,1,31) != 0); @*/
{
    int p=1,count=0;
    
    while (p<=x && count<100)
    {
        if (p==x) return 1;
        p=p*n;count+=1;
    }
    return 0;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: {  p076_is_simple_power(1, 1); return 0; }
case 1: {  p076_is_simple_power(2, 1); return 0; }
case 2: {  p076_is_simple_power(2147483647, 1); return 0; }
case 3: {  p076_is_simple_power(1, 2147483647); return 0; }
case 4: {  p076_is_simple_power(1, 2147483646); return 0; }
case 5: {  p076_is_simple_power(1, 46340); return 0; }
case 6: {  p076_is_simple_power(46340, 46340); return 0; }
case 7: {  p076_is_simple_power(1073741823, 2); return 0; }
case 8: {  p076_is_simple_power(536870912, 2); return 0; }
case 9: {  p076_is_simple_power(536870911, 2); return 0; }
case 10: {  p076_is_simple_power(536870913, 2); return 0; }
case 11: {  p076_is_simple_power(625, 5); return 0; }
case 12: {  p076_is_simple_power(43046720, 3); return 0; }
case 13: {  p076_is_simple_power(4782970, 3); return 0; }
case 14: {  p076_is_simple_power(177148, 3); return 0; }
case 15: {  p076_is_simple_power(4194303, 4); return 0; }
case 16: {  p076_is_simple_power(10001, 100); return 0; }
case 17: {  p076_is_simple_power(1, 10); return 0; }
case 18: {  p076_is_simple_power(1024, 2); return 0; }
case 19: {  p076_is_simple_power(65535, 2); return 0; }
case 20: {  p076_is_simple_power(9999, 100); return 0; }
case 21: {  p076_is_simple_power(59048, 3); return 0; }
case 22: {  p076_is_simple_power(531442, 3); return 0; }
case 23: {  p076_is_simple_power(16385, 2); return 0; }
case 24: {  p076_is_simple_power(1000, 10); return 0; }
case 25: {  p076_is_simple_power(1, 2); return 0; }
case 26: {  p076_is_simple_power(134217728, 2); return 0; }
case 27: {  p076_is_simple_power(387420488, 3); return 0; }
case 28: {  p076_is_simple_power(64, 2); return 0; }
case 29: {  p076_is_simple_power(9, 10); return 0; }
case 30: {  p076_is_simple_power(2400, 7); return 0; }
case 31: {  p076_is_simple_power(19683, 3); return 0; }
case 32: {  p076_is_simple_power(48, 7); return 0; }
case 33: {  p076_is_simple_power(100001, 10); return 0; }
case 34: {  p076_is_simple_power(16, 4); return 0; }
case 35: {  p076_is_simple_power(14348907, 3); return 0; }
case 36: {  p076_is_simple_power(1953124, 5); return 0; }
case 37: {  p076_is_simple_power(63, 2); return 0; }
case 38: {  p076_is_simple_power(513, 2); return 0; }
case 39: {  p076_is_simple_power(4096, 2); return 0; }
case 40: {  p076_is_simple_power(1000000, 10); return 0; }
case 41: {  p076_is_simple_power(65, 2); return 0; }
case 42: {  p076_is_simple_power(5764802, 7); return 0; }
case 43: {  p076_is_simple_power(5, 5); return 0; }
case 44: {  p076_is_simple_power(999999, 100); return 0; }
case 45: {  p076_is_simple_power(511, 2); return 0; }
case 46: {  p076_is_simple_power(63, 4); return 0; }
case 47: {  p076_is_simple_power(1953126, 5); return 0; }
case 48: {  p076_is_simple_power(6, 7); return 0; }
case 49: {  p076_is_simple_power(10000, 100); return 0; }
case 50: {  p076_is_simple_power(125, 5); return 0; }
case 51: {  p076_is_simple_power(31, 31); return 0; }
case 52: {  p076_is_simple_power(32768, 2); return 0; }
case 53: {  p076_is_simple_power(67108865, 4); return 0; }
case 54: {  p076_is_simple_power(8388609, 2); return 0; }
case 55: {  p076_is_simple_power(4097, 4); return 0; }
case 56: {  p076_is_simple_power(2, 7); return 0; }
case 57: {  p076_is_simple_power(129140163, 3); return 0; }
case 58: {  p076_is_simple_power(26, 5); return 0; }
case 59: {  p076_is_simple_power(268435455, 4); return 0; }
case 60: {  p076_is_simple_power(6562, 3); return 0; }
case 61: {  p076_is_simple_power(2048, 2); return 0; }
case 62: {  p076_is_simple_power(730, 3); return 0; }
case 63: {  p076_is_simple_power(4194304, 2); return 0; }
case 64: {  p076_is_simple_power(268435456, 2); return 0; }
case 65: {  p076_is_simple_power(129140162, 3); return 0; }
case 66: {  p076_is_simple_power(43046722, 3); return 0; }
case 67: {  p076_is_simple_power(268435457, 4); return 0; }
case 68: {  p076_is_simple_power(65536, 2); return 0; }
case 69: {  p076_is_simple_power(15624, 5); return 0; }
case 70: {  p076_is_simple_power(256, 4); return 0; }
case 71: {  p076_is_simple_power(25, 5); return 0; }
case 72: {  p076_is_simple_power(3125, 5); return 0; }
case 73: {  p076_is_simple_power(67108864, 2); return 0; }
case 74: {  p076_is_simple_power(40353608, 7); return 0; }
case 75: {  p076_is_simple_power(67108865, 2); return 0; }
case 76: {  p076_is_simple_power(4194303, 2); return 0; }
case 77: {  p076_is_simple_power(2097153, 2); return 0; }
case 78: {  p076_is_simple_power(390624, 5); return 0; }
case 79: {  p076_is_simple_power(16384, 2); return 0; }
case 80: {  p076_is_simple_power(1048575, 2); return 0; }
case 81: {  p076_is_simple_power(16, 2); return 0; }
case 82: {  p076_is_simple_power(40353607, 7); return 0; }
case 83: {  p076_is_simple_power(5, 2); return 0; }
case 84: {  p076_is_simple_power(131072, 2); return 0; }
case 85: {  p076_is_simple_power(65536, 4); return 0; }
case 86: {  p076_is_simple_power(2, 2); return 0; }
case 87: {  p076_is_simple_power(2, 100); return 0; }
case 88: {  p076_is_simple_power(4, 4); return 0; }
case 89: {  p076_is_simple_power(4097, 2); return 0; }
case 90: {  p076_is_simple_power(19682, 3); return 0; }
case 91: {  p076_is_simple_power(961, 31); return 0; }
case 92: {  p076_is_simple_power(387420489, 3); return 0; }
case 93: {  p076_is_simple_power(8388608, 2); return 0; }
case 94: {  p076_is_simple_power(1024, 4); return 0; }
case 95: {  p076_is_simple_power(10000000, 10); return 0; }
case 96: {  p076_is_simple_power(15626, 5); return 0; }
case 97: {  p076_is_simple_power(65537, 2); return 0; }
case 98: {  p076_is_simple_power(4096, 4); return 0; }
case 99: {  p076_is_simple_power(4095, 2); return 0; }
case 100: {  p076_is_simple_power(32767, 2); return 0; }
case 101: {  p076_is_simple_power(262143, 2); return 0; }
case 102: {  p076_is_simple_power(1953125, 5); return 0; }
case 103: {  p076_is_simple_power(4194305, 2); return 0; }
case 104: {  p076_is_simple_power(29792, 31); return 0; }
case 105: {  p076_is_simple_power(16806, 7); return 0; }
case 106: {  p076_is_simple_power(99, 10); return 0; }
case 107: {  p076_is_simple_power(2, 31); return 0; }
case 108: {  p076_is_simple_power(50, 7); return 0; }
case 109: {  p076_is_simple_power(524287, 2); return 0; }
case 110: {  p076_is_simple_power(100000, 10); return 0; }
case 111: {  p076_is_simple_power(1025, 2); return 0; }
case 112: {  p076_is_simple_power(243, 3); return 0; }
case 113: {  p076_is_simple_power(49, 7); return 0; }
case 114: {  p076_is_simple_power(16777215, 2); return 0; }
case 115: {  p076_is_simple_power(4194304, 4); return 0; }
case 116: {  p076_is_simple_power(10, 3); return 0; }
case 117: {  p076_is_simple_power(1048575, 4); return 0; }
case 118: {  p076_is_simple_power(8191, 2); return 0; }
case 119: {  p076_is_simple_power(16385, 4); return 0; }
case 120: {  p076_is_simple_power(344, 7); return 0; }
case 121: {  p076_is_simple_power(19684, 3); return 0; }
case 122: {  p076_is_simple_power(923522, 31); return 0; }
case 123: {  p076_is_simple_power(134217729, 2); return 0; }
case 124: {  p076_is_simple_power(923521, 31); return 0; }
case 125: {  p076_is_simple_power(81, 3); return 0; }
case 126: {  p076_is_simple_power(65, 4); return 0; }
case 127: {  p076_is_simple_power(9999999, 10); return 0; }
default: return 13; } }
