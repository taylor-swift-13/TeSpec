unsigned int five_six(unsigned int *p, unsigned int *q) 
/*@ requires take P = RW<unsigned int>(p);
		     take Q = RW<unsigned int>(q);
    ensures  take P_post = RW<unsigned int>(p);
    		 take Q_post = RW<unsigned int>(q);
             return == 5;
@*/
{
	*p = 5;
	*q = 6;
	return *q;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: { unsigned int p = 0U; unsigned int q = 0U; five_six(&p, &q); return 0; }
case 1: { unsigned int p = 0U; unsigned int q = 10U; five_six(&p, &q); return 0; }
case 2: { unsigned int p = 0U; unsigned int q = 1600U; five_six(&p, &q); return 0; }
case 3: { unsigned int p = 0U; unsigned int q = 4294967294U; five_six(&p, &q); return 0; }
case 4: { unsigned int p = 1U; unsigned int q = 4U; five_six(&p, &q); return 0; }
case 5: { unsigned int p = 1U; unsigned int q = 401U; five_six(&p, &q); return 0; }
case 6: { unsigned int p = 1U; unsigned int q = 2100U; five_six(&p, &q); return 0; }
case 7: { unsigned int p = 2U; unsigned int q = 2U; five_six(&p, &q); return 0; }
case 8: { unsigned int p = 2U; unsigned int q = 399U; five_six(&p, &q); return 0; }
case 9: { unsigned int p = 2U; unsigned int q = 2000U; five_six(&p, &q); return 0; }
case 10: { unsigned int p = 4U; unsigned int q = 0U; five_six(&p, &q); return 0; }
case 11: { unsigned int p = 4U; unsigned int q = 10U; five_six(&p, &q); return 0; }
case 12: { unsigned int p = 4U; unsigned int q = 1600U; five_six(&p, &q); return 0; }
case 13: { unsigned int p = 4U; unsigned int q = 4294967294U; five_six(&p, &q); return 0; }
case 14: { unsigned int p = 9U; unsigned int q = 9U; five_six(&p, &q); return 0; }
case 15: { unsigned int p = 9U; unsigned int q = 401U; five_six(&p, &q); return 0; }
case 16: { unsigned int p = 9U; unsigned int q = 2100U; five_six(&p, &q); return 0; }
case 17: { unsigned int p = 10U; unsigned int q = 2U; five_six(&p, &q); return 0; }
case 18: { unsigned int p = 10U; unsigned int q = 399U; five_six(&p, &q); return 0; }
case 19: { unsigned int p = 10U; unsigned int q = 2000U; five_six(&p, &q); return 0; }
case 20: { unsigned int p = 100U; unsigned int q = 0U; five_six(&p, &q); return 0; }
case 21: { unsigned int p = 100U; unsigned int q = 100U; five_six(&p, &q); return 0; }
case 22: { unsigned int p = 100U; unsigned int q = 1600U; five_six(&p, &q); return 0; }
case 23: { unsigned int p = 100U; unsigned int q = 4294967294U; five_six(&p, &q); return 0; }
case 24: { unsigned int p = 241U; unsigned int q = 2536U; five_six(&p, &q); return 0; }
case 25: { unsigned int p = 320U; unsigned int q = 1780U; five_six(&p, &q); return 0; }
case 26: { unsigned int p = 348U; unsigned int q = 214U; five_six(&p, &q); return 0; }
case 27: { unsigned int p = 399U; unsigned int q = 9U; five_six(&p, &q); return 0; }
case 28: { unsigned int p = 399U; unsigned int q = 401U; five_six(&p, &q); return 0; }
case 29: { unsigned int p = 399U; unsigned int q = 2100U; five_six(&p, &q); return 0; }
case 30: { unsigned int p = 400U; unsigned int q = 2U; five_six(&p, &q); return 0; }
case 31: { unsigned int p = 400U; unsigned int q = 400U; five_six(&p, &q); return 0; }
case 32: { unsigned int p = 400U; unsigned int q = 2000U; five_six(&p, &q); return 0; }
case 33: { unsigned int p = 401U; unsigned int q = 0U; five_six(&p, &q); return 0; }
case 34: { unsigned int p = 401U; unsigned int q = 100U; five_six(&p, &q); return 0; }
case 35: { unsigned int p = 401U; unsigned int q = 1600U; five_six(&p, &q); return 0; }
case 36: { unsigned int p = 401U; unsigned int q = 4294967294U; five_six(&p, &q); return 0; }
case 37: { unsigned int p = 521U; unsigned int q = 537U; five_six(&p, &q); return 0; }
case 38: { unsigned int p = 630U; unsigned int q = 3393U; five_six(&p, &q); return 0; }
case 39: { unsigned int p = 665U; unsigned int q = 3124U; five_six(&p, &q); return 0; }
case 40: { unsigned int p = 800U; unsigned int q = 9U; five_six(&p, &q); return 0; }
case 41: { unsigned int p = 800U; unsigned int q = 800U; five_six(&p, &q); return 0; }
case 42: { unsigned int p = 800U; unsigned int q = 2100U; five_six(&p, &q); return 0; }
case 43: { unsigned int p = 845U; unsigned int q = 3360U; five_six(&p, &q); return 0; }
case 44: { unsigned int p = 969U; unsigned int q = 3667U; five_six(&p, &q); return 0; }
case 45: { unsigned int p = 1017U; unsigned int q = 2686U; five_six(&p, &q); return 0; }
case 46: { unsigned int p = 1379U; unsigned int q = 2993U; five_six(&p, &q); return 0; }
case 47: { unsigned int p = 1477U; unsigned int q = 2666U; five_six(&p, &q); return 0; }
case 48: { unsigned int p = 1570U; unsigned int q = 3773U; five_six(&p, &q); return 0; }
case 49: { unsigned int p = 1600U; unsigned int q = 2U; five_six(&p, &q); return 0; }
case 50: { unsigned int p = 1600U; unsigned int q = 400U; five_six(&p, &q); return 0; }
case 51: { unsigned int p = 1600U; unsigned int q = 2000U; five_six(&p, &q); return 0; }
case 52: { unsigned int p = 1645U; unsigned int q = 3701U; five_six(&p, &q); return 0; }
case 53: { unsigned int p = 1810U; unsigned int q = 2962U; five_six(&p, &q); return 0; }
case 54: { unsigned int p = 1812U; unsigned int q = 855U; five_six(&p, &q); return 0; }
case 55: { unsigned int p = 1900U; unsigned int q = 0U; five_six(&p, &q); return 0; }
case 56: { unsigned int p = 1900U; unsigned int q = 100U; five_six(&p, &q); return 0; }
case 57: { unsigned int p = 1900U; unsigned int q = 1900U; five_six(&p, &q); return 0; }
case 58: { unsigned int p = 1900U; unsigned int q = 4294967294U; five_six(&p, &q); return 0; }
case 59: { unsigned int p = 1928U; unsigned int q = 839U; five_six(&p, &q); return 0; }
case 60: { unsigned int p = 1991U; unsigned int q = 513U; five_six(&p, &q); return 0; }
case 61: { unsigned int p = 2000U; unsigned int q = 9U; five_six(&p, &q); return 0; }
case 62: { unsigned int p = 2000U; unsigned int q = 800U; five_six(&p, &q); return 0; }
case 63: { unsigned int p = 2000U; unsigned int q = 2100U; five_six(&p, &q); return 0; }
case 64: { unsigned int p = 2004U; unsigned int q = 2U; five_six(&p, &q); return 0; }
case 65: { unsigned int p = 2004U; unsigned int q = 400U; five_six(&p, &q); return 0; }
case 66: { unsigned int p = 2004U; unsigned int q = 2004U; five_six(&p, &q); return 0; }
case 67: { unsigned int p = 2100U; unsigned int q = 0U; five_six(&p, &q); return 0; }
case 68: { unsigned int p = 2100U; unsigned int q = 100U; five_six(&p, &q); return 0; }
case 69: { unsigned int p = 2100U; unsigned int q = 1900U; five_six(&p, &q); return 0; }
case 70: { unsigned int p = 2100U; unsigned int q = 4294967294U; five_six(&p, &q); return 0; }
case 71: { unsigned int p = 2400U; unsigned int q = 9U; five_six(&p, &q); return 0; }
case 72: { unsigned int p = 2400U; unsigned int q = 800U; five_six(&p, &q); return 0; }
case 73: { unsigned int p = 2400U; unsigned int q = 2400U; five_six(&p, &q); return 0; }
case 74: { unsigned int p = 2506U; unsigned int q = 84U; five_six(&p, &q); return 0; }
case 75: { unsigned int p = 2624U; unsigned int q = 2713U; five_six(&p, &q); return 0; }
case 76: { unsigned int p = 2685U; unsigned int q = 1610U; five_six(&p, &q); return 0; }
case 77: { unsigned int p = 2970U; unsigned int q = 2611U; five_six(&p, &q); return 0; }
case 78: { unsigned int p = 3067U; unsigned int q = 1614U; five_six(&p, &q); return 0; }
case 79: { unsigned int p = 3089U; unsigned int q = 1355U; five_six(&p, &q); return 0; }
case 80: { unsigned int p = 3108U; unsigned int q = 458U; five_six(&p, &q); return 0; }
case 81: { unsigned int p = 3304U; unsigned int q = 1185U; five_six(&p, &q); return 0; }
case 82: { unsigned int p = 3399U; unsigned int q = 437U; five_six(&p, &q); return 0; }
case 83: { unsigned int p = 3640U; unsigned int q = 1387U; five_six(&p, &q); return 0; }
case 84: { unsigned int p = 3744U; unsigned int q = 2344U; five_six(&p, &q); return 0; }
case 85: { unsigned int p = 3864U; unsigned int q = 3698U; five_six(&p, &q); return 0; }
case 86: { unsigned int p = 3890U; unsigned int q = 3893U; five_six(&p, &q); return 0; }
case 87: { unsigned int p = 3934U; unsigned int q = 4034U; five_six(&p, &q); return 0; }
case 88: { unsigned int p = 3963U; unsigned int q = 3137U; five_six(&p, &q); return 0; }
case 89: { unsigned int p = 62067097U; unsigned int q = 1578327848U; five_six(&p, &q); return 0; }
case 90: { unsigned int p = 657551918U; unsigned int q = 2908295958U; five_six(&p, &q); return 0; }
case 91: { unsigned int p = 893143590U; unsigned int q = 3381619671U; five_six(&p, &q); return 0; }
case 92: { unsigned int p = 964704780U; unsigned int q = 2532392796U; five_six(&p, &q); return 0; }
case 93: { unsigned int p = 994133217U; unsigned int q = 305202158U; five_six(&p, &q); return 0; }
case 94: { unsigned int p = 1011062755U; unsigned int q = 3510008398U; five_six(&p, &q); return 0; }
case 95: { unsigned int p = 1204031168U; unsigned int q = 1675404779U; five_six(&p, &q); return 0; }
case 96: { unsigned int p = 1265127161U; unsigned int q = 2370890204U; five_six(&p, &q); return 0; }
case 97: { unsigned int p = 1704666516U; unsigned int q = 3072559899U; five_six(&p, &q); return 0; }
case 98: { unsigned int p = 1724555609U; unsigned int q = 3340780237U; five_six(&p, &q); return 0; }
case 99: { unsigned int p = 1852041741U; unsigned int q = 1698833487U; five_six(&p, &q); return 0; }
case 100: { unsigned int p = 2131408694U; unsigned int q = 3231362224U; five_six(&p, &q); return 0; }
case 101: { unsigned int p = 2261105646U; unsigned int q = 2920343091U; five_six(&p, &q); return 0; }
case 102: { unsigned int p = 2270574764U; unsigned int q = 1807122473U; five_six(&p, &q); return 0; }
case 103: { unsigned int p = 2521543424U; unsigned int q = 1484522380U; five_six(&p, &q); return 0; }
case 104: { unsigned int p = 2621356976U; unsigned int q = 2034226161U; five_six(&p, &q); return 0; }
case 105: { unsigned int p = 2742086419U; unsigned int q = 841290264U; five_six(&p, &q); return 0; }
case 106: { unsigned int p = 2921131250U; unsigned int q = 3063960775U; five_six(&p, &q); return 0; }
case 107: { unsigned int p = 3080934448U; unsigned int q = 1306497092U; five_six(&p, &q); return 0; }
case 108: { unsigned int p = 3161589132U; unsigned int q = 1276557620U; five_six(&p, &q); return 0; }
case 109: { unsigned int p = 3237887411U; unsigned int q = 3988897054U; five_six(&p, &q); return 0; }
case 110: { unsigned int p = 3261692427U; unsigned int q = 2541756919U; five_six(&p, &q); return 0; }
case 111: { unsigned int p = 3439525711U; unsigned int q = 3141346717U; five_six(&p, &q); return 0; }
case 112: { unsigned int p = 3519563107U; unsigned int q = 3151202525U; five_six(&p, &q); return 0; }
case 113: { unsigned int p = 3539886343U; unsigned int q = 3072469589U; five_six(&p, &q); return 0; }
case 114: { unsigned int p = 3604398671U; unsigned int q = 2953492271U; five_six(&p, &q); return 0; }
case 115: { unsigned int p = 3788598865U; unsigned int q = 316355598U; five_six(&p, &q); return 0; }
case 116: { unsigned int p = 3893852854U; unsigned int q = 2339355275U; five_six(&p, &q); return 0; }
case 117: { unsigned int p = 3989018947U; unsigned int q = 4237298253U; five_six(&p, &q); return 0; }
case 118: { unsigned int p = 4233698182U; unsigned int q = 2413072352U; five_six(&p, &q); return 0; }
case 119: { unsigned int p = 4247893452U; unsigned int q = 2577027581U; five_six(&p, &q); return 0; }
case 120: { unsigned int p = 4293967469U; unsigned int q = 4011016879U; five_six(&p, &q); return 0; }
case 121: { unsigned int p = 4294967294U; unsigned int q = 2U; five_six(&p, &q); return 0; }
case 122: { unsigned int p = 4294967294U; unsigned int q = 400U; five_six(&p, &q); return 0; }
case 123: { unsigned int p = 4294967294U; unsigned int q = 2004U; five_six(&p, &q); return 0; }
case 124: { unsigned int p = 4294967295U; unsigned int q = 0U; five_six(&p, &q); return 0; }
case 125: { unsigned int p = 4294967295U; unsigned int q = 100U; five_six(&p, &q); return 0; }
case 126: { unsigned int p = 4294967295U; unsigned int q = 1900U; five_six(&p, &q); return 0; }
case 127: { unsigned int p = 4294967295U; unsigned int q = 4294967295U; five_six(&p, &q); return 0; }
default: return 13; } }
