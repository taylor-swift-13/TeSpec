



void chars_initialize(char *a, int n, char m)
/*@ requires 0 <= n; n < 2147483647; take A = each(integer i; 0 <= i && i < n) {W<char>(array_shift<char>(a,i))}; ensures take B = each(integer i; 0 <= i && i < n) {RW<char>(array_shift<char>(a,i))}; each(integer i; 0 <= i && i < n) {B[i] == m}; @*/
{
  int i;
  
  for (i = 0; i < n; i++)
  {
    a[i] = 0;
  }
}
int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: { char a[1] = {0}; chars_initialize(a, 0, -128); return 0; }
case 1: { char a[1] = {-128}; chars_initialize(a, 1, -128); return 0; }
case 2: { char a[16] = {-128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127}; chars_initialize(a, 16, -128); return 0; }
case 3: { char a[1] = {0}; chars_initialize(a, 0, -127); return 0; }
case 4: { char a[1] = {-128}; chars_initialize(a, 1, -127); return 0; }
case 5: { char a[16] = {-128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127}; chars_initialize(a, 16, -127); return 0; }
case 6: { char a[1] = {0}; chars_initialize(a, 0, -1); return 0; }
case 7: { char a[1] = {-128}; chars_initialize(a, 1, -1); return 0; }
case 8: { char a[16] = {-128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127}; chars_initialize(a, 16, -1); return 0; }
case 9: { char a[1] = {0}; chars_initialize(a, 0, 0); return 0; }
case 10: { char a[1] = {-128}; chars_initialize(a, 1, 0); return 0; }
case 11: { char a[16] = {-128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127}; chars_initialize(a, 16, 0); return 0; }
case 12: { char a[1] = {0}; chars_initialize(a, 0, 1); return 0; }
case 13: { char a[1] = {-128}; chars_initialize(a, 1, 1); return 0; }
case 14: { char a[16] = {-128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127}; chars_initialize(a, 16, 1); return 0; }
case 15: { char a[1] = {0}; chars_initialize(a, 0, 65); return 0; }
case 16: { char a[1] = {-128}; chars_initialize(a, 1, 65); return 0; }
case 17: { char a[16] = {-128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127}; chars_initialize(a, 16, 65); return 0; }
case 18: { char a[1] = {0}; chars_initialize(a, 0, 126); return 0; }
case 19: { char a[1] = {-128}; chars_initialize(a, 1, 126); return 0; }
case 20: { char a[16] = {-128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127}; chars_initialize(a, 16, 126); return 0; }
case 21: { char a[1] = {0}; chars_initialize(a, 0, 127); return 0; }
case 22: { char a[1] = {-128}; chars_initialize(a, 1, 127); return 0; }
case 23: { char a[16] = {-128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127, -128, 127}; chars_initialize(a, 16, 127); return 0; }
case 24: { char a[1] = {0}; chars_initialize(a, 0, 106); return 0; }
case 25: { char a[2] = {-128, -128}; chars_initialize(a, 2, -29); return 0; }
case 26: { char a[3] = {-128, -128, -128}; chars_initialize(a, 3, 0); return 0; }
case 27: { char a[4] = {-128, -128, -128, -128}; chars_initialize(a, 4, 39); return 0; }
case 28: { char a[8] = {-128, -128, -128, -128, -128, -128, -128, -128}; chars_initialize(a, 8, 65); return 0; }
case 29: { char a[16] = {-128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128}; chars_initialize(a, 16, 114); return 0; }
case 30: { char a[1] = {-128}; chars_initialize(a, 1, -79); return 0; }
case 31: { char a[2] = {-127, -1}; chars_initialize(a, 2, -127); return 0; }
case 32: { char a[3] = {-1, 0, 1}; chars_initialize(a, 3, 84); return 0; }
case 33: { char a[4] = {0, 1, 65, 126}; chars_initialize(a, 4, 0); return 0; }
case 34: { char a[8] = {1, 65, 126, 127, -128, -127, -1, 0}; chars_initialize(a, 8, -101); return 0; }
case 35: { char a[1] = {0}; chars_initialize(a, 0, -7); return 0; }
case 36: { char a[2] = {-128, -127}; chars_initialize(a, 2, -75); return 0; }
case 37: { char a[3] = {127, 1, -127}; chars_initialize(a, 3, -127); return 0; }
case 38: { char a[4] = {0, -127, -127, 65}; chars_initialize(a, 4, -36); return 0; }
case 39: { char a[8] = {1, 1, -1, 0, 65, 65, 0, 127}; chars_initialize(a, 8, 0); return 0; }
case 40: { char a[16] = {1, 0, 0, 127, -127, 65, -1, 126, 65, 126, -128, 65, -128, 127, 65, -128}; chars_initialize(a, 16, 103); return 0; }
case 41: { char a[1] = {-56}; chars_initialize(a, 1, -116); return 0; }
case 42: { char a[2] = {90, -115}; chars_initialize(a, 2, 127); return 0; }
case 43: { char a[3] = {87, -24, 63}; chars_initialize(a, 3, -28); return 0; }
case 44: { char a[4] = {-10, -109, 117, -92}; chars_initialize(a, 4, -127); return 0; }
case 45: { char a[8] = {23, -108, -17, 22, -49, 107, -54, 56}; chars_initialize(a, 8, 78); return 0; }
case 46: { char a[1] = {0}; chars_initialize(a, 0, -105); return 0; }
case 47: { char a[2] = {1, 1}; chars_initialize(a, 2, 14); return 0; }
case 48: { char a[3] = {1, 1, 1}; chars_initialize(a, 3, 127); return 0; }
case 49: { char a[4] = {1, 1, 1, 1}; chars_initialize(a, 4, -17); return 0; }
case 50: { char a[8] = {1, 1, 1, 1, 1, 1, 1, 1}; chars_initialize(a, 8, -127); return 0; }
case 51: { char a[16] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}; chars_initialize(a, 16, -15); return 0; }
case 52: { char a[1] = {1}; chars_initialize(a, 1, 57); return 0; }
case 53: { char a[2] = {65, 126}; chars_initialize(a, 2, 65); return 0; }
case 54: { char a[3] = {126, 127, -128}; chars_initialize(a, 3, 18); return 0; }
case 55: { char a[4] = {127, -128, -127, -1}; chars_initialize(a, 4, 127); return 0; }
case 56: { char a[8] = {-128, -127, -1, 0, 1, 65, 126, 127}; chars_initialize(a, 8, 12); return 0; }
case 57: { char a[1] = {0}; chars_initialize(a, 0, 5); return 0; }
case 58: { char a[2] = {1, 127}; chars_initialize(a, 2, 9); return 0; }
case 59: { char a[3] = {-127, 127, 1}; chars_initialize(a, 3, 65); return 0; }
case 60: { char a[4] = {127, -127, 126, 126}; chars_initialize(a, 4, -65); return 0; }
case 61: { char a[8] = {-1, 1, 127, 0, -1, 0, -127, -1}; chars_initialize(a, 8, 127); return 0; }
case 62: { char a[16] = {126, 65, -1, 65, -128, 1, 1, -127, 0, -1, -128, -128, -128, 1, 127, 65}; chars_initialize(a, 16, -23); return 0; }
case 63: { char a[1] = {47}; chars_initialize(a, 1, -50); return 0; }
case 64: { char a[2] = {-106, 66}; chars_initialize(a, 2, 0); return 0; }
case 65: { char a[3] = {-100, 46, -119}; chars_initialize(a, 3, 106); return 0; }
case 66: { char a[4] = {18, -1, -13, -34}; chars_initialize(a, 4, 65); return 0; }
case 67: { char a[8] = {91, -74, -76, 82, 77, 41, 4, -42}; chars_initialize(a, 8, 59); return 0; }
case 68: { char a[1] = {0}; chars_initialize(a, 0, 117); return 0; }
case 69: { char a[2] = {-128, -128}; chars_initialize(a, 2, 124); return 0; }
case 70: { char a[4] = {-128, -128, -128, -128}; chars_initialize(a, 4, 28); return 0; }
case 71: { char a[16] = {-128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128}; chars_initialize(a, 16, -90); return 0; }
case 72: { char a[1] = {-128}; chars_initialize(a, 1, -96); return 0; }
case 73: { char a[3] = {-1, 0, 1}; chars_initialize(a, 3, -95); return 0; }
case 74: { char a[8] = {1, 65, 126, 127, -128, -127, -1, 0}; chars_initialize(a, 8, -112); return 0; }
case 75: { char a[1] = {0}; chars_initialize(a, 0, -77); return 0; }
case 76: { char a[2] = {127, -128}; chars_initialize(a, 2, -74); return 0; }
case 77: { char a[4] = {126, 127, -127, 65}; chars_initialize(a, 4, 46); return 0; }
case 78: { char a[16] = {126, 0, 65, -127, 126, -1, 0, 127, -128, 127, 126, 127, 127, 0, -127, 65}; chars_initialize(a, 16, 71); return 0; }
case 79: { char a[1] = {37}; chars_initialize(a, 1, -117); return 0; }
case 80: { char a[3] = {-15, 103, -46}; chars_initialize(a, 3, 76); return 0; }
case 81: { char a[8] = {11, 90, -66, -1, 67, -92, 112, 96}; chars_initialize(a, 8, -100); return 0; }
case 82: { char a[1] = {0}; chars_initialize(a, 0, -2); return 0; }
case 83: { char a[2] = {1, 1}; chars_initialize(a, 2, 103); return 0; }
case 84: { char a[4] = {1, 1, 1, 1}; chars_initialize(a, 4, -117); return 0; }
case 85: { char a[16] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}; chars_initialize(a, 16, -52); return 0; }
case 86: { char a[1] = {1}; chars_initialize(a, 1, 40); return 0; }
case 87: { char a[3] = {126, 127, -128}; chars_initialize(a, 3, -82); return 0; }
case 88: { char a[8] = {-128, -127, -1, 0, 1, 65, 126, 127}; chars_initialize(a, 8, 40); return 0; }
case 89: { char a[1] = {0}; chars_initialize(a, 0, -103); return 0; }
case 90: { char a[2] = {-1, 1}; chars_initialize(a, 2, 97); return 0; }
case 91: { char a[4] = {-1, 1, 127, -128}; chars_initialize(a, 4, -66); return 0; }
case 92: { char a[16] = {-127, 1, -1, -128, -128, -127, -1, 0, 0, 0, 0, -128, 1, 0, 126, -127}; chars_initialize(a, 16, 66); return 0; }
case 93: { char a[1] = {55}; chars_initialize(a, 1, 51); return 0; }
case 94: { char a[3] = {89, 96, 34}; chars_initialize(a, 3, 6); return 0; }
case 95: { char a[8] = {114, 120, -43, 116, -106, -58, -98, 88}; chars_initialize(a, 8, -37); return 0; }
case 96: { char a[1] = {0}; chars_initialize(a, 0, -57); return 0; }
case 97: { char a[2] = {-128, -128}; chars_initialize(a, 2, 89); return 0; }
case 98: { char a[16] = {-128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128}; chars_initialize(a, 16, 61); return 0; }
case 99: { char a[3] = {-1, 0, 1}; chars_initialize(a, 3, 117); return 0; }
case 100: { char a[8] = {1, 65, 126, 127, -128, -127, -1, 0}; chars_initialize(a, 8, -45); return 0; }
case 101: { char a[1] = {0}; chars_initialize(a, 0, -72); return 0; }
case 102: { char a[2] = {127, 0}; chars_initialize(a, 2, -22); return 0; }
case 103: { char a[4] = {126, -1, -128, -128}; chars_initialize(a, 4, 59); return 0; }
case 104: { char a[16] = {-127, 127, -127, -1, 126, 65, 0, -1, 1, 127, 127, 1, 65, 0, -1, 1}; chars_initialize(a, 16, -100); return 0; }
case 105: { char a[1] = {-34}; chars_initialize(a, 1, -55); return 0; }
case 106: { char a[3] = {-33, 114, 12}; chars_initialize(a, 3, 72); return 0; }
case 107: { char a[8] = {-124, 103, 88, -121, 37, -121, -27, 113}; chars_initialize(a, 8, -3); return 0; }
case 108: { char a[1] = {0}; chars_initialize(a, 0, 61); return 0; }
case 109: { char a[2] = {1, 1}; chars_initialize(a, 2, 58); return 0; }
case 110: { char a[4] = {1, 1, 1, 1}; chars_initialize(a, 4, 56); return 0; }
case 111: { char a[16] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}; chars_initialize(a, 16, 36); return 0; }
case 112: { char a[1] = {1}; chars_initialize(a, 1, -105); return 0; }
case 113: { char a[3] = {126, 127, -128}; chars_initialize(a, 3, 75); return 0; }
case 114: { char a[8] = {-128, -127, -1, 0, 1, 65, 126, 127}; chars_initialize(a, 8, -56); return 0; }
case 115: { char a[1] = {0}; chars_initialize(a, 0, 97); return 0; }
case 116: { char a[2] = {65, 127}; chars_initialize(a, 2, 113); return 0; }
case 117: { char a[4] = {1, 0, 126, -127}; chars_initialize(a, 4, 2); return 0; }
case 118: { char a[16] = {-1, -127, 127, 65, 127, 65, -1, 1, -1, 127, 126, 1, 1, -1, -127, 126}; chars_initialize(a, 16, 106); return 0; }
case 119: { char a[1] = {112}; chars_initialize(a, 1, 66); return 0; }
case 120: { char a[8] = {-26, 90, -20, -54, -53, -43, 26, 54}; chars_initialize(a, 8, 87); return 0; }
case 121: { char a[1] = {0}; chars_initialize(a, 0, 21); return 0; }
case 122: { char a[2] = {-128, -128}; chars_initialize(a, 2, 32); return 0; }
case 123: { char a[16] = {-128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128}; chars_initialize(a, 16, 13); return 0; }
case 124: { char a[1] = {-128}; chars_initialize(a, 1, -112); return 0; }
case 125: { char a[3] = {-1, 0, 1}; chars_initialize(a, 3, -77); return 0; }
case 126: { char a[8] = {1, 65, 126, 127, -128, -127, -1, 0}; chars_initialize(a, 8, -8); return 0; }
case 127: { char a[1] = {0}; chars_initialize(a, 0, 123); return 0; }
default: return 13; } }
