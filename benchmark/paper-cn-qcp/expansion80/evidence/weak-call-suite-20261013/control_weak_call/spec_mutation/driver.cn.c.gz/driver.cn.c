void step(int *p, int n)
/*@ requires take v = RW<int>(p); 0 <= n; n <= 3; 0 <= v; v + n <= 100;
    ensures take w = RW<int>(p); v <= w; @*/
{ if (n > 0) { *p = *p + 1; step(p, n - 1); } }
void sample(int *p)
/*@ requires take v = RW<int>(p); 0 <= v; v <= 97;
    ensures take w = RW<int>(p); w == v + 4; @*/
{ step(p, 3); }

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: { int p = 0; sample(&p); return 0; }
case 1: { int p = 1; sample(&p); return 0; }
case 2: { int p = 2; sample(&p); return 0; }
case 3: { int p = 3; sample(&p); return 0; }
case 4: { int p = 4; sample(&p); return 0; }
case 5: { int p = 5; sample(&p); return 0; }
case 6: { int p = 6; sample(&p); return 0; }
case 7: { int p = 7; sample(&p); return 0; }
case 8: { int p = 8; sample(&p); return 0; }
case 9: { int p = 9; sample(&p); return 0; }
case 10: { int p = 10; sample(&p); return 0; }
case 11: { int p = 11; sample(&p); return 0; }
case 12: { int p = 12; sample(&p); return 0; }
case 13: { int p = 13; sample(&p); return 0; }
case 14: { int p = 14; sample(&p); return 0; }
case 15: { int p = 15; sample(&p); return 0; }
case 16: { int p = 16; sample(&p); return 0; }
case 17: { int p = 17; sample(&p); return 0; }
case 18: { int p = 18; sample(&p); return 0; }
case 19: { int p = 19; sample(&p); return 0; }
case 20: { int p = 20; sample(&p); return 0; }
case 21: { int p = 21; sample(&p); return 0; }
case 22: { int p = 22; sample(&p); return 0; }
case 23: { int p = 23; sample(&p); return 0; }
case 24: { int p = 24; sample(&p); return 0; }
case 25: { int p = 25; sample(&p); return 0; }
case 26: { int p = 26; sample(&p); return 0; }
case 27: { int p = 27; sample(&p); return 0; }
case 28: { int p = 28; sample(&p); return 0; }
case 29: { int p = 29; sample(&p); return 0; }
case 30: { int p = 30; sample(&p); return 0; }
case 31: { int p = 31; sample(&p); return 0; }
case 32: { int p = 32; sample(&p); return 0; }
case 33: { int p = 33; sample(&p); return 0; }
case 34: { int p = 34; sample(&p); return 0; }
case 35: { int p = 35; sample(&p); return 0; }
case 36: { int p = 36; sample(&p); return 0; }
case 37: { int p = 37; sample(&p); return 0; }
case 38: { int p = 38; sample(&p); return 0; }
case 39: { int p = 39; sample(&p); return 0; }
case 40: { int p = 40; sample(&p); return 0; }
case 41: { int p = 41; sample(&p); return 0; }
case 42: { int p = 42; sample(&p); return 0; }
case 43: { int p = 43; sample(&p); return 0; }
case 44: { int p = 44; sample(&p); return 0; }
case 45: { int p = 45; sample(&p); return 0; }
case 46: { int p = 46; sample(&p); return 0; }
case 47: { int p = 47; sample(&p); return 0; }
case 48: { int p = 48; sample(&p); return 0; }
case 49: { int p = 49; sample(&p); return 0; }
case 50: { int p = 50; sample(&p); return 0; }
case 51: { int p = 51; sample(&p); return 0; }
case 52: { int p = 52; sample(&p); return 0; }
case 53: { int p = 53; sample(&p); return 0; }
case 54: { int p = 54; sample(&p); return 0; }
case 55: { int p = 55; sample(&p); return 0; }
case 56: { int p = 56; sample(&p); return 0; }
case 57: { int p = 57; sample(&p); return 0; }
case 58: { int p = 58; sample(&p); return 0; }
case 59: { int p = 59; sample(&p); return 0; }
case 60: { int p = 60; sample(&p); return 0; }
case 61: { int p = 61; sample(&p); return 0; }
case 62: { int p = 62; sample(&p); return 0; }
case 63: { int p = 63; sample(&p); return 0; }
case 64: { int p = 64; sample(&p); return 0; }
case 65: { int p = 65; sample(&p); return 0; }
case 66: { int p = 66; sample(&p); return 0; }
case 67: { int p = 67; sample(&p); return 0; }
case 68: { int p = 68; sample(&p); return 0; }
case 69: { int p = 69; sample(&p); return 0; }
case 70: { int p = 70; sample(&p); return 0; }
case 71: { int p = 71; sample(&p); return 0; }
case 72: { int p = 72; sample(&p); return 0; }
case 73: { int p = 73; sample(&p); return 0; }
case 74: { int p = 74; sample(&p); return 0; }
case 75: { int p = 75; sample(&p); return 0; }
case 76: { int p = 76; sample(&p); return 0; }
case 77: { int p = 77; sample(&p); return 0; }
case 78: { int p = 78; sample(&p); return 0; }
case 79: { int p = 79; sample(&p); return 0; }
case 80: { int p = 80; sample(&p); return 0; }
case 81: { int p = 81; sample(&p); return 0; }
case 82: { int p = 82; sample(&p); return 0; }
case 83: { int p = 83; sample(&p); return 0; }
case 84: { int p = 84; sample(&p); return 0; }
case 85: { int p = 85; sample(&p); return 0; }
case 86: { int p = 86; sample(&p); return 0; }
case 87: { int p = 87; sample(&p); return 0; }
case 88: { int p = 88; sample(&p); return 0; }
case 89: { int p = 89; sample(&p); return 0; }
case 90: { int p = 90; sample(&p); return 0; }
case 91: { int p = 91; sample(&p); return 0; }
case 92: { int p = 92; sample(&p); return 0; }
case 93: { int p = 93; sample(&p); return 0; }
case 94: { int p = 94; sample(&p); return 0; }
case 95: { int p = 95; sample(&p); return 0; }
case 96: { int p = 96; sample(&p); return 0; }
case 97: { int p = 97; sample(&p); return 0; }
default: return 13; } }
