/*@
function [rec] (integer) Count(map<integer,integer> a, integer n, integer v) { if(n <= 0) {0} else { if(a[n-1] == v) {1 + Count(a,n-1,v)} else {Count(a,n-1,v)} } }
@*/









int* sortArray(int* nums, int numsSize, int* returnSize) 
/*@ requires 1 <= numsSize; numsSize <= 50000; take A = each(integer i; 0 <= i && i < numsSize) {RW<int>(array_shift<int>(nums,i))}; take R = W<int>(returnSize); ensures take B = each(integer i; 0 <= i && i < numsSize) {RW<int>(array_shift<int>(return,i))}; take R2 = RW<int>(returnSize); R2 == numsSize; each(integer i; 0 <= i && i < numsSize-1) {B[i] <= B[i+1]}; each(integer i; 0 <= i && i < numsSize) {Count(A,numsSize,A[i]) == Count(B,numsSize,A[i])}; each(integer i; 0 <= i && i < numsSize) {Count(A,numsSize,B[i]) == Count(B,numsSize,B[i])}; @*/
{
    *returnSize = numsSize;
    {
    int i;
    
    for (i = 1; i < numsSize; ++i) {
        int key = nums[i];
        int j = i - 1;
        
        while (j >= 0 && nums[j] < key) {
            
            nums[j + 1] = nums[j];
                    
            j--;
        }
        nums[j + 1] = key;
    }
    }
    return nums;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: { int nums[1] = {(-2147483647 - 1)};int returnSize = (-2147483647 - 1); sortArray(nums, 1, &returnSize); return 0; }
case 1: { int nums[2] = {(-2147483647 - 1), (-2147483647 - 1)};int returnSize = -1; sortArray(nums, 2, &returnSize); return 0; }
case 2: { int nums[3] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)};int returnSize = 0; sortArray(nums, 3, &returnSize); return 0; }
case 3: { int nums[4] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)};int returnSize = 1; sortArray(nums, 4, &returnSize); return 0; }
case 4: { int nums[8] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)};int returnSize = 2147483647; sortArray(nums, 8, &returnSize); return 0; }
case 5: { int nums[16] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)};int returnSize = (-2147483647 - 1); sortArray(nums, 16, &returnSize); return 0; }
case 6: { int nums[2] = {0, 0};int returnSize = -1; sortArray(nums, 2, &returnSize); return 0; }
case 7: { int nums[3] = {0, 0, 0};int returnSize = 0; sortArray(nums, 3, &returnSize); return 0; }
case 8: { int nums[4] = {0, 0, 0, 0};int returnSize = 1; sortArray(nums, 4, &returnSize); return 0; }
case 9: { int nums[8] = {0, 0, 0, 0, 0, 0, 0, 0};int returnSize = 2147483647; sortArray(nums, 8, &returnSize); return 0; }
case 10: { int nums[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};int returnSize = (-2147483647 - 1); sortArray(nums, 16, &returnSize); return 0; }
case 11: { int nums[1] = {0};int returnSize = -1; sortArray(nums, 1, &returnSize); return 0; }
case 12: { int nums[3] = {-2, -1, 0};int returnSize = 0; sortArray(nums, 3, &returnSize); return 0; }
case 13: { int nums[4] = {-1, 0, 1, 2};int returnSize = 1; sortArray(nums, 4, &returnSize); return 0; }
case 14: { int nums[8] = {0, 1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647};int returnSize = 2147483647; sortArray(nums, 8, &returnSize); return 0; }
case 15: { int nums[16] = {1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1, 0, 1, 2, 100, 2147483646, 2147483647};int returnSize = (-2147483647 - 1); sortArray(nums, 16, &returnSize); return 0; }
case 16: { int nums[1] = {2};int returnSize = -1; sortArray(nums, 1, &returnSize); return 0; }
case 17: { int nums[2] = {100, 2147483646};int returnSize = 0; sortArray(nums, 2, &returnSize); return 0; }
case 18: { int nums[3] = {2147483646, 2147483647, (-2147483647 - 1)};int returnSize = 1; sortArray(nums, 3, &returnSize); return 0; }
case 19: { int nums[4] = {-100, 1, 2147483646, 2147483647};int returnSize = 2147483647; sortArray(nums, 4, &returnSize); return 0; }
case 20: { int nums[8] = {-2, -1, 0, 1, 1, 2147483646, 2147483646, 2147483646};int returnSize = (-2147483647 - 1); sortArray(nums, 8, &returnSize); return 0; }
case 21: { int nums[16] = {(-2147483647 - 1), (-2147483647 - 1), -2147483647, -2147483647, -100, -100, -100, -2, -1, -1, 1, 1, 2, 2, 100, 2147483646};int returnSize = -1; sortArray(nums, 16, &returnSize); return 0; }
case 22: { int nums[2] = {0, 2};int returnSize = 0; sortArray(nums, 2, &returnSize); return 0; }
case 23: { int nums[3] = {0, 1, 2147483647};int returnSize = 1; sortArray(nums, 3, &returnSize); return 0; }
case 24: { int nums[4] = {-100, 0, 100, 2147483646};int returnSize = 2147483647; sortArray(nums, 4, &returnSize); return 0; }
case 25: { int nums[8] = {-833421548, 1456915023, 806008623, 1368451539, 2087782113, -1845620830, -208350282, -2038743611};int returnSize = (-2147483647 - 1); sortArray(nums, 8, &returnSize); return 0; }
case 26: { int nums[16] = {1309130943, 1950106030, -1271326959, 1466066651, 2136620527, 2081350927, -1979372692, -882356487, 223406556, 617865469, 1266513166, 1114208779, 394273271, 1180827568, 1726544480, 374059776};int returnSize = -1; sortArray(nums, 16, &returnSize); return 0; }
case 27: { int nums[1] = {-662961268};int returnSize = 0; sortArray(nums, 1, &returnSize); return 0; }
case 28: { int nums[2] = {-69631889, 1392402695};int returnSize = 1; sortArray(nums, 2, &returnSize); return 0; }
case 29: { int nums[3] = {924985941, 2095640952, -594437444};int returnSize = 2147483647; sortArray(nums, 3, &returnSize); return 0; }
case 30: { int nums[4] = {423149033, 190991604, 939240215, 2142139567};int returnSize = (-2147483647 - 1); sortArray(nums, 4, &returnSize); return 0; }
case 31: { int nums[8] = {-997193837, -1303128720, -2060693665, 248560309, 1631517721, -210343047, -239065941, -1136420893};int returnSize = -1; sortArray(nums, 8, &returnSize); return 0; }
case 32: { int nums[16] = {-2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647};int returnSize = 0; sortArray(nums, 16, &returnSize); return 0; }
case 33: { int nums[1] = {-2147483647};int returnSize = 1; sortArray(nums, 1, &returnSize); return 0; }
case 34: { int nums[2] = {-2147483647, -2147483647};int returnSize = 2147483647; sortArray(nums, 2, &returnSize); return 0; }
case 35: { int nums[3] = {-2147483647, -2147483647, -2147483647};int returnSize = (-2147483647 - 1); sortArray(nums, 3, &returnSize); return 0; }
case 36: { int nums[4] = {-2147483647, -2147483647, -2147483647, -2147483647};int returnSize = -1; sortArray(nums, 4, &returnSize); return 0; }
case 37: { int nums[8] = {-2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647};int returnSize = 0; sortArray(nums, 8, &returnSize); return 0; }
case 38: { int nums[2] = {0, 1};int returnSize = 1; sortArray(nums, 2, &returnSize); return 0; }
case 39: { int nums[3] = {1, 2, 100};int returnSize = 2147483647; sortArray(nums, 3, &returnSize); return 0; }
case 40: { int nums[4] = {2, 100, 2147483646, 2147483647};int returnSize = (-2147483647 - 1); sortArray(nums, 4, &returnSize); return 0; }
case 41: { int nums[8] = {100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1};int returnSize = -1; sortArray(nums, 8, &returnSize); return 0; }
case 42: { int nums[16] = {2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1, 0, 1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100};int returnSize = 0; sortArray(nums, 16, &returnSize); return 0; }
case 43: { int nums[1] = {2147483647};int returnSize = 1; sortArray(nums, 1, &returnSize); return 0; }
case 44: { int nums[2] = {(-2147483647 - 1), -2147483647};int returnSize = 2147483647; sortArray(nums, 2, &returnSize); return 0; }
case 45: { int nums[3] = {-2, 2, 100};int returnSize = (-2147483647 - 1); sortArray(nums, 3, &returnSize); return 0; }
case 46: { int nums[4] = {(-2147483647 - 1), -2, 1, 2};int returnSize = -1; sortArray(nums, 4, &returnSize); return 0; }
case 47: { int nums[8] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), -100, -1, -1, 0, 1};int returnSize = 0; sortArray(nums, 8, &returnSize); return 0; }
case 48: { int nums[16] = {(-2147483647 - 1), (-2147483647 - 1), -2147483647, -100, -2, -2, -1, 1, 2, 2, 2, 2, 100, 100, 2147483647, 2147483647};int returnSize = 1; sortArray(nums, 16, &returnSize); return 0; }
case 49: { int nums[2] = {0, 100};int returnSize = 2147483647; sortArray(nums, 2, &returnSize); return 0; }
case 50: { int nums[3] = {-2147483647, -100, 2};int returnSize = (-2147483647 - 1); sortArray(nums, 3, &returnSize); return 0; }
case 51: { int nums[4] = {-385745401, -1036584957, -578059497, 701236369};int returnSize = -1; sortArray(nums, 4, &returnSize); return 0; }
case 52: { int nums[8] = {1629498510, -983082501, 992478129, -2085416551, -569155800, -226780370, -1874312103, 2146483821};int returnSize = 0; sortArray(nums, 8, &returnSize); return 0; }
case 53: { int nums[16] = {1863533231, 2065963835, -2034977911, -1693996271, 2024847753, 772856760, 213633940, 1834165143, -648283412, -1822171305, -1436904439, -27507951, 664021708, -1446294794, -1069282466, -200547056};int returnSize = 1; sortArray(nums, 16, &returnSize); return 0; }
case 54: { int nums[1] = {2056106113};int returnSize = 2147483647; sortArray(nums, 1, &returnSize); return 0; }
case 55: { int nums[2] = {2006128915, 1521112263};int returnSize = (-2147483647 - 1); sortArray(nums, 2, &returnSize); return 0; }
case 56: { int nums[3] = {-19994936, 854870091, -557894232};int returnSize = -1; sortArray(nums, 3, &returnSize); return 0; }
case 57: { int nums[4] = {918298044, -208703394, -431630919, 698507150};int returnSize = 0; sortArray(nums, 4, &returnSize); return 0; }
case 58: { int nums[8] = {-100, -100, -100, -100, -100, -100, -100, -100};int returnSize = 1; sortArray(nums, 8, &returnSize); return 0; }
case 59: { int nums[16] = {-100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100};int returnSize = 2147483647; sortArray(nums, 16, &returnSize); return 0; }
case 60: { int nums[1] = {-100};int returnSize = (-2147483647 - 1); sortArray(nums, 1, &returnSize); return 0; }
case 61: { int nums[2] = {-100, -100};int returnSize = -1; sortArray(nums, 2, &returnSize); return 0; }
case 62: { int nums[3] = {-100, -100, -100};int returnSize = 0; sortArray(nums, 3, &returnSize); return 0; }
case 63: { int nums[4] = {-100, -100, -100, -100};int returnSize = 1; sortArray(nums, 4, &returnSize); return 0; }
case 64: { int nums[4] = {2147483647, (-2147483647 - 1), -2147483647, -100};int returnSize = 2147483647; sortArray(nums, 4, &returnSize); return 0; }
case 65: { int nums[8] = {(-2147483647 - 1), -2147483647, -100, -2, -1, 0, 1, 2};int returnSize = (-2147483647 - 1); sortArray(nums, 8, &returnSize); return 0; }
case 66: { int nums[16] = {-2147483647, -100, -2, -1, 0, 1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1, 0};int returnSize = -1; sortArray(nums, 16, &returnSize); return 0; }
case 67: { int nums[2] = {-2147483647, 100};int returnSize = 0; sortArray(nums, 2, &returnSize); return 0; }
case 68: { int nums[3] = {-2, 2, 2};int returnSize = 1; sortArray(nums, 3, &returnSize); return 0; }
case 69: { int nums[4] = {-2147483647, -100, 2147483646, 2147483646};int returnSize = 2147483647; sortArray(nums, 4, &returnSize); return 0; }
case 70: { int nums[8] = {(-2147483647 - 1), (-2147483647 - 1), -2, -1, 0, 2, 2147483646, 2147483647};int returnSize = (-2147483647 - 1); sortArray(nums, 8, &returnSize); return 0; }
case 71: { int nums[16] = {(-2147483647 - 1), -2, -1, -1, -1, 0, 1, 2, 2, 2147483646, 2147483646, 2147483646, 2147483646, 2147483646, 2147483647, 2147483647};int returnSize = -1; sortArray(nums, 16, &returnSize); return 0; }
case 72: { int nums[1] = {2147483646};int returnSize = 0; sortArray(nums, 1, &returnSize); return 0; }
case 73: { int nums[2] = {-100, 2};int returnSize = 1; sortArray(nums, 2, &returnSize); return 0; }
case 74: { int nums[3] = {-2050622355, 114559393, 52264846};int returnSize = 2147483647; sortArray(nums, 3, &returnSize); return 0; }
case 75: { int nums[4] = {1654188971, -1933844997, -1158074238, 1159592373};int returnSize = (-2147483647 - 1); sortArray(nums, 4, &returnSize); return 0; }
case 76: { int nums[8] = {208891740, 1940001134, -1846391616, 1395749025, -509314459, -179718819, -1979051088, -1179049931};int returnSize = -1; sortArray(nums, 8, &returnSize); return 0; }
case 77: { int nums[16] = {1882448808, -548542552, 1208135172, 2067871768, 1808180369, 1562695090, 1736259565, -665934555, -950905118, 1036621963, -595887025, 445292680, -610261274, 1150703960, 149373163, 1367121287};int returnSize = 0; sortArray(nums, 16, &returnSize); return 0; }
case 78: { int nums[1] = {1246671927};int returnSize = 1; sortArray(nums, 1, &returnSize); return 0; }
case 79: { int nums[2] = {2090048509, 155196249};int returnSize = 2147483647; sortArray(nums, 2, &returnSize); return 0; }
case 80: { int nums[3] = {1608653981, -1372233979, -117367611};int returnSize = (-2147483647 - 1); sortArray(nums, 3, &returnSize); return 0; }
case 81: { int nums[4] = {-2, -2, -2, -2};int returnSize = -1; sortArray(nums, 4, &returnSize); return 0; }
case 82: { int nums[8] = {-2, -2, -2, -2, -2, -2, -2, -2};int returnSize = 0; sortArray(nums, 8, &returnSize); return 0; }
case 83: { int nums[16] = {-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2};int returnSize = 1; sortArray(nums, 16, &returnSize); return 0; }
case 84: { int nums[1] = {-2};int returnSize = 2147483647; sortArray(nums, 1, &returnSize); return 0; }
case 85: { int nums[2] = {-2, -2};int returnSize = (-2147483647 - 1); sortArray(nums, 2, &returnSize); return 0; }
case 86: { int nums[3] = {-2, -2, -2};int returnSize = -1; sortArray(nums, 3, &returnSize); return 0; }
case 87: { int nums[3] = {-2147483647, -100, -2};int returnSize = 0; sortArray(nums, 3, &returnSize); return 0; }
case 88: { int nums[4] = {-100, -2, -1, 0};int returnSize = 1; sortArray(nums, 4, &returnSize); return 0; }
case 89: { int nums[8] = {-2, -1, 0, 1, 2, 100, 2147483646, 2147483647};int returnSize = 2147483647; sortArray(nums, 8, &returnSize); return 0; }
case 90: { int nums[16] = {-1, 0, 1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1, 0, 1, 2, 100};int returnSize = (-2147483647 - 1); sortArray(nums, 16, &returnSize); return 0; }
case 91: { int nums[1] = {1};int returnSize = -1; sortArray(nums, 1, &returnSize); return 0; }
case 92: { int nums[2] = {-2147483647, 0};int returnSize = 0; sortArray(nums, 2, &returnSize); return 0; }
case 93: { int nums[3] = {-2147483647, 1, 2};int returnSize = 1; sortArray(nums, 3, &returnSize); return 0; }
case 94: { int nums[4] = {2, 2, 2147483647, 2147483647};int returnSize = 2147483647; sortArray(nums, 4, &returnSize); return 0; }
case 95: { int nums[8] = {(-2147483647 - 1), -100, 0, 0, 1, 2, 2, 2147483646};int returnSize = (-2147483647 - 1); sortArray(nums, 8, &returnSize); return 0; }
case 96: { int nums[16] = {(-2147483647 - 1), -2147483647, -2147483647, -100, -100, -1, 0, 0, 0, 0, 2, 2, 100, 100, 2147483646, 2147483647};int returnSize = -1; sortArray(nums, 16, &returnSize); return 0; }
case 97: { int nums[2] = {-152320547, -291012452};int returnSize = 0; sortArray(nums, 2, &returnSize); return 0; }
case 98: { int nums[3] = {-1848074038, 663289720, 815642197};int returnSize = 1; sortArray(nums, 3, &returnSize); return 0; }
case 99: { int nums[4] = {-46694898, 1298010804, 1192953353, 224166788};int returnSize = 2147483647; sortArray(nums, 4, &returnSize); return 0; }
case 100: { int nums[8] = {-1599344655, 683818026, -219468548, 67120118, 385534353, 645458742, -1353089488, -1752403606};int returnSize = (-2147483647 - 1); sortArray(nums, 8, &returnSize); return 0; }
case 101: { int nums[16] = {-114207157, -462996215, 1142464526, 105842754, -206473950, 1868606285, -757973160, -1296226354, -1096721974, -1913204401, -710416124, -2010564886, 1952723005, -428826563, 1100648095, 1222722771};int returnSize = -1; sortArray(nums, 16, &returnSize); return 0; }
case 102: { int nums[1] = {-637351359};int returnSize = 0; sortArray(nums, 1, &returnSize); return 0; }
case 103: { int nums[2] = {605155675, 1853301338};int returnSize = 1; sortArray(nums, 2, &returnSize); return 0; }
case 104: { int nums[3] = {-1, -1, -1};int returnSize = 2147483647; sortArray(nums, 3, &returnSize); return 0; }
case 105: { int nums[4] = {-1, -1, -1, -1};int returnSize = (-2147483647 - 1); sortArray(nums, 4, &returnSize); return 0; }
case 106: { int nums[8] = {-1, -1, -1, -1, -1, -1, -1, -1};int returnSize = -1; sortArray(nums, 8, &returnSize); return 0; }
case 107: { int nums[16] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};int returnSize = 0; sortArray(nums, 16, &returnSize); return 0; }
case 108: { int nums[1] = {-1};int returnSize = 1; sortArray(nums, 1, &returnSize); return 0; }
case 109: { int nums[2] = {-1, -1};int returnSize = 2147483647; sortArray(nums, 2, &returnSize); return 0; }
case 110: { int nums[2] = {-2, -1};int returnSize = (-2147483647 - 1); sortArray(nums, 2, &returnSize); return 0; }
case 111: { int nums[3] = {-1, 0, 1};int returnSize = -1; sortArray(nums, 3, &returnSize); return 0; }
case 112: { int nums[4] = {0, 1, 2, 100};int returnSize = 0; sortArray(nums, 4, &returnSize); return 0; }
case 113: { int nums[8] = {1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100};int returnSize = 1; sortArray(nums, 8, &returnSize); return 0; }
case 114: { int nums[16] = {(-2147483647 - 1), -2147483647, -2147483647, -2, -1, -1, -1, -1, 0, 1, 1, 100, 100, 2147483646, 2147483647, 2147483647};int returnSize = 2147483647; sortArray(nums, 16, &returnSize); return 0; }
case 115: { int nums[2] = {(-2147483647 - 1), 2147483647};int returnSize = (-2147483647 - 1); sortArray(nums, 2, &returnSize); return 0; }
case 116: { int nums[3] = {2, 2, 2147483646};int returnSize = -1; sortArray(nums, 3, &returnSize); return 0; }
case 117: { int nums[4] = {(-2147483647 - 1), -2147483647, -2, 2147483647};int returnSize = 0; sortArray(nums, 4, &returnSize); return 0; }
case 118: { int nums[8] = {-100, -2, 0, 2, 100, 100, 2147483646, 2147483647};int returnSize = 1; sortArray(nums, 8, &returnSize); return 0; }
case 119: { int nums[16] = {-2147483647, -2147483647, -2147483647, -2, -1, -1, 0, 0, 1, 1, 1, 2, 2, 100, 100, 2147483647};int returnSize = 2147483647; sortArray(nums, 16, &returnSize); return 0; }
case 120: { int nums[1] = {1095855425};int returnSize = (-2147483647 - 1); sortArray(nums, 1, &returnSize); return 0; }
case 121: { int nums[2] = {-1153444952, -316466477};int returnSize = -1; sortArray(nums, 2, &returnSize); return 0; }
case 122: { int nums[3] = {-1522895720, 852710999, 2084105685};int returnSize = 0; sortArray(nums, 3, &returnSize); return 0; }
case 123: { int nums[4] = {233137520, -337062465, -1172095830, -268479557};int returnSize = 1; sortArray(nums, 4, &returnSize); return 0; }
case 124: { int nums[8] = {-780427405, -1460333914, -1839703333, -680640243, -2005772941, -499696307, -1586496354, 1852105981};int returnSize = 2147483647; sortArray(nums, 8, &returnSize); return 0; }
case 125: { int nums[16] = {-1426678154, -1891207262, 787790455, -1472570231, -327449500, -1612594943, 1182243097, -246558382, 34658714, 1953417002, 1377651849, -1837035599, -2115529950, -248841112, 1169399141, -1880465423};int returnSize = (-2147483647 - 1); sortArray(nums, 16, &returnSize); return 0; }
case 126: { int nums[1] = {668639790};int returnSize = -1; sortArray(nums, 1, &returnSize); return 0; }
case 127: { int nums[2] = {1, 2};int returnSize = 0; sortArray(nums, 2, &returnSize); return 0; }
default: return 13; } }
