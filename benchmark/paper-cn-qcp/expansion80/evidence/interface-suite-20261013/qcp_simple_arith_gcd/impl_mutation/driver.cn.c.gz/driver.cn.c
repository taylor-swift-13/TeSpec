/*@
function (integer) Abs(integer x) { if(x < 0) {0-x} else {x} }
function [rec] (integer) Gcd(integer x, integer y) { if(y == 0) {Abs(x)} else {Gcd(y,mod(x,y))} }
@*/




int abs(int x)
  /*@ requires -2147483648 < x; x <= 2147483647; ensures return == Abs(x); @*/
{ return x < 0 ? -x : x; }

int gcd(int x, int y)
  /*@ requires -2147483648 < x; -2147483648 < y; ensures return == Gcd(x,y); @*/
{
  
  if (y == 0)
  {
    return 0;
  }
  else {
    return gcd(y, x % y);
  }
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: {  gcd(-2147483647, -2147483647); return 0; }
case 1: {  gcd(-2147483647, 0); return 0; }
case 2: {  gcd(-2147483647, 4); return 0; }
case 3: {  gcd(-2147483647, 2004); return 0; }
case 4: {  gcd(-2147483646, -1); return 0; }
case 5: {  gcd(-2147483646, 401); return 0; }
case 6: {  gcd(-2110186328, -221699471); return 0; }
case 7: {  gcd(-2038743610, -316644389); return 0; }
case 8: {  gcd(-2037664568, -340361174); return 0; }
case 9: {  gcd(-1980710354, 861311842); return 0; }
case 10: {  gcd(-1979372691, -1213984677); return 0; }
case 11: {  gcd(-1950330302, -955749167); return 0; }
case 12: {  gcd(-1949621354, -223504605); return 0; }
case 13: {  gcd(-1918129190, -1129535666); return 0; }
case 14: {  gcd(-1845620829, -121626300); return 0; }
case 15: {  gcd(-1836311903, -1134903170); return 0; }
case 16: {  gcd(-1836311903, 1134903170); return 0; }
case 17: {  gcd(-1831128049, -2067095786); return 0; }
case 18: {  gcd(-1730959948, -365177302); return 0; }
case 19: {  gcd(-1707355838, 438915215); return 0; }
case 20: {  gcd(-1698718697, -1074058733); return 0; }
case 21: {  gcd(-1549562208, 741862624); return 0; }
case 22: {  gcd(-1526126833, -1766727061); return 0; }
case 23: {  gcd(-1489931729, -1946947052); return 0; }
case 24: {  gcd(-1316976608, -739058469); return 0; }
case 25: {  gcd(-1301003035, -1153350430); return 0; }
case 26: {  gcd(-1284518891, -206899814); return 0; }
case 27: {  gcd(-1271326958, -539259347); return 0; }
case 28: {  gcd(-1212037343, -1198357267); return 0; }
case 29: {  gcd(-1197286770, 942451683); return 0; }
case 30: {  gcd(-1184215427, -1372959570); return 0; }
case 31: {  gcd(-1134903170, -701408733); return 0; }
case 32: {  gcd(-1134903170, 701408733); return 0; }
case 33: {  gcd(-882356486, -1481156918); return 0; }
case 34: {  gcd(-873709126, 963810147); return 0; }
case 35: {  gcd(-833421547, -2103008459); return 0; }
case 36: {  gcd(-749478675, -442817131); return 0; }
case 37: {  gcd(-740083939, -937046351); return 0; }
case 38: {  gcd(-689467812, -128663419); return 0; }
case 39: {  gcd(-662961267, -151324928); return 0; }
case 40: {  gcd(-599425079, -415021519); return 0; }
case 41: {  gcd(-465499377, -1639313220); return 0; }
case 42: {  gcd(-448650160, -1099156846); return 0; }
case 43: {  gcd(-355125031, 1099693634); return 0; }
case 44: {  gcd(-349117697, -1136564613); return 0; }
case 45: {  gcd(-295441906, -180236359); return 0; }
case 46: {  gcd(-208350281, -1540296869); return 0; }
case 47: {  gcd(-168916291, -1855923309); return 0; }
case 48: {  gcd(-168262939, -1522440576); return 0; }
case 49: {  gcd(-107942483, -106392810); return 0; }
case 50: {  gcd(-89557788, -1842281489); return 0; }
case 51: {  gcd(-69631888, -502702747); return 0; }
case 52: {  gcd(-45479319, 977826321); return 0; }
case 53: {  gcd(-400, -2147483646); return 0; }
case 54: {  gcd(-400, 10); return 0; }
case 55: {  gcd(-400, 2400); return 0; }
case 56: {  gcd(-100, -75); return 0; }
case 57: {  gcd(-100, 0); return 0; }
case 58: {  gcd(-100, 75); return 0; }
case 59: {  gcd(-100, 1600); return 0; }
case 60: {  gcd(-10, -100); return 0; }
case 61: {  gcd(-10, 100); return 0; }
case 62: {  gcd(-10, 2147483646); return 0; }
case 63: {  gcd(-2, 2); return 0; }
case 64: {  gcd(-2, 2000); return 0; }
case 65: {  gcd(-1, -10); return 0; }
case 66: {  gcd(-1, 1); return 0; }
case 67: {  gcd(-1, 400); return 0; }
case 68: {  gcd(0, -2147483647); return 0; }
case 69: {  gcd(0, 0); return 0; }
case 70: {  gcd(0, 4); return 0; }
case 71: {  gcd(0, 2004); return 0; }
case 72: {  gcd(0, 2147483647); return 0; }
case 73: {  gcd(1, -1); return 0; }
case 74: {  gcd(1, 800); return 0; }
case 75: {  gcd(2, -2147483646); return 0; }
case 76: {  gcd(2, 10); return 0; }
case 77: {  gcd(2, 2400); return 0; }
case 78: {  gcd(4, 0); return 0; }
case 79: {  gcd(4, 1600); return 0; }
case 80: {  gcd(9, -100); return 0; }
case 81: {  gcd(9, 399); return 0; }
case 82: {  gcd(9, 2147483646); return 0; }
case 83: {  gcd(10, 2); return 0; }
case 84: {  gcd(10, 2000); return 0; }
case 85: {  gcd(100, -75); return 0; }
case 86: {  gcd(100, -10); return 0; }
case 87: {  gcd(100, 75); return 0; }
case 88: {  gcd(100, 400); return 0; }
case 89: {  gcd(399, -2147483647); return 0; }
case 90: {  gcd(399, 9); return 0; }
case 91: {  gcd(399, 2004); return 0; }
case 92: {  gcd(400, -1); return 0; }
case 93: {  gcd(400, 800); return 0; }
case 94: {  gcd(401, -2147483646); return 0; }
case 95: {  gcd(401, 10); return 0; }
case 96: {  gcd(401, 2400); return 0; }
case 97: {  gcd(800, 1); return 0; }
case 98: {  gcd(800, 1600); return 0; }
case 99: {  gcd(1600, -100); return 0; }
case 100: {  gcd(1600, 399); return 0; }
case 101: {  gcd(1600, 2147483646); return 0; }
case 102: {  gcd(1900, 2); return 0; }
case 103: {  gcd(1900, 2000); return 0; }
case 104: {  gcd(2000, -2); return 0; }
case 105: {  gcd(2000, 400); return 0; }
case 106: {  gcd(2004, -2147483647); return 0; }
case 107: {  gcd(2004, 9); return 0; }
case 108: {  gcd(2004, 2004); return 0; }
case 109: {  gcd(2100, -1); return 0; }
case 110: {  gcd(2100, 800); return 0; }
case 111: {  gcd(2400, -400); return 0; }
case 112: {  gcd(2400, 10); return 0; }
case 113: {  gcd(2400, 2400); return 0; }
case 114: {  gcd(155785653, 1007131359); return 0; }
case 115: {  gcd(368336629, 1667271381); return 0; }
case 116: {  gcd(429543934, -1593755615); return 0; }
case 117: {  gcd(473873329, -184096501); return 0; }
case 118: {  gcd(527778287, 508004983); return 0; }
case 119: {  gcd(725305261, 1841413407); return 0; }
case 120: {  gcd(792890726, 17306666); return 0; }
case 121: {  gcd(820045723, 168570368); return 0; }
case 122: {  gcd(1134903170, -701408733); return 0; }
case 123: {  gcd(1134903170, 701408733); return 0; }
case 124: {  gcd(1283912124, 1439628960); return 0; }
case 125: {  gcd(1836311903, -1134903170); return 0; }
case 126: {  gcd(1836311903, 1134903170); return 0; }
case 127: {  gcd(2147483647, 2147483647); return 0; }
default: return 13; } }
