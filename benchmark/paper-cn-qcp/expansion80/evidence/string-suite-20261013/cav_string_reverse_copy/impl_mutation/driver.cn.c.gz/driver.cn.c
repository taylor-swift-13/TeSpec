void string_reverse_copy(int n, char *src, char *dst)
/*@ requires 0 <= n; n < 2147483647; take S = each(integer i; 0 <= i && i <= n) {RW<char>(array_shift<char>(src,i))}; take D = each(integer i; 0 <= i && i <= n) {RW<char>(array_shift<char>(dst,i))}; S[n] == 0; each(integer i; 0 <= i && i < n) {S[i] != 0}; ensures take S2 = each(integer i; 0 <= i && i <= n) {RW<char>(array_shift<char>(src,i))}; take D2 = each(integer i; 0 <= i && i <= n) {RW<char>(array_shift<char>(dst,i))}; S2 == S; D2[n] == 0; each(integer i; 0 <= i && i < n) {D2[i] == S[n-1-i]}; @*/
{
    int i;

    for (i = 0; i < n; ++i) {
        dst[i] = src[n - 1 - i];
    }
    dst[n] = 1;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: { char src[1] = {0}; char dst[1] = {106}; string_reverse_copy(0, src, dst); return 0; }
case 1: { char src[2] = {-128, 0}; char dst[2] = {-29, 39}; string_reverse_copy(1, src, dst); return 0; }
case 2: { char src[3] = {-128, -128, 0}; char dst[3] = {114, -79, 84}; string_reverse_copy(2, src, dst); return 0; }
case 3: { char src[4] = {-128, -128, -128, 0}; char dst[4] = {-101, -7, -91, -119}; string_reverse_copy(3, src, dst); return 0; }
case 4: { char src[5] = {-128, -128, -128, -128, 0}; char dst[5] = {-15, -75, -1, -62, -26}; string_reverse_copy(4, src, dst); return 0; }
case 5: { char src[9] = {-128, -128, -128, -128, -128, -128, -128, -128, 0}; char dst[9] = {103, 122, -50, -105, -57, -14, -36, 38, 75}; string_reverse_copy(8, src, dst); return 0; }
case 6: { char src[17] = {-128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, 0}; char dst[17] = {85, 45, 112, 115, 115, 92, 106, 74, -4, 28, -123, -53, 86, -8, -76, -105, 101}; string_reverse_copy(16, src, dst); return 0; }
case 7: { char src[1] = {0}; char dst[1] = {-93}; string_reverse_copy(0, src, dst); return 0; }
case 8: { char src[2] = {90, 0}; char dst[2] = {113, 103}; string_reverse_copy(1, src, dst); return 0; }
case 9: { char src[3] = {96, 97, 0}; char dst[3] = {-56, -116, 90}; string_reverse_copy(2, src, dst); return 0; }
case 10: { char src[4] = {97, 98, 121, 0}; char dst[4] = {-115, 87, -24, 63}; string_reverse_copy(3, src, dst); return 0; }
case 11: { char src[5] = {98, 121, 122, 123, 0}; char dst[5] = {-28, -10, -109, 117, -92}; string_reverse_copy(4, src, dst); return 0; }
case 12: { char src[9] = {121, 122, 123, 126, 127, -128, -127, -1, 0}; char dst[9] = {23, -108, -17, 22, -49, 107, -54, 56, 78}; string_reverse_copy(8, src, dst); return 0; }
case 13: { char src[17] = {122, 123, 126, 127, -128, -127, -1, 1, 9, 32, 64, 65, 90, 96, 97, 98, 0}; char dst[17] = {-54, -83, -124, 101, -30, 107, -94, 72, -68, 101, 39, 16, 48, 109, 119, 68, -105}; string_reverse_copy(16, src, dst); return 0; }
case 14: { char src[1] = {0}; char dst[1] = {14}; string_reverse_copy(0, src, dst); return 0; }
case 15: { char src[2] = {122, 0}; char dst[2] = {-17, -15}; string_reverse_copy(1, src, dst); return 0; }
case 16: { char src[3] = {64, 123, 0}; char dst[3] = {12, 5, -41}; string_reverse_copy(2, src, dst); return 0; }
case 17: { char src[4] = {96, 127, 97, 0}; char dst[4] = {9, -28, -10, 39}; string_reverse_copy(3, src, dst); return 0; }
case 18: { char src[5] = {126, 1, 123, 122, 0}; char dst[5] = {-65, 39, -86, 15, 102}; string_reverse_copy(4, src, dst); return 0; }
case 19: { char src[9] = {64, 96, -1, 64, 97, -1, 32, 65, 0}; char dst[9] = {-121, 42, -27, -87, 67, 60, -116, -89, 84}; string_reverse_copy(8, src, dst); return 0; }
case 20: { char src[17] = {-127, 90, 126, 98, 1, 127, -1, 97, 98, 96, 64, -128, 32, -128, 122, 122, 0}; char dst[17] = {18, -1, -13, -34, 91, -74, -76, 82, 77, 41, 4, -42, 59, -5, -35, -75, 110}; string_reverse_copy(16, src, dst); return 0; }
case 21: { char src[1] = {0}; char dst[1] = {10}; string_reverse_copy(0, src, dst); return 0; }
case 22: { char src[2] = {1, 0}; char dst[2] = {-113, 30}; string_reverse_copy(1, src, dst); return 0; }
case 23: { char src[3] = {1, 1, 0}; char dst[3] = {-121, 84, 60}; string_reverse_copy(2, src, dst); return 0; }
case 24: { char src[4] = {1, 1, 1, 0}; char dst[4] = {-112, -4, -96, 100}; string_reverse_copy(3, src, dst); return 0; }
case 25: { char src[5] = {1, 1, 1, 1, 0}; char dst[5] = {27, -45, 117, 124, 28}; string_reverse_copy(4, src, dst); return 0; }
case 26: { char src[9] = {1, 1, 1, 1, 1, 1, 1, 1, 0}; char dst[9] = {-90, -96, -95, -112, -77, -111, -107, -115, 107}; string_reverse_copy(8, src, dst); return 0; }
case 27: { char src[17] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0}; char dst[17] = {-74, 24, 111, 57, 35, -62, 46, 126, 50, 96, -90, 65, -44, 121, 16, 124, -1}; string_reverse_copy(16, src, dst); return 0; }
case 28: { char src[1] = {0}; char dst[1] = {20}; string_reverse_copy(0, src, dst); return 0; }
case 29: { char src[2] = {121, 0}; char dst[2] = {-45, -35}; string_reverse_copy(1, src, dst); return 0; }
case 30: { char src[3] = {122, 123, 0}; char dst[3] = {0, 5, 104}; string_reverse_copy(2, src, dst); return 0; }
case 31: { char src[4] = {123, 126, 127, 0}; char dst[4] = {39, -65, -106, 24}; string_reverse_copy(3, src, dst); return 0; }
case 32: { char src[5] = {126, 127, -128, -127, 0}; char dst[5] = {89, 125, 50, -29, 71}; string_reverse_copy(4, src, dst); return 0; }
case 33: { char src[9] = {127, -128, -127, -1, 1, 9, 32, 64, 0}; char dst[9] = {37, -117, 61, 28, -15, 103, -46, 76, 78}; string_reverse_copy(8, src, dst); return 0; }
case 34: { char src[17] = {-128, -127, -1, 1, 9, 32, 64, 65, 90, 96, 97, 98, 121, 122, 123, 126, 0}; char dst[17] = {117, -44, 34, 11, 90, -66, -1, 67, -92, 112, 96, -100, -105, 37, -121, -109, 115}; string_reverse_copy(16, src, dst); return 0; }
case 35: { char src[1] = {0}; char dst[1] = {-67}; string_reverse_copy(0, src, dst); return 0; }
case 36: { char src[2] = {32, 0}; char dst[2] = {15, 93}; string_reverse_copy(1, src, dst); return 0; }
case 37: { char src[3] = {90, 32, 0}; char dst[3] = {-114, 64, 58}; string_reverse_copy(2, src, dst); return 0; }
case 38: { char src[4] = {-1, 64, 122, 0}; char dst[4] = {103, -117, -52, 40}; string_reverse_copy(3, src, dst); return 0; }
case 39: { char src[5] = {90, 126, -128, 1, 0}; char dst[5] = {97, 75, -122, 56, -35}; string_reverse_copy(4, src, dst); return 0; }
case 40: { char src[9] = {-127, -1, 123, 122, 64, 65, 96, 97, 0}; char dst[9] = {-108, -87, -13, -16, -7, 16, 62, -96, -81}; string_reverse_copy(8, src, dst); return 0; }
case 41: { char src[17] = {127, 126, 123, 126, 32, 9, 121, 98, 64, 126, 97, 121, 64, 64, 9, 98, 0}; char dst[17] = {101, 89, 96, 34, 6, -127, -117, -36, -52, 114, 120, -43, 116, -106, -58, -98, 88}; string_reverse_copy(16, src, dst); return 0; }
case 42: { char src[1] = {0}; char dst[1] = {-37}; string_reverse_copy(0, src, dst); return 0; }
case 43: { char src[2] = {64, 0}; char dst[2] = {-109, 75}; string_reverse_copy(1, src, dst); return 0; }
case 44: { char src[3] = {64, 64, 0}; char dst[3] = {-32, 86, -110}; string_reverse_copy(2, src, dst); return 0; }
case 45: { char src[4] = {64, 64, 64, 0}; char dst[4] = {114, -53, 13, -36}; string_reverse_copy(3, src, dst); return 0; }
case 46: { char src[5] = {64, 64, 64, 64, 0}; char dst[5] = {-121, 42, 31, 126, -24}; string_reverse_copy(4, src, dst); return 0; }
case 47: { char src[9] = {64, 64, 64, 64, 64, 64, 64, 64, 0}; char dst[9] = {-65, 104, -57, 89, 0, 61, -127, 117, -45}; string_reverse_copy(8, src, dst); return 0; }
case 48: { char src[17] = {64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 0}; char dst[17] = {-72, 115, -5, -22, 92, 109, 65, 93, 61, -93, -72, -76, 59, 122, 107, 7, -34}; string_reverse_copy(16, src, dst); return 0; }
case 49: { char src[1] = {0}; char dst[1] = {53}; string_reverse_copy(0, src, dst); return 0; }
case 50: { char src[2] = {127, 0}; char dst[2] = {-28, -22}; string_reverse_copy(1, src, dst); return 0; }
case 51: { char src[3] = {-128, -127, 0}; char dst[3] = {51, -63, -9}; string_reverse_copy(2, src, dst); return 0; }
case 52: { char src[4] = {-127, -1, 1, 0}; char dst[4] = {-36, 56, -110, 101}; string_reverse_copy(3, src, dst); return 0; }
case 53: { char src[5] = {-1, 1, 9, 32, 0}; char dst[5] = {69, 41, 78, -68, -93}; string_reverse_copy(4, src, dst); return 0; }
case 54: { char src[9] = {1, 9, 32, 64, 65, 90, 96, 97, 0}; char dst[9] = {84, 41, -100, -34, -55, -81, 102, -33, 114}; string_reverse_copy(8, src, dst); return 0; }
case 55: { char src[17] = {9, 32, 64, 65, 90, 96, 97, 98, 121, 122, 123, 126, 127, -128, -127, -1, 0}; char dst[17] = {12, 72, -10, 123, 50, -117, -124, 103, 88, -121, 37, -121, -27, 113, -3, 111, -91}; string_reverse_copy(16, src, dst); return 0; }
case 56: { char src[1] = {0}; char dst[1] = {-101}; string_reverse_copy(0, src, dst); return 0; }
case 57: { char src[2] = {64, 0}; char dst[2] = {42, 43}; string_reverse_copy(1, src, dst); return 0; }
case 58: { char src[3] = {-127, -1, 0}; char dst[3] = {60, 76, -118}; string_reverse_copy(2, src, dst); return 0; }
case 59: { char src[4] = {121, 122, 32, 0}; char dst[4] = {58, 56, 36, -105}; string_reverse_copy(3, src, dst); return 0; }
case 60: { char src[5] = {64, 98, 127, 98, 0}; char dst[5] = {113, -117, -90, 22, 104}; string_reverse_copy(4, src, dst); return 0; }
case 61: { char src[9] = {64, 64, 64, -127, -1, -128, 127, 121, 0}; char dst[9] = {47, -92, -70, 49, 89, -58, 114, -54, -20}; string_reverse_copy(8, src, dst); return 0; }
case 62: { char src[17] = {98, 64, 90, 9, 127, 122, 96, 96, 32, -1, 122, 65, 98, 121, 64, 127, 0}; char dst[17] = {121, -54, -113, -41, 76, 103, 84, 29, -10, -26, 90, -20, -54, -53, -43, 26, 54}; string_reverse_copy(16, src, dst); return 0; }
case 63: { char src[1] = {0}; char dst[1] = {87}; string_reverse_copy(0, src, dst); return 0; }
case 64: { char src[2] = {96, 0}; char dst[2] = {-3, -41}; string_reverse_copy(1, src, dst); return 0; }
case 65: { char src[3] = {96, 96, 0}; char dst[3] = {-12, -48, 19}; string_reverse_copy(2, src, dst); return 0; }
case 66: { char src[4] = {96, 96, 96, 0}; char dst[4] = {95, -16, -103, 34}; string_reverse_copy(3, src, dst); return 0; }
case 67: { char src[5] = {96, 96, 96, 96, 0}; char dst[5] = {1, 96, -51, -119, -47}; string_reverse_copy(4, src, dst); return 0; }
case 68: { char src[9] = {96, 96, 96, 96, 96, 96, 96, 96, 0}; char dst[9] = {116, -92, 21, 32, 46, 13, -112, -77, -8}; string_reverse_copy(8, src, dst); return 0; }
case 69: { char src[17] = {96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 0}; char dst[17] = {123, -117, 80, 68, -55, -62, 118, -79, -43, 56, -98, -75, -22, -87, -48, -100, 73}; string_reverse_copy(16, src, dst); return 0; }
case 70: { char src[1] = {0}; char dst[1] = {88}; string_reverse_copy(0, src, dst); return 0; }
case 71: { char src[2] = {1, 0}; char dst[2] = {-60, -65}; string_reverse_copy(1, src, dst); return 0; }
case 72: { char src[3] = {9, 32, 0}; char dst[3] = {47, 47, 98}; string_reverse_copy(2, src, dst); return 0; }
case 73: { char src[4] = {32, 64, 65, 0}; char dst[4] = {-88, -31, 100, -58}; string_reverse_copy(3, src, dst); return 0; }
case 74: { char src[5] = {64, 65, 90, 96, 0}; char dst[5] = {-111, 125, -91, -54, -125}; string_reverse_copy(4, src, dst); return 0; }
case 75: { char src[9] = {65, 90, 96, 97, 98, 121, 122, 123, 0}; char dst[9] = {-74, 78, 102, 98, 94, 40, -108, -75, 31}; string_reverse_copy(8, src, dst); return 0; }
case 76: { char src[17] = {90, 96, 97, 98, 121, 122, 123, 126, 127, -128, -127, -1, 1, 9, 32, 64, 0}; char dst[17] = {-97, 21, 110, 31, 19, 55, -61, 121, -67, 14, -75, 87, -46, 26, 0, -128, 83}; string_reverse_copy(16, src, dst); return 0; }
case 77: { char src[1] = {0}; char dst[1] = {18}; string_reverse_copy(0, src, dst); return 0; }
case 78: { char src[2] = {90, 0}; char dst[2] = {83, 87}; string_reverse_copy(1, src, dst); return 0; }
case 79: { char src[3] = {32, 32, 0}; char dst[3] = {-81, 84, 106}; string_reverse_copy(2, src, dst); return 0; }
case 80: { char src[4] = {121, 9, 96, 0}; char dst[4] = {52, -20, 76, -32}; string_reverse_copy(3, src, dst); return 0; }
case 81: { char src[5] = {127, 96, 1, -127, 0}; char dst[5] = {21, 117, 82, -102, 58}; string_reverse_copy(4, src, dst); return 0; }
case 82: { char src[9] = {90, 126, 64, 121, -127, 122, -127, -128, 0}; char dst[9] = {-103, -44, 112, -45, 21, 126, 50, -123, -54}; string_reverse_copy(8, src, dst); return 0; }
case 83: { char src[17] = {90, 9, -127, 97, 96, -128, -1, 9, 127, 98, 90, -1, 1, 126, 123, 121, 0}; char dst[17] = {101, 79, -115, 52, 17, 84, 126, -55, 9, -65, 99, -26, 10, 96, 50, 7, -96}; string_reverse_copy(16, src, dst); return 0; }
case 84: { char src[1] = {0}; char dst[1] = {107}; string_reverse_copy(0, src, dst); return 0; }
case 85: { char src[2] = {121, 0}; char dst[2] = {-60, 54}; string_reverse_copy(1, src, dst); return 0; }
case 86: { char src[3] = {121, 121, 0}; char dst[3] = {81, 42, -30}; string_reverse_copy(2, src, dst); return 0; }
case 87: { char src[4] = {121, 121, 121, 0}; char dst[4] = {-26, 47, 5, -49}; string_reverse_copy(3, src, dst); return 0; }
case 88: { char src[5] = {121, 121, 121, 121, 0}; char dst[5] = {-55, 67, 69, 68, 102}; string_reverse_copy(4, src, dst); return 0; }
case 89: { char src[9] = {121, 121, 121, 121, 121, 121, 121, 121, 0}; char dst[9] = {-60, 76, -42, 124, -100, -65, 94, 36, -91}; string_reverse_copy(8, src, dst); return 0; }
case 90: { char src[17] = {121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 0}; char dst[17] = {31, -66, -2, 21, -51, -95, -119, 47, 109, -64, 57, 21, -92, 10, -123, 41, -57}; string_reverse_copy(16, src, dst); return 0; }
case 91: { char src[1] = {0}; char dst[1] = {-118}; string_reverse_copy(0, src, dst); return 0; }
case 92: { char src[2] = {65, 0}; char dst[2] = {20, 56}; string_reverse_copy(1, src, dst); return 0; }
case 93: { char src[3] = {90, 96, 0}; char dst[3] = {-24, 127, -96}; string_reverse_copy(2, src, dst); return 0; }
case 94: { char src[4] = {96, 97, 98, 0}; char dst[4] = {62, 74, -32, -27}; string_reverse_copy(3, src, dst); return 0; }
case 95: { char src[5] = {97, 98, 121, 122, 0}; char dst[5] = {-52, -126, 0, 113, -65}; string_reverse_copy(4, src, dst); return 0; }
case 96: { char src[9] = {98, 121, 122, 123, 126, 127, -128, -127, 0}; char dst[9] = {67, 31, 33, 106, -94, 113, -101, 0, 122}; string_reverse_copy(8, src, dst); return 0; }
case 97: { char src[17] = {121, 122, 123, 126, 127, -128, -127, -1, 1, 9, 32, 64, 65, 90, 96, 97, 0}; char dst[17] = {-59, -76, -94, 61, -85, 28, 77, -109, 40, -56, -87, -77, 5, -4, 107, -34, 98}; string_reverse_copy(16, src, dst); return 0; }
case 98: { char src[1] = {0}; char dst[1] = {8}; string_reverse_copy(0, src, dst); return 0; }
case 99: { char src[2] = {64, 0}; char dst[2] = {-117, 84}; string_reverse_copy(1, src, dst); return 0; }
case 100: { char src[3] = {-127, -127, 0}; char dst[3] = {-121, 86, 95}; string_reverse_copy(2, src, dst); return 0; }
case 101: { char src[4] = {123, 127, -127, 0}; char dst[4] = {-28, -23, 11, -56}; string_reverse_copy(3, src, dst); return 0; }
case 102: { char src[5] = {97, 32, 64, 123, 0}; char dst[5] = {81, -68, -33, 10, -12}; string_reverse_copy(4, src, dst); return 0; }
case 103: { char src[9] = {32, 126, 65, 127, 90, -127, -127, 123, 0}; char dst[9] = {-2, 41, -2, -68, -15, -40, -100, 59, 99}; string_reverse_copy(8, src, dst); return 0; }
case 104: { char src[17] = {-127, 96, 126, 122, 123, 96, -1, -1, 32, 32, 96, 122, 65, 65, -128, 64, 0}; char dst[17] = {121, 38, -114, -121, -106, -7, -127, 42, 48, -70, -25, -57, 96, 19, -23, 65, 77}; string_reverse_copy(16, src, dst); return 0; }
case 105: { char src[1] = {0}; char dst[1] = {68}; string_reverse_copy(0, src, dst); return 0; }
case 106: { char src[2] = {126, 0}; char dst[2] = {-32, 63}; string_reverse_copy(1, src, dst); return 0; }
case 107: { char src[3] = {126, 126, 0}; char dst[3] = {114, 72, 108}; string_reverse_copy(2, src, dst); return 0; }
case 108: { char src[4] = {126, 126, 126, 0}; char dst[4] = {11, 102, 89, 17}; string_reverse_copy(3, src, dst); return 0; }
case 109: { char src[5] = {126, 126, 126, 126, 0}; char dst[5] = {-41, 34, 27, 62, 27}; string_reverse_copy(4, src, dst); return 0; }
case 110: { char src[9] = {126, 126, 126, 126, 126, 126, 126, 126, 0}; char dst[9] = {38, -45, 95, -113, -86, 64, 1, -47, 33}; string_reverse_copy(8, src, dst); return 0; }
case 111: { char src[17] = {126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 0}; char dst[17] = {-11, 14, 75, -14, 60, -38, 92, 56, 69, -60, -84, 79, -127, -111, 66, 42, 29}; string_reverse_copy(16, src, dst); return 0; }
case 112: { char src[1] = {0}; char dst[1] = {93}; string_reverse_copy(0, src, dst); return 0; }
case 113: { char src[2] = {98, 0}; char dst[2] = {-127, 42}; string_reverse_copy(1, src, dst); return 0; }
case 114: { char src[3] = {121, 122, 0}; char dst[3] = {-15, -39, -39}; string_reverse_copy(2, src, dst); return 0; }
case 115: { char src[4] = {122, 123, 126, 0}; char dst[4] = {-12, -43, 36, -123}; string_reverse_copy(3, src, dst); return 0; }
case 116: { char src[5] = {123, 126, 127, -128, 0}; char dst[5] = {36, -60, -47, -59, -21}; string_reverse_copy(4, src, dst); return 0; }
case 117: { char src[9] = {126, 127, -128, -127, -1, 1, 9, 32, 0}; char dst[9] = {-74, -4, -65, -116, -112, -79, -18, -34, 112}; string_reverse_copy(8, src, dst); return 0; }
case 118: { char src[17] = {127, -128, -127, -1, 1, 9, 32, 64, 65, 90, 96, 97, 98, 121, 122, 123, 0}; char dst[17] = {122, 13, 62, -78, 89, -16, 83, 92, 77, 60, -50, 51, 30, 89, -45, 105, 121}; string_reverse_copy(16, src, dst); return 0; }
case 119: { char src[1] = {0}; char dst[1] = {75}; string_reverse_copy(0, src, dst); return 0; }
case 120: { char src[2] = {98, 0}; char dst[2] = {-119, -9}; string_reverse_copy(1, src, dst); return 0; }
case 121: { char src[3] = {98, 123, 0}; char dst[3] = {-47, 87, 11}; string_reverse_copy(2, src, dst); return 0; }
case 122: { char src[4] = {96, 9, 64, 0}; char dst[4] = {64, -66, -78, -87}; string_reverse_copy(3, src, dst); return 0; }
case 123: { char src[5] = {127, -128, 123, 97, 0}; char dst[5] = {-12, -37, 61, 7, -57}; string_reverse_copy(4, src, dst); return 0; }
case 124: { char src[9] = {96, -128, 64, 32, -1, 123, -127, 64, 0}; char dst[9] = {116, 62, 91, 31, 105, 71, -111, -68, 114}; string_reverse_copy(8, src, dst); return 0; }
case 125: { char src[17] = {97, 97, 127, -127, 1, 126, 65, 121, 127, 65, -127, -127, 97, 32, -127, 90, 0}; char dst[17] = {102, -22, 7, -111, -18, -6, -125, 43, 14, 35, 38, -110, 67, -6, -122, -81, -105}; string_reverse_copy(16, src, dst); return 0; }
case 126: { char src[1] = {0}; char dst[1] = {34}; string_reverse_copy(0, src, dst); return 0; }
case 127: { char src[2] = {-127, 0}; char dst[2] = {29, 24}; string_reverse_copy(1, src, dst); return 0; }
default: return 13; } }
