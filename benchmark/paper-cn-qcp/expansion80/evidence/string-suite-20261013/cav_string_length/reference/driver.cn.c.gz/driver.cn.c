int algo_string_length(char *s)
/*@ requires cn_ghost integer n; 0 <= n; n < 2147483647; take A = each(integer i; 0 <= i && i <= n) {RW<char>(array_shift<char>(s,i))}; A[n] == 0; each(integer k; 0 <= k && k < n) {A[k] != 0}; ensures take B = each(integer i; 0 <= i && i <= n) {RW<char>(array_shift<char>(s,i))}; B == A; return == n; @*/
{
    int i = 0;

    while (1) {
        if (s[i] == 0) {
            break;
        }
        i++;
    }

    return i;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar();
if (index == 0) { char s[1] = {0}; algo_string_length(s /*@ 0 @*/); return 0; }
if (index == 1) { char s[2] = {-128, 0}; algo_string_length(s /*@ 1 @*/); return 0; }
if (index == 2) { char s[3] = {-128, -128, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 3) { char s[4] = {-128, -128, -128, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 4) { char s[5] = {-128, -128, -128, -128, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 5) { char s[9] = {-128, -128, -128, -128, -128, -128, -128, -128, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 6) { char s[17] = {-128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 7) { char s[2] = {90, 0}; algo_string_length(s /*@ 1 @*/); return 0; }
if (index == 8) { char s[3] = {96, 97, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 9) { char s[4] = {97, 98, 121, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 10) { char s[5] = {98, 121, 122, 123, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 11) { char s[9] = {121, 122, 123, 126, 127, -128, -127, -1, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 12) { char s[17] = {122, 123, 126, 127, -128, -127, -1, 1, 9, 32, 64, 65, 90, 96, 97, 98, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 13) { char s[2] = {97, 0}; algo_string_length(s /*@ 1 @*/); return 0; }
if (index == 14) { char s[3] = {1, 123, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 15) { char s[4] = {126, 32, 90, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 16) { char s[5] = {65, 97, 97, 123, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 17) { char s[9] = {123, 123, -127, 1, 121, 123, -127, 9, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 18) { char s[17] = {-1, 65, 121, -128, 98, 1, 96, 97, 32, 65, 98, 121, 65, 126, 96, 90, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 19) { char s[2] = {1, 0}; algo_string_length(s /*@ 1 @*/); return 0; }
if (index == 20) { char s[3] = {1, 1, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 21) { char s[4] = {1, 1, 1, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 22) { char s[5] = {1, 1, 1, 1, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 23) { char s[9] = {1, 1, 1, 1, 1, 1, 1, 1, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 24) { char s[17] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 25) { char s[2] = {121, 0}; algo_string_length(s /*@ 1 @*/); return 0; }
if (index == 26) { char s[3] = {122, 123, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 27) { char s[4] = {123, 126, 127, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 28) { char s[5] = {126, 127, -128, -127, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 29) { char s[9] = {127, -128, -127, -1, 1, 9, 32, 64, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 30) { char s[17] = {-128, -127, -1, 1, 9, 32, 64, 65, 90, 96, 97, 98, 121, 122, 123, 126, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 31) { char s[2] = {65, 0}; algo_string_length(s /*@ 1 @*/); return 0; }
if (index == 32) { char s[3] = {126, 9, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 33) { char s[4] = {121, 32, 123, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 34) { char s[5] = {98, 122, -127, 97, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 35) { char s[9] = {-128, 127, 98, -127, 127, 65, 127, -128, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 36) { char s[17] = {126, 122, 127, 1, 1, 126, 123, -128, 127, 127, 32, -128, 32, 90, 65, -1, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 37) { char s[2] = {64, 0}; algo_string_length(s /*@ 1 @*/); return 0; }
if (index == 38) { char s[3] = {64, 64, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 39) { char s[4] = {64, 64, 64, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 40) { char s[5] = {64, 64, 64, 64, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 41) { char s[9] = {64, 64, 64, 64, 64, 64, 64, 64, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 42) { char s[17] = {64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 43) { char s[2] = {127, 0}; algo_string_length(s /*@ 1 @*/); return 0; }
if (index == 44) { char s[3] = {-128, -127, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 45) { char s[4] = {-127, -1, 1, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 46) { char s[5] = {-1, 1, 9, 32, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 47) { char s[9] = {1, 9, 32, 64, 65, 90, 96, 97, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 48) { char s[17] = {9, 32, 64, 65, 90, 96, 97, 98, 121, 122, 123, 126, 127, -128, -127, -1, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 49) { char s[2] = {96, 0}; algo_string_length(s /*@ 1 @*/); return 0; }
if (index == 50) { char s[3] = {64, 123, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 51) { char s[4] = {-1, 97, 98, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 52) { char s[5] = {98, 97, 97, -128, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 53) { char s[9] = {65, 1, 122, 121, 96, 97, 122, 126, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 54) { char s[17] = {127, 96, 9, 90, 32, 90, 123, 98, 9, 121, 126, 127, 64, 123, 123, 97, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 55) { char s[3] = {96, 96, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 56) { char s[4] = {96, 96, 96, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 57) { char s[5] = {96, 96, 96, 96, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 58) { char s[9] = {96, 96, 96, 96, 96, 96, 96, 96, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 59) { char s[17] = {96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 60) { char s[3] = {9, 32, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 61) { char s[4] = {32, 64, 65, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 62) { char s[5] = {64, 65, 90, 96, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 63) { char s[9] = {65, 90, 96, 97, 98, 121, 122, 123, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 64) { char s[17] = {90, 96, 97, 98, 121, 122, 123, 126, 127, -128, -127, -1, 1, 9, 32, 64, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 65) { char s[3] = {96, 121, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 66) { char s[4] = {96, 127, 97, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 67) { char s[5] = {126, 126, 98, 9, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 68) { char s[9] = {1, 97, 32, 1, 1, 98, -128, 32, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 69) { char s[17] = {96, 123, 65, 64, 65, 9, 64, 122, 98, 32, 98, -128, 97, 97, 1, 64, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 70) { char s[3] = {121, 121, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 71) { char s[4] = {121, 121, 121, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 72) { char s[5] = {121, 121, 121, 121, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 73) { char s[9] = {121, 121, 121, 121, 121, 121, 121, 121, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 74) { char s[17] = {121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 75) { char s[3] = {90, 96, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 76) { char s[4] = {96, 97, 98, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 77) { char s[5] = {97, 98, 121, 122, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 78) { char s[9] = {98, 121, 122, 123, 126, 127, -128, -127, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 79) { char s[17] = {121, 122, 123, 126, 127, -128, -127, -1, 1, 9, 32, 64, 65, 90, 96, 97, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 80) { char s[4] = {-127, 90, 126, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 81) { char s[5] = {98, 1, 127, -1, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 82) { char s[9] = {97, 98, 96, 64, -128, 32, -128, 122, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 83) { char s[17] = {122, 9, 98, 126, 96, 121, 1, 98, -127, 126, 127, -127, 90, 64, 32, 9, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 84) { char s[2] = {126, 0}; algo_string_length(s /*@ 1 @*/); return 0; }
if (index == 85) { char s[3] = {126, 126, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 86) { char s[4] = {126, 126, 126, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 87) { char s[5] = {126, 126, 126, 126, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 88) { char s[9] = {126, 126, 126, 126, 126, 126, 126, 126, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 89) { char s[17] = {126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 90) { char s[2] = {98, 0}; algo_string_length(s /*@ 1 @*/); return 0; }
if (index == 91) { char s[3] = {121, 122, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 92) { char s[4] = {122, 123, 126, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 93) { char s[5] = {123, 126, 127, -128, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 94) { char s[9] = {126, 127, -128, -127, -1, 1, 9, 32, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 95) { char s[17] = {127, -128, -127, -1, 1, 9, 32, 64, 65, 90, 96, 97, 98, 121, 122, 123, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 96) { char s[3] = {127, 98, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 97) { char s[4] = {98, 123, 97, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 98) { char s[5] = {65, 9, 121, -128, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 99) { char s[9] = {64, 9, -127, 65, -1, 90, 90, 90, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 100) { char s[17] = {32, -127, -127, -128, 96, 127, 97, 127, 126, 127, -128, 96, -127, 65, 127, 32, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 101) { char s[2] = {-127, 0}; algo_string_length(s /*@ 1 @*/); return 0; }
if (index == 102) { char s[3] = {-127, -127, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 103) { char s[4] = {-127, -127, -127, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 104) { char s[5] = {-127, -127, -127, -127, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 105) { char s[9] = {-127, -127, -127, -127, -127, -127, -127, -127, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 106) { char s[17] = {-127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 107) { char s[3] = {127, -128, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 108) { char s[4] = {-128, -127, -1, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 109) { char s[5] = {-127, -1, 1, 9, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 110) { char s[9] = {-1, 1, 9, 32, 64, 65, 90, 96, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 111) { char s[17] = {1, 9, 32, 64, 65, 90, 96, 97, 98, 121, 122, 123, 126, 127, -128, -127, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 112) { char s[3] = {98, 98, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 113) { char s[4] = {96, 126, 32, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 114) { char s[5] = {127, -127, -1, 126, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 115) { char s[9] = {9, 98, 122, 90, 98, -1, 122, 9, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 116) { char s[17] = {65, 127, -128, 127, 123, 126, 126, 90, 1, 98, 98, 32, -128, 64, 126, 121, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 117) { char s[2] = {9, 0}; algo_string_length(s /*@ 1 @*/); return 0; }
if (index == 118) { char s[3] = {9, 9, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 119) { char s[4] = {9, 9, 9, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 120) { char s[5] = {9, 9, 9, 9, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 121) { char s[9] = {9, 9, 9, 9, 9, 9, 9, 9, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
if (index == 122) { char s[17] = {9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 0}; algo_string_length(s /*@ 16 @*/); return 0; }
if (index == 123) { char s[2] = {-1, 0}; algo_string_length(s /*@ 1 @*/); return 0; }
if (index == 124) { char s[3] = {1, 9, 0}; algo_string_length(s /*@ 2 @*/); return 0; }
if (index == 125) { char s[4] = {9, 32, 64, 0}; algo_string_length(s /*@ 3 @*/); return 0; }
if (index == 126) { char s[5] = {32, 64, 65, 90, 0}; algo_string_length(s /*@ 4 @*/); return 0; }
if (index == 127) { char s[9] = {64, 65, 90, 96, 97, 98, 121, 122, 0}; algo_string_length(s /*@ 8 @*/); return 0; }
return 13; }
