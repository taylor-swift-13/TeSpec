/*@
function [rec] (integer) Same(map<integer,integer> a, map<integer,integer> b, integer n) { if(n <= 0) {1} else { if(a[n-1] == b[n-1]) {Same(a,b,n-1)} else {0} } }
@*/
int string_equal(char *a, char *b)
/*@ requires cn_ghost integer na, integer nb; 0 <= na; na < 2147483647; 0 <= nb; nb < 2147483647; take A = each(integer i; 0 <= i && i <= na) {RW<char>(array_shift<char>(a,i))}; take B = each(integer i; 0 <= i && i <= nb) {RW<char>(array_shift<char>(b,i))}; A[na] == 0; B[nb] == 0; each(integer i; 0 <= i && i < na) {A[i] != 0}; each(integer i; 0 <= i && i < nb) {B[i] != 0}; ensures take A2 = each(integer i; 0 <= i && i <= na) {RW<char>(array_shift<char>(a,i))}; take B2 = each(integer i; 0 <= i && i <= nb) {RW<char>(array_shift<char>(b,i))}; A2 == A; B2 == B; (return == 1 && na == nb && Same(A,B,na) == 1) || (return == 0 && (na != nb || Same(A,B,na) == 0)); @*/
{
    int i = 0;

    while (1) {
        if (a[i] == 0) {
            break;
        }
        if (b[i] == 0) {
            break;
        }
        if (a[i] != b[i]) {
            return 1;
        }
        i++;
    }

    if (a[i] == 0 && b[i] == 0) {
        return 1;
    }
    return 0;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar();
if (index == 0) { char a[1] = {0}; char b[1] = {0}; string_equal(a, b /*@ 0, 0 @*/); return 0; }
if (index == 1) { char a[2] = {-128, 0}; char b[2] = {-128, 0}; string_equal(a, b /*@ 1, 1 @*/); return 0; }
if (index == 2) { char a[3] = {-128, -128, 0}; char b[3] = {-128, -128, 0}; string_equal(a, b /*@ 2, 2 @*/); return 0; }
if (index == 3) { char a[4] = {-128, -128, -128, 0}; char b[4] = {-128, -128, -128, 0}; string_equal(a, b /*@ 3, 3 @*/); return 0; }
if (index == 4) { char a[5] = {-128, -128, -128, -128, 0}; char b[5] = {-128, -128, -128, -128, 0}; string_equal(a, b /*@ 4, 4 @*/); return 0; }
if (index == 5) { char a[9] = {-128, -128, -128, -128, -128, -128, -128, -128, 0}; char b[9] = {-128, -128, -128, -128, -128, -128, -128, -128, 0}; string_equal(a, b /*@ 8, 8 @*/); return 0; }
if (index == 6) { char a[17] = {-128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, 0}; char b[17] = {-128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, 0}; string_equal(a, b /*@ 16, 16 @*/); return 0; }
if (index == 7) { char a[2] = {90, 0}; char b[2] = {-128, 0}; string_equal(a, b /*@ 1, 1 @*/); return 0; }
if (index == 8) { char a[3] = {96, 97, 0}; char b[3] = {-128, 97, 0}; string_equal(a, b /*@ 2, 2 @*/); return 0; }
if (index == 9) { char a[4] = {97, 98, 121, 0}; char b[4] = {-128, 98, 121, 0}; string_equal(a, b /*@ 3, 3 @*/); return 0; }
if (index == 10) { char a[5] = {98, 121, 122, 123, 0}; char b[5] = {-128, 121, 122, 123, 0}; string_equal(a, b /*@ 4, 4 @*/); return 0; }
if (index == 11) { char a[9] = {121, 122, 123, 126, 127, -128, -127, -1, 0}; char b[9] = {-128, 122, 123, 126, 127, -128, -127, -1, 0}; string_equal(a, b /*@ 8, 8 @*/); return 0; }
if (index == 12) { char a[17] = {122, 123, 126, 127, -128, -127, -1, 1, 9, 32, 64, 65, 90, 96, 97, 98, 0}; char b[17] = {-128, 123, 126, 127, -128, -127, -1, 1, 9, 32, 64, 65, 90, 96, 97, 98, 0}; string_equal(a, b /*@ 16, 16 @*/); return 0; }
if (index == 13) { char a[1] = {0}; char b[2] = {123, 0}; string_equal(a, b /*@ 0, 1 @*/); return 0; }
if (index == 14) { char a[2] = {1, 0}; char b[3] = {1, 97, 0}; string_equal(a, b /*@ 1, 2 @*/); return 0; }
if (index == 15) { char a[3] = {127, -127, 0}; char b[4] = {127, -127, -127, 0}; string_equal(a, b /*@ 2, 3 @*/); return 0; }
if (index == 16) { char a[4] = {123, 123, 123, 0}; char b[5] = {123, 123, 123, -1, 0}; string_equal(a, b /*@ 3, 4 @*/); return 0; }
if (index == 17) { char a[5] = {-128, 121, 96, 96, 0}; char b[6] = {-128, 121, 96, 96, 65, 0}; string_equal(a, b /*@ 4, 5 @*/); return 0; }
if (index == 18) { char a[9] = {97, 1, 90, -1, -1, 98, 1, 126, 0}; char b[10] = {97, 1, 90, -1, -1, 98, 1, 126, 97, 0}; string_equal(a, b /*@ 8, 9 @*/); return 0; }
if (index == 19) { char a[17] = {64, 121, 32, 121, 122, 97, 90, 65, 127, 64, 126, 122, -128, -1, 65, 9, 0}; char b[18] = {64, 121, 32, 121, 122, 97, 90, 65, 127, 64, 126, 122, -128, -1, 65, 9, -127, 0}; string_equal(a, b /*@ 16, 17 @*/); return 0; }
if (index == 20) { char a[2] = {1, 0}; char b[2] = {-128, 0}; string_equal(a, b /*@ 1, 1 @*/); return 0; }
if (index == 21) { char a[3] = {1, 1, 0}; char b[3] = {1, -128, 0}; string_equal(a, b /*@ 2, 2 @*/); return 0; }
if (index == 22) { char a[4] = {1, 1, 1, 0}; char b[4] = {1, 1, -128, 0}; string_equal(a, b /*@ 3, 3 @*/); return 0; }
if (index == 23) { char a[5] = {1, 1, 1, 1, 0}; char b[5] = {1, 1, 1, -128, 0}; string_equal(a, b /*@ 4, 4 @*/); return 0; }
if (index == 24) { char a[9] = {1, 1, 1, 1, 1, 1, 1, 1, 0}; char b[9] = {1, 1, 1, 1, 1, 1, 1, -128, 0}; string_equal(a, b /*@ 8, 8 @*/); return 0; }
if (index == 25) { char a[17] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0}; char b[17] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -128, 0}; string_equal(a, b /*@ 16, 16 @*/); return 0; }
if (index == 26) { char a[2] = {121, 0}; char b[2] = {121, 0}; string_equal(a, b /*@ 1, 1 @*/); return 0; }
if (index == 27) { char a[3] = {122, 123, 0}; char b[3] = {122, 123, 0}; string_equal(a, b /*@ 2, 2 @*/); return 0; }
if (index == 28) { char a[4] = {123, 126, 127, 0}; char b[4] = {123, 126, 127, 0}; string_equal(a, b /*@ 3, 3 @*/); return 0; }
if (index == 29) { char a[5] = {126, 127, -128, -127, 0}; char b[5] = {126, 127, -128, -127, 0}; string_equal(a, b /*@ 4, 4 @*/); return 0; }
if (index == 30) { char a[9] = {127, -128, -127, -1, 1, 9, 32, 64, 0}; char b[9] = {127, -128, -127, -1, 1, 9, 32, 64, 0}; string_equal(a, b /*@ 8, 8 @*/); return 0; }
if (index == 31) { char a[17] = {-128, -127, -1, 1, 9, 32, 64, 65, 90, 96, 97, 98, 121, 122, 123, 126, 0}; char b[17] = {-128, -127, -1, 1, 9, 32, 64, 65, 90, 96, 97, 98, 121, 122, 123, 126, 0}; string_equal(a, b /*@ 16, 16 @*/); return 0; }
if (index == 32) { char a[2] = {97, 0}; char b[2] = {-128, 0}; string_equal(a, b /*@ 1, 1 @*/); return 0; }
if (index == 33) { char a[3] = {65, 126, 0}; char b[3] = {-128, 126, 0}; string_equal(a, b /*@ 2, 2 @*/); return 0; }
if (index == 34) { char a[4] = {90, 96, -1, 0}; char b[4] = {-128, 96, -1, 0}; string_equal(a, b /*@ 3, 3 @*/); return 0; }
if (index == 35) { char a[5] = {90, 65, 122, -128, 0}; char b[5] = {-128, 65, 122, -128, 0}; string_equal(a, b /*@ 4, 4 @*/); return 0; }
if (index == 36) { char a[9] = {65, 64, 123, 123, 1, 98, 90, -127, 0}; char b[9] = {-128, 64, 123, 123, 1, 98, 90, -127, 0}; string_equal(a, b /*@ 8, 8 @*/); return 0; }
if (index == 37) { char a[17] = {121, 1, -1, 123, 121, 122, 64, 122, 121, 123, -127, 96, 96, 126, 98, 121, 0}; char b[17] = {-128, 1, -1, 123, 121, 122, 64, 122, 121, 123, -127, 96, 96, 126, 98, 121, 0}; string_equal(a, b /*@ 16, 16 @*/); return 0; }
if (index == 38) { char a[1] = {0}; char b[2] = {64, 0}; string_equal(a, b /*@ 0, 1 @*/); return 0; }
if (index == 39) { char a[2] = {64, 0}; char b[3] = {64, 123, 0}; string_equal(a, b /*@ 1, 2 @*/); return 0; }
if (index == 40) { char a[3] = {64, 64, 0}; char b[4] = {64, 64, -1, 0}; string_equal(a, b /*@ 2, 3 @*/); return 0; }
if (index == 41) { char a[4] = {64, 64, 64, 0}; char b[5] = {64, 64, 64, 121, 0}; string_equal(a, b /*@ 3, 4 @*/); return 0; }
if (index == 42) { char a[5] = {64, 64, 64, 64, 0}; char b[6] = {64, 64, 64, 64, 1, 0}; string_equal(a, b /*@ 4, 5 @*/); return 0; }
if (index == 43) { char a[9] = {64, 64, 64, 64, 64, 64, 64, 64, 0}; char b[10] = {64, 64, 64, 64, 64, 64, 64, 64, 123, 0}; string_equal(a, b /*@ 8, 9 @*/); return 0; }
if (index == 44) { char a[17] = {64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 0}; char b[18] = {64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 97, 0}; string_equal(a, b /*@ 16, 17 @*/); return 0; }
if (index == 45) { char a[2] = {127, 0}; char b[2] = {-128, 0}; string_equal(a, b /*@ 1, 1 @*/); return 0; }
if (index == 46) { char a[3] = {-128, -127, 0}; char b[3] = {-128, -128, 0}; string_equal(a, b /*@ 2, 2 @*/); return 0; }
if (index == 47) { char a[4] = {-127, -1, 1, 0}; char b[4] = {-127, -1, -128, 0}; string_equal(a, b /*@ 3, 3 @*/); return 0; }
if (index == 48) { char a[5] = {-1, 1, 9, 32, 0}; char b[5] = {-1, 1, 9, -128, 0}; string_equal(a, b /*@ 4, 4 @*/); return 0; }
if (index == 49) { char a[9] = {1, 9, 32, 64, 65, 90, 96, 97, 0}; char b[9] = {1, 9, 32, 64, 65, 90, 96, -128, 0}; string_equal(a, b /*@ 8, 8 @*/); return 0; }
if (index == 50) { char a[17] = {9, 32, 64, 65, 90, 96, 97, 98, 121, 122, 123, 126, 127, -128, -127, -1, 0}; char b[17] = {9, 32, 64, 65, 90, 96, 97, 98, 121, 122, 123, 126, 127, -128, -127, -128, 0}; string_equal(a, b /*@ 16, 16 @*/); return 0; }
if (index == 51) { char a[2] = {9, 0}; char b[2] = {9, 0}; string_equal(a, b /*@ 1, 1 @*/); return 0; }
if (index == 52) { char a[3] = {90, 32, 0}; char b[3] = {90, 32, 0}; string_equal(a, b /*@ 2, 2 @*/); return 0; }
if (index == 53) { char a[4] = {90, 123, 98, 0}; char b[4] = {90, 123, 98, 0}; string_equal(a, b /*@ 3, 3 @*/); return 0; }
if (index == 54) { char a[5] = {9, 121, 126, 127, 0}; char b[5] = {9, 121, 126, 127, 0}; string_equal(a, b /*@ 4, 4 @*/); return 0; }
if (index == 55) { char a[9] = {64, 123, 123, 97, 121, 96, 121, 96, 0}; char b[9] = {64, 123, 123, 97, 121, 96, 121, 96, 0}; string_equal(a, b /*@ 8, 8 @*/); return 0; }
if (index == 56) { char a[17] = {127, 97, 126, 126, 98, 9, 1, 97, 32, 1, 1, 98, -128, 32, 96, 123, 0}; char b[17] = {127, 97, 126, 126, 98, 9, 1, 97, 32, 1, 1, 98, -128, 32, 96, 123, 0}; string_equal(a, b /*@ 16, 16 @*/); return 0; }
if (index == 57) { char a[2] = {96, 0}; char b[2] = {-128, 0}; string_equal(a, b /*@ 1, 1 @*/); return 0; }
if (index == 58) { char a[3] = {96, 96, 0}; char b[3] = {-128, 96, 0}; string_equal(a, b /*@ 2, 2 @*/); return 0; }
if (index == 59) { char a[4] = {96, 96, 96, 0}; char b[4] = {-128, 96, 96, 0}; string_equal(a, b /*@ 3, 3 @*/); return 0; }
if (index == 60) { char a[5] = {96, 96, 96, 96, 0}; char b[5] = {-128, 96, 96, 96, 0}; string_equal(a, b /*@ 4, 4 @*/); return 0; }
if (index == 61) { char a[9] = {96, 96, 96, 96, 96, 96, 96, 96, 0}; char b[9] = {-128, 96, 96, 96, 96, 96, 96, 96, 0}; string_equal(a, b /*@ 8, 8 @*/); return 0; }
if (index == 62) { char a[17] = {96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 0}; char b[17] = {-128, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 0}; string_equal(a, b /*@ 16, 16 @*/); return 0; }
if (index == 63) { char a[2] = {1, 0}; char b[3] = {1, 121, 0}; string_equal(a, b /*@ 1, 2 @*/); return 0; }
if (index == 64) { char a[3] = {9, 32, 0}; char b[4] = {9, 32, 98, 0}; string_equal(a, b /*@ 2, 3 @*/); return 0; }
if (index == 65) { char a[4] = {32, 64, 65, 0}; char b[5] = {32, 64, 65, 123, 0}; string_equal(a, b /*@ 3, 4 @*/); return 0; }
if (index == 66) { char a[5] = {64, 65, 90, 96, 0}; char b[6] = {64, 65, 90, 96, 32, 0}; string_equal(a, b /*@ 4, 5 @*/); return 0; }
if (index == 67) { char a[9] = {65, 90, 96, 97, 98, 121, 122, 123, 0}; char b[10] = {65, 90, 96, 97, 98, 121, 122, 123, 65, 0}; string_equal(a, b /*@ 8, 9 @*/); return 0; }
if (index == 68) { char a[17] = {90, 96, 97, 98, 121, 122, 123, 126, 127, -128, -127, -1, 1, 9, 32, 64, 0}; char b[18] = {90, 96, 97, 98, 121, 122, 123, 126, 127, -128, -127, -1, 1, 9, 32, 64, 98, 0}; string_equal(a, b /*@ 16, 17 @*/); return 0; }
if (index == 69) { char a[2] = {64, 0}; char b[2] = {-128, 0}; string_equal(a, b /*@ 1, 1 @*/); return 0; }
if (index == 70) { char a[3] = {122, 98, 0}; char b[3] = {122, -128, 0}; string_equal(a, b /*@ 2, 2 @*/); return 0; }
if (index == 71) { char a[4] = {32, 98, -128, 0}; char b[4] = {32, 98, -127, 0}; string_equal(a, b /*@ 3, 3 @*/); return 0; }
if (index == 72) { char a[5] = {97, 97, 1, 64, 0}; char b[5] = {97, 97, 1, -128, 0}; string_equal(a, b /*@ 4, 4 @*/); return 0; }
if (index == 73) { char a[9] = {64, -128, -127, -127, 90, 126, 98, 1, 0}; char b[9] = {64, -128, -127, -127, 90, 126, 98, -128, 0}; string_equal(a, b /*@ 8, 8 @*/); return 0; }
if (index == 74) { char a[17] = {127, -1, 97, 98, 96, 64, -128, 32, -128, 122, 122, 9, 98, 126, 96, 121, 0}; char b[17] = {127, -1, 97, 98, 96, 64, -128, 32, -128, 122, 122, 9, 98, 126, 96, -128, 0}; string_equal(a, b /*@ 16, 16 @*/); return 0; }
if (index == 75) { char a[3] = {121, 121, 0}; char b[3] = {121, 121, 0}; string_equal(a, b /*@ 2, 2 @*/); return 0; }
if (index == 76) { char a[4] = {121, 121, 121, 0}; char b[4] = {121, 121, 121, 0}; string_equal(a, b /*@ 3, 3 @*/); return 0; }
if (index == 77) { char a[5] = {121, 121, 121, 121, 0}; char b[5] = {121, 121, 121, 121, 0}; string_equal(a, b /*@ 4, 4 @*/); return 0; }
if (index == 78) { char a[9] = {121, 121, 121, 121, 121, 121, 121, 121, 0}; char b[9] = {121, 121, 121, 121, 121, 121, 121, 121, 0}; string_equal(a, b /*@ 8, 8 @*/); return 0; }
if (index == 79) { char a[17] = {121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 0}; char b[17] = {121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 0}; string_equal(a, b /*@ 16, 16 @*/); return 0; }
if (index == 80) { char a[2] = {65, 0}; char b[2] = {-128, 0}; string_equal(a, b /*@ 1, 1 @*/); return 0; }
if (index == 81) { char a[3] = {90, 96, 0}; char b[3] = {-128, 96, 0}; string_equal(a, b /*@ 2, 2 @*/); return 0; }
if (index == 82) { char a[4] = {96, 97, 98, 0}; char b[4] = {-128, 97, 98, 0}; string_equal(a, b /*@ 3, 3 @*/); return 0; }
if (index == 83) { char a[5] = {97, 98, 121, 122, 0}; char b[5] = {-128, 98, 121, 122, 0}; string_equal(a, b /*@ 4, 4 @*/); return 0; }
if (index == 84) { char a[9] = {98, 121, 122, 123, 126, 127, -128, -127, 0}; char b[9] = {-128, 121, 122, 123, 126, 127, -128, -127, 0}; string_equal(a, b /*@ 8, 8 @*/); return 0; }
if (index == 85) { char a[17] = {121, 122, 123, 126, 127, -128, -127, -1, 1, 9, 32, 64, 65, 90, 96, 97, 0}; char b[17] = {-128, 122, 123, 126, 127, -128, -127, -1, 1, 9, 32, 64, 65, 90, 96, 97, 0}; string_equal(a, b /*@ 16, 16 @*/); return 0; }
if (index == 86) { char a[1] = {0}; char b[2] = {32, 0}; string_equal(a, b /*@ 0, 1 @*/); return 0; }
if (index == 87) { char a[2] = {65, 0}; char b[3] = {65, 1, 0}; string_equal(a, b /*@ 1, 2 @*/); return 0; }
if (index == 88) { char a[3] = {122, 122, 0}; char b[4] = {122, 122, 1, 0}; string_equal(a, b /*@ 2, 3 @*/); return 0; }
if (index == 89) { char a[4] = {97, 123, 64, 0}; char b[5] = {97, 123, 64, 90, 0}; string_equal(a, b /*@ 3, 4 @*/); return 0; }
if (index == 90) { char a[5] = {-1, 9, 122, 1, 0}; char b[6] = {-1, 9, 122, 1, 127, 0}; string_equal(a, b /*@ 4, 5 @*/); return 0; }
if (index == 91) { char a[9] = {123, 97, 65, 9, 121, -128, 64, 9, 0}; char b[10] = {123, 97, 65, 9, 121, -128, 64, 9, -1, 0}; string_equal(a, b /*@ 8, 9 @*/); return 0; }
if (index == 92) { char a[17] = {121, 32, 127, 126, 123, 126, 127, 123, -127, 127, 98, 127, 97, -127, -128, -128, 0}; char b[18] = {121, 32, 127, 126, 123, 126, 127, 123, -127, 127, 98, 127, 97, -127, -128, -128, 123, 0}; string_equal(a, b /*@ 16, 17 @*/); return 0; }
if (index == 93) { char a[2] = {126, 0}; char b[2] = {-128, 0}; string_equal(a, b /*@ 1, 1 @*/); return 0; }
if (index == 94) { char a[3] = {126, 126, 0}; char b[3] = {126, -128, 0}; string_equal(a, b /*@ 2, 2 @*/); return 0; }
if (index == 95) { char a[4] = {126, 126, 126, 0}; char b[4] = {126, 126, -128, 0}; string_equal(a, b /*@ 3, 3 @*/); return 0; }
if (index == 96) { char a[5] = {126, 126, 126, 126, 0}; char b[5] = {126, 126, 126, -128, 0}; string_equal(a, b /*@ 4, 4 @*/); return 0; }
if (index == 97) { char a[9] = {126, 126, 126, 126, 126, 126, 126, 126, 0}; char b[9] = {126, 126, 126, 126, 126, 126, 126, -128, 0}; string_equal(a, b /*@ 8, 8 @*/); return 0; }
if (index == 98) { char a[17] = {126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 0}; char b[17] = {126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, -128, 0}; string_equal(a, b /*@ 16, 16 @*/); return 0; }
if (index == 99) { char a[2] = {98, 0}; char b[2] = {98, 0}; string_equal(a, b /*@ 1, 1 @*/); return 0; }
if (index == 100) { char a[3] = {121, 122, 0}; char b[3] = {121, 122, 0}; string_equal(a, b /*@ 2, 2 @*/); return 0; }
if (index == 101) { char a[4] = {122, 123, 126, 0}; char b[4] = {122, 123, 126, 0}; string_equal(a, b /*@ 3, 3 @*/); return 0; }
if (index == 102) { char a[5] = {123, 126, 127, -128, 0}; char b[5] = {123, 126, 127, -128, 0}; string_equal(a, b /*@ 4, 4 @*/); return 0; }
if (index == 103) { char a[9] = {126, 127, -128, -127, -1, 1, 9, 32, 0}; char b[9] = {126, 127, -128, -127, -1, 1, 9, 32, 0}; string_equal(a, b /*@ 8, 8 @*/); return 0; }
if (index == 104) { char a[17] = {127, -128, -127, -1, 1, 9, 32, 64, 65, 90, 96, 97, 98, 121, 122, 123, 0}; char b[17] = {127, -128, -127, -1, 1, 9, 32, 64, 65, 90, 96, 97, 98, 121, 122, 123, 0}; string_equal(a, b /*@ 16, 16 @*/); return 0; }
if (index == 105) { char a[3] = {-127, 65, 0}; char b[3] = {-128, 65, 0}; string_equal(a, b /*@ 2, 2 @*/); return 0; }
if (index == 106) { char a[4] = {127, 32, 126, 0}; char b[4] = {-128, 32, 126, 0}; string_equal(a, b /*@ 3, 3 @*/); return 0; }
if (index == 107) { char a[5] = {98, 98, 96, 126, 0}; char b[5] = {-128, 98, 96, 126, 0}; string_equal(a, b /*@ 4, 4 @*/); return 0; }
if (index == 108) { char a[9] = {32, 127, -127, -1, 126, 9, 98, 122, 0}; char b[9] = {-128, 127, -127, -1, 126, 9, 98, 122, 0}; string_equal(a, b /*@ 8, 8 @*/); return 0; }
if (index == 109) { char a[17] = {90, 98, -1, 122, 9, 65, 127, -128, 127, 123, 126, 126, 90, 1, 98, 98, 0}; char b[17] = {-128, 98, -1, 122, 9, 65, 127, -128, 127, 123, 126, 126, 90, 1, 98, 98, 0}; string_equal(a, b /*@ 16, 16 @*/); return 0; }
if (index == 110) { char a[1] = {0}; char b[2] = {97, 0}; string_equal(a, b /*@ 0, 1 @*/); return 0; }
if (index == 111) { char a[2] = {-127, 0}; char b[3] = {-127, -128, 0}; string_equal(a, b /*@ 1, 2 @*/); return 0; }
if (index == 112) { char a[3] = {-127, -127, 0}; char b[4] = {-127, -127, 98, 0}; string_equal(a, b /*@ 2, 3 @*/); return 0; }
if (index == 113) { char a[4] = {-127, -127, -127, 0}; char b[5] = {-127, -127, -127, 96, 0}; string_equal(a, b /*@ 3, 4 @*/); return 0; }
if (index == 114) { char a[5] = {-127, -127, -127, -127, 0}; char b[6] = {-127, -127, -127, -127, 65, 0}; string_equal(a, b /*@ 4, 5 @*/); return 0; }
if (index == 115) { char a[9] = {-127, -127, -127, -127, -127, -127, -127, -127, 0}; char b[10] = {-127, -127, -127, -127, -127, -127, -127, -127, 123, 0}; string_equal(a, b /*@ 8, 9 @*/); return 0; }
if (index == 116) { char a[17] = {-127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, 0}; char b[18] = {-127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, 32, 0}; string_equal(a, b /*@ 16, 17 @*/); return 0; }
if (index == 117) { char a[3] = {127, -128, 0}; char b[3] = {127, -127, 0}; string_equal(a, b /*@ 2, 2 @*/); return 0; }
if (index == 118) { char a[4] = {-128, -127, -1, 0}; char b[4] = {-128, -127, -128, 0}; string_equal(a, b /*@ 3, 3 @*/); return 0; }
if (index == 119) { char a[5] = {-127, -1, 1, 9, 0}; char b[5] = {-127, -1, 1, -128, 0}; string_equal(a, b /*@ 4, 4 @*/); return 0; }
if (index == 120) { char a[9] = {-1, 1, 9, 32, 64, 65, 90, 96, 0}; char b[9] = {-1, 1, 9, 32, 64, 65, 90, -128, 0}; string_equal(a, b /*@ 8, 8 @*/); return 0; }
if (index == 121) { char a[17] = {1, 9, 32, 64, 65, 90, 96, 97, 98, 121, 122, 123, 126, 127, -128, -127, 0}; char b[17] = {1, 9, 32, 64, 65, 90, 96, 97, 98, 121, 122, 123, 126, 127, -128, -128, 0}; string_equal(a, b /*@ 16, 16 @*/); return 0; }
if (index == 122) { char a[2] = {96, 0}; char b[2] = {96, 0}; string_equal(a, b /*@ 1, 1 @*/); return 0; }
if (index == 123) { char a[3] = {64, 98, 0}; char b[3] = {64, 98, 0}; string_equal(a, b /*@ 2, 2 @*/); return 0; }
if (index == 124) { char a[4] = {-1, 122, 32, 0}; char b[4] = {-1, 122, 32, 0}; string_equal(a, b /*@ 3, 3 @*/); return 0; }
if (index == 125) { char a[5] = {121, 97, 123, 123, 0}; char b[5] = {121, 97, 123, 123, 0}; string_equal(a, b /*@ 4, 4 @*/); return 0; }
if (index == 126) { char a[9] = {-1, 9, -127, 127, 65, 65, -128, 126, 0}; char b[9] = {-1, 9, -127, 127, 65, 65, -128, 126, 0}; string_equal(a, b /*@ 8, 8 @*/); return 0; }
if (index == 127) { char a[17] = {32, 98, 90, 32, 126, 127, 96, 98, 123, 126, 65, -127, 121, 123, 123, 64, 0}; char b[17] = {32, 98, 90, 32, 126, 127, 96, 98, 123, 126, 65, -127, 121, 123, 123, 64, 0}; string_equal(a, b /*@ 16, 16 @*/); return 0; }
return 13; }
