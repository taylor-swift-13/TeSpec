int root_cell(int *p)
/*@ requires take x = RW<int>(p); 0 <= x && x <= 100; ensures take y = RW<int>(p); y == return; 0 <= return; x <= return*return; return == 0 || (return-1)*(return-1) < x; @*/
{
    int n = *p;
    int r = 0;
    while (r * r < n)
    
    { r = r + 1; }
    *p = r + 1;
    return r;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: { int p = 0; root_cell(&p); return 0; }
case 1: { int p = 1; root_cell(&p); return 0; }
case 2: { int p = 2; root_cell(&p); return 0; }
case 3: { int p = 3; root_cell(&p); return 0; }
case 4: { int p = 4; root_cell(&p); return 0; }
case 5: { int p = 5; root_cell(&p); return 0; }
case 6: { int p = 6; root_cell(&p); return 0; }
case 7: { int p = 7; root_cell(&p); return 0; }
case 8: { int p = 8; root_cell(&p); return 0; }
case 9: { int p = 9; root_cell(&p); return 0; }
case 10: { int p = 10; root_cell(&p); return 0; }
case 11: { int p = 11; root_cell(&p); return 0; }
case 12: { int p = 12; root_cell(&p); return 0; }
case 13: { int p = 13; root_cell(&p); return 0; }
case 14: { int p = 14; root_cell(&p); return 0; }
case 15: { int p = 15; root_cell(&p); return 0; }
case 16: { int p = 16; root_cell(&p); return 0; }
case 17: { int p = 17; root_cell(&p); return 0; }
case 18: { int p = 18; root_cell(&p); return 0; }
case 19: { int p = 19; root_cell(&p); return 0; }
case 20: { int p = 20; root_cell(&p); return 0; }
case 21: { int p = 21; root_cell(&p); return 0; }
case 22: { int p = 22; root_cell(&p); return 0; }
case 23: { int p = 23; root_cell(&p); return 0; }
case 24: { int p = 24; root_cell(&p); return 0; }
case 25: { int p = 25; root_cell(&p); return 0; }
case 26: { int p = 26; root_cell(&p); return 0; }
case 27: { int p = 27; root_cell(&p); return 0; }
case 28: { int p = 28; root_cell(&p); return 0; }
case 29: { int p = 29; root_cell(&p); return 0; }
case 30: { int p = 30; root_cell(&p); return 0; }
case 31: { int p = 31; root_cell(&p); return 0; }
case 32: { int p = 32; root_cell(&p); return 0; }
case 33: { int p = 33; root_cell(&p); return 0; }
case 34: { int p = 34; root_cell(&p); return 0; }
case 35: { int p = 35; root_cell(&p); return 0; }
case 36: { int p = 36; root_cell(&p); return 0; }
case 37: { int p = 37; root_cell(&p); return 0; }
case 38: { int p = 38; root_cell(&p); return 0; }
case 39: { int p = 39; root_cell(&p); return 0; }
case 40: { int p = 40; root_cell(&p); return 0; }
case 41: { int p = 41; root_cell(&p); return 0; }
case 42: { int p = 42; root_cell(&p); return 0; }
case 43: { int p = 43; root_cell(&p); return 0; }
case 44: { int p = 44; root_cell(&p); return 0; }
case 45: { int p = 45; root_cell(&p); return 0; }
case 46: { int p = 46; root_cell(&p); return 0; }
case 47: { int p = 47; root_cell(&p); return 0; }
case 48: { int p = 48; root_cell(&p); return 0; }
case 49: { int p = 49; root_cell(&p); return 0; }
case 50: { int p = 50; root_cell(&p); return 0; }
case 51: { int p = 51; root_cell(&p); return 0; }
case 52: { int p = 52; root_cell(&p); return 0; }
case 53: { int p = 53; root_cell(&p); return 0; }
case 54: { int p = 54; root_cell(&p); return 0; }
case 55: { int p = 55; root_cell(&p); return 0; }
case 56: { int p = 56; root_cell(&p); return 0; }
case 57: { int p = 57; root_cell(&p); return 0; }
case 58: { int p = 58; root_cell(&p); return 0; }
case 59: { int p = 59; root_cell(&p); return 0; }
case 60: { int p = 60; root_cell(&p); return 0; }
case 61: { int p = 61; root_cell(&p); return 0; }
case 62: { int p = 62; root_cell(&p); return 0; }
case 63: { int p = 63; root_cell(&p); return 0; }
case 64: { int p = 64; root_cell(&p); return 0; }
case 65: { int p = 65; root_cell(&p); return 0; }
case 66: { int p = 66; root_cell(&p); return 0; }
case 67: { int p = 67; root_cell(&p); return 0; }
case 68: { int p = 68; root_cell(&p); return 0; }
case 69: { int p = 69; root_cell(&p); return 0; }
case 70: { int p = 70; root_cell(&p); return 0; }
case 71: { int p = 71; root_cell(&p); return 0; }
case 72: { int p = 72; root_cell(&p); return 0; }
case 73: { int p = 73; root_cell(&p); return 0; }
case 74: { int p = 74; root_cell(&p); return 0; }
case 75: { int p = 75; root_cell(&p); return 0; }
case 76: { int p = 76; root_cell(&p); return 0; }
case 77: { int p = 77; root_cell(&p); return 0; }
case 78: { int p = 78; root_cell(&p); return 0; }
case 79: { int p = 79; root_cell(&p); return 0; }
case 80: { int p = 80; root_cell(&p); return 0; }
case 81: { int p = 81; root_cell(&p); return 0; }
case 82: { int p = 82; root_cell(&p); return 0; }
case 83: { int p = 83; root_cell(&p); return 0; }
case 84: { int p = 84; root_cell(&p); return 0; }
case 85: { int p = 85; root_cell(&p); return 0; }
case 86: { int p = 86; root_cell(&p); return 0; }
case 87: { int p = 87; root_cell(&p); return 0; }
case 88: { int p = 88; root_cell(&p); return 0; }
case 89: { int p = 89; root_cell(&p); return 0; }
case 90: { int p = 90; root_cell(&p); return 0; }
case 91: { int p = 91; root_cell(&p); return 0; }
case 92: { int p = 92; root_cell(&p); return 0; }
case 93: { int p = 93; root_cell(&p); return 0; }
case 94: { int p = 94; root_cell(&p); return 0; }
case 95: { int p = 95; root_cell(&p); return 0; }
case 96: { int p = 96; root_cell(&p); return 0; }
case 97: { int p = 97; root_cell(&p); return 0; }
case 98: { int p = 98; root_cell(&p); return 0; }
case 99: { int p = 99; root_cell(&p); return 0; }
case 100: { int p = 100; root_cell(&p); return 0; }
default: return 13; } }
