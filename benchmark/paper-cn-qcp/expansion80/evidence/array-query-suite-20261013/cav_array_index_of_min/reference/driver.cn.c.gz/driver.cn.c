int array_index_of_min(int n, int *a)
/*@ requires 1 <= n; take A = each(integer i; 0 <= i && i < n) {RW<int>(array_shift<int>(a,i))}; ensures take B = each(integer i; 0 <= i && i < n) {RW<int>(array_shift<int>(a,i))}; B == A; 0 <= return; return < n; each(integer j; 0 <= j && j < n) {A[return] <= A[j]}; each(integer j; 0 <= j && j < return) {A[j] > A[return]}; @*/
{
    int idx = 0;
    int i = 1;

    while (i < n) {
        if (a[i] < a[idx]) {
            idx = i;
        }
        i++;
    }

    return idx;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: { int a[1] = {(-2147483647 - 1)}; array_index_of_min(1, a); return 0; }
case 1: { int a[2] = {(-2147483647 - 1), (-2147483647 - 1)}; array_index_of_min(2, a); return 0; }
case 2: { int a[3] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)}; array_index_of_min(3, a); return 0; }
case 3: { int a[4] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)}; array_index_of_min(4, a); return 0; }
case 4: { int a[8] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)}; array_index_of_min(8, a); return 0; }
case 5: { int a[16] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)}; array_index_of_min(16, a); return 0; }
case 6: { int a[2] = {0, 0}; array_index_of_min(2, a); return 0; }
case 7: { int a[3] = {0, 0, 0}; array_index_of_min(3, a); return 0; }
case 8: { int a[4] = {0, 0, 0, 0}; array_index_of_min(4, a); return 0; }
case 9: { int a[8] = {0, 0, 0, 0, 0, 0, 0, 0}; array_index_of_min(8, a); return 0; }
case 10: { int a[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; array_index_of_min(16, a); return 0; }
case 11: { int a[1] = {0}; array_index_of_min(1, a); return 0; }
case 12: { int a[3] = {-2, -1, 0}; array_index_of_min(3, a); return 0; }
case 13: { int a[4] = {-1, 0, 1, 2}; array_index_of_min(4, a); return 0; }
case 14: { int a[8] = {0, 1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647}; array_index_of_min(8, a); return 0; }
case 15: { int a[16] = {1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1, 0, 1, 2, 100, 2147483646, 2147483647}; array_index_of_min(16, a); return 0; }
case 16: { int a[1] = {2}; array_index_of_min(1, a); return 0; }
case 17: { int a[2] = {100, 2147483646}; array_index_of_min(2, a); return 0; }
case 18: { int a[3] = {2147483646, 2147483647, (-2147483647 - 1)}; array_index_of_min(3, a); return 0; }
case 19: { int a[4] = {-100, 1, 2147483646, 2147483647}; array_index_of_min(4, a); return 0; }
case 20: { int a[8] = {-2, -1, 0, 1, 1, 2147483646, 2147483646, 2147483646}; array_index_of_min(8, a); return 0; }
case 21: { int a[16] = {(-2147483647 - 1), (-2147483647 - 1), -2147483647, -2147483647, -100, -100, -100, -2, -1, -1, 1, 1, 2, 2, 100, 2147483646}; array_index_of_min(16, a); return 0; }
case 22: { int a[2] = {0, 2}; array_index_of_min(2, a); return 0; }
case 23: { int a[3] = {0, 1, 2147483647}; array_index_of_min(3, a); return 0; }
case 24: { int a[4] = {-100, 0, 100, 2147483646}; array_index_of_min(4, a); return 0; }
case 25: { int a[8] = {-833421548, 1456915023, 806008623, 1368451539, 2087782113, -1845620830, -208350282, -2038743611}; array_index_of_min(8, a); return 0; }
case 26: { int a[16] = {1309130943, 1950106030, -1271326959, 1466066651, 2136620527, 2081350927, -1979372692, -882356487, 223406556, 617865469, 1266513166, 1114208779, 394273271, 1180827568, 1726544480, 374059776}; array_index_of_min(16, a); return 0; }
case 27: { int a[1] = {-662961268}; array_index_of_min(1, a); return 0; }
case 28: { int a[2] = {-69631889, 1392402695}; array_index_of_min(2, a); return 0; }
case 29: { int a[3] = {924985941, 2095640952, -594437444}; array_index_of_min(3, a); return 0; }
case 30: { int a[4] = {423149033, 190991604, 939240215, 2142139567}; array_index_of_min(4, a); return 0; }
case 31: { int a[8] = {-997193837, -1303128720, -2060693665, 248560309, 1631517721, -210343047, -239065941, -1136420893}; array_index_of_min(8, a); return 0; }
case 32: { int a[16] = {-2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647}; array_index_of_min(16, a); return 0; }
case 33: { int a[1] = {-2147483647}; array_index_of_min(1, a); return 0; }
case 34: { int a[2] = {-2147483647, -2147483647}; array_index_of_min(2, a); return 0; }
case 35: { int a[3] = {-2147483647, -2147483647, -2147483647}; array_index_of_min(3, a); return 0; }
case 36: { int a[4] = {-2147483647, -2147483647, -2147483647, -2147483647}; array_index_of_min(4, a); return 0; }
case 37: { int a[8] = {-2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647}; array_index_of_min(8, a); return 0; }
case 38: { int a[2] = {0, 1}; array_index_of_min(2, a); return 0; }
case 39: { int a[3] = {1, 2, 100}; array_index_of_min(3, a); return 0; }
case 40: { int a[4] = {2, 100, 2147483646, 2147483647}; array_index_of_min(4, a); return 0; }
case 41: { int a[8] = {100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1}; array_index_of_min(8, a); return 0; }
case 42: { int a[16] = {2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1, 0, 1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100}; array_index_of_min(16, a); return 0; }
case 43: { int a[1] = {2147483647}; array_index_of_min(1, a); return 0; }
case 44: { int a[2] = {(-2147483647 - 1), -2147483647}; array_index_of_min(2, a); return 0; }
case 45: { int a[3] = {-2, 2, 100}; array_index_of_min(3, a); return 0; }
case 46: { int a[4] = {(-2147483647 - 1), -2, 1, 2}; array_index_of_min(4, a); return 0; }
case 47: { int a[8] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), -100, -1, -1, 0, 1}; array_index_of_min(8, a); return 0; }
case 48: { int a[16] = {(-2147483647 - 1), (-2147483647 - 1), -2147483647, -100, -2, -2, -1, 1, 2, 2, 2, 2, 100, 100, 2147483647, 2147483647}; array_index_of_min(16, a); return 0; }
case 49: { int a[2] = {0, 100}; array_index_of_min(2, a); return 0; }
case 50: { int a[3] = {-2147483647, -100, 2}; array_index_of_min(3, a); return 0; }
case 51: { int a[4] = {-385745401, -1036584957, -578059497, 701236369}; array_index_of_min(4, a); return 0; }
case 52: { int a[8] = {1629498510, -983082501, 992478129, -2085416551, -569155800, -226780370, -1874312103, 2146483821}; array_index_of_min(8, a); return 0; }
case 53: { int a[16] = {1863533231, 2065963835, -2034977911, -1693996271, 2024847753, 772856760, 213633940, 1834165143, -648283412, -1822171305, -1436904439, -27507951, 664021708, -1446294794, -1069282466, -200547056}; array_index_of_min(16, a); return 0; }
case 54: { int a[1] = {2056106113}; array_index_of_min(1, a); return 0; }
case 55: { int a[2] = {2006128915, 1521112263}; array_index_of_min(2, a); return 0; }
case 56: { int a[3] = {-19994936, 854870091, -557894232}; array_index_of_min(3, a); return 0; }
case 57: { int a[4] = {918298044, -208703394, -431630919, 698507150}; array_index_of_min(4, a); return 0; }
case 58: { int a[8] = {-100, -100, -100, -100, -100, -100, -100, -100}; array_index_of_min(8, a); return 0; }
case 59: { int a[16] = {-100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100}; array_index_of_min(16, a); return 0; }
case 60: { int a[1] = {-100}; array_index_of_min(1, a); return 0; }
case 61: { int a[2] = {-100, -100}; array_index_of_min(2, a); return 0; }
case 62: { int a[3] = {-100, -100, -100}; array_index_of_min(3, a); return 0; }
case 63: { int a[4] = {-100, -100, -100, -100}; array_index_of_min(4, a); return 0; }
case 64: { int a[4] = {2147483647, (-2147483647 - 1), -2147483647, -100}; array_index_of_min(4, a); return 0; }
case 65: { int a[8] = {(-2147483647 - 1), -2147483647, -100, -2, -1, 0, 1, 2}; array_index_of_min(8, a); return 0; }
case 66: { int a[16] = {-2147483647, -100, -2, -1, 0, 1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1, 0}; array_index_of_min(16, a); return 0; }
case 67: { int a[2] = {-2147483647, 100}; array_index_of_min(2, a); return 0; }
case 68: { int a[3] = {-2, 2, 2}; array_index_of_min(3, a); return 0; }
case 69: { int a[4] = {-2147483647, -100, 2147483646, 2147483646}; array_index_of_min(4, a); return 0; }
case 70: { int a[8] = {(-2147483647 - 1), (-2147483647 - 1), -2, -1, 0, 2, 2147483646, 2147483647}; array_index_of_min(8, a); return 0; }
case 71: { int a[16] = {(-2147483647 - 1), -2, -1, -1, -1, 0, 1, 2, 2, 2147483646, 2147483646, 2147483646, 2147483646, 2147483646, 2147483647, 2147483647}; array_index_of_min(16, a); return 0; }
case 72: { int a[1] = {2147483646}; array_index_of_min(1, a); return 0; }
case 73: { int a[2] = {-100, 2}; array_index_of_min(2, a); return 0; }
case 74: { int a[3] = {-2050622355, 114559393, 52264846}; array_index_of_min(3, a); return 0; }
case 75: { int a[4] = {1654188971, -1933844997, -1158074238, 1159592373}; array_index_of_min(4, a); return 0; }
case 76: { int a[8] = {208891740, 1940001134, -1846391616, 1395749025, -509314459, -179718819, -1979051088, -1179049931}; array_index_of_min(8, a); return 0; }
case 77: { int a[16] = {1882448808, -548542552, 1208135172, 2067871768, 1808180369, 1562695090, 1736259565, -665934555, -950905118, 1036621963, -595887025, 445292680, -610261274, 1150703960, 149373163, 1367121287}; array_index_of_min(16, a); return 0; }
case 78: { int a[1] = {1246671927}; array_index_of_min(1, a); return 0; }
case 79: { int a[2] = {2090048509, 155196249}; array_index_of_min(2, a); return 0; }
case 80: { int a[3] = {1608653981, -1372233979, -117367611}; array_index_of_min(3, a); return 0; }
case 81: { int a[4] = {-2, -2, -2, -2}; array_index_of_min(4, a); return 0; }
case 82: { int a[8] = {-2, -2, -2, -2, -2, -2, -2, -2}; array_index_of_min(8, a); return 0; }
case 83: { int a[16] = {-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2}; array_index_of_min(16, a); return 0; }
case 84: { int a[1] = {-2}; array_index_of_min(1, a); return 0; }
case 85: { int a[2] = {-2, -2}; array_index_of_min(2, a); return 0; }
case 86: { int a[3] = {-2, -2, -2}; array_index_of_min(3, a); return 0; }
case 87: { int a[3] = {-2147483647, -100, -2}; array_index_of_min(3, a); return 0; }
case 88: { int a[4] = {-100, -2, -1, 0}; array_index_of_min(4, a); return 0; }
case 89: { int a[8] = {-2, -1, 0, 1, 2, 100, 2147483646, 2147483647}; array_index_of_min(8, a); return 0; }
case 90: { int a[16] = {-1, 0, 1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1, 0, 1, 2, 100}; array_index_of_min(16, a); return 0; }
case 91: { int a[1] = {1}; array_index_of_min(1, a); return 0; }
case 92: { int a[2] = {-2147483647, 0}; array_index_of_min(2, a); return 0; }
case 93: { int a[3] = {-2147483647, 1, 2}; array_index_of_min(3, a); return 0; }
case 94: { int a[4] = {2, 2, 2147483647, 2147483647}; array_index_of_min(4, a); return 0; }
case 95: { int a[8] = {(-2147483647 - 1), -100, 0, 0, 1, 2, 2, 2147483646}; array_index_of_min(8, a); return 0; }
case 96: { int a[16] = {(-2147483647 - 1), -2147483647, -2147483647, -100, -100, -1, 0, 0, 0, 0, 2, 2, 100, 100, 2147483646, 2147483647}; array_index_of_min(16, a); return 0; }
case 97: { int a[2] = {-152320547, -291012452}; array_index_of_min(2, a); return 0; }
case 98: { int a[3] = {-1848074038, 663289720, 815642197}; array_index_of_min(3, a); return 0; }
case 99: { int a[4] = {-46694898, 1298010804, 1192953353, 224166788}; array_index_of_min(4, a); return 0; }
case 100: { int a[8] = {-1599344655, 683818026, -219468548, 67120118, 385534353, 645458742, -1353089488, -1752403606}; array_index_of_min(8, a); return 0; }
case 101: { int a[16] = {-114207157, -462996215, 1142464526, 105842754, -206473950, 1868606285, -757973160, -1296226354, -1096721974, -1913204401, -710416124, -2010564886, 1952723005, -428826563, 1100648095, 1222722771}; array_index_of_min(16, a); return 0; }
case 102: { int a[1] = {-637351359}; array_index_of_min(1, a); return 0; }
case 103: { int a[2] = {605155675, 1853301338}; array_index_of_min(2, a); return 0; }
case 104: { int a[3] = {-1, -1, -1}; array_index_of_min(3, a); return 0; }
case 105: { int a[4] = {-1, -1, -1, -1}; array_index_of_min(4, a); return 0; }
case 106: { int a[8] = {-1, -1, -1, -1, -1, -1, -1, -1}; array_index_of_min(8, a); return 0; }
case 107: { int a[16] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}; array_index_of_min(16, a); return 0; }
case 108: { int a[1] = {-1}; array_index_of_min(1, a); return 0; }
case 109: { int a[2] = {-1, -1}; array_index_of_min(2, a); return 0; }
case 110: { int a[2] = {-2, -1}; array_index_of_min(2, a); return 0; }
case 111: { int a[3] = {-1, 0, 1}; array_index_of_min(3, a); return 0; }
case 112: { int a[4] = {0, 1, 2, 100}; array_index_of_min(4, a); return 0; }
case 113: { int a[8] = {1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100}; array_index_of_min(8, a); return 0; }
case 114: { int a[16] = {(-2147483647 - 1), -2147483647, -2147483647, -2, -1, -1, -1, -1, 0, 1, 1, 100, 100, 2147483646, 2147483647, 2147483647}; array_index_of_min(16, a); return 0; }
case 115: { int a[2] = {(-2147483647 - 1), 2147483647}; array_index_of_min(2, a); return 0; }
case 116: { int a[3] = {2, 2, 2147483646}; array_index_of_min(3, a); return 0; }
case 117: { int a[4] = {(-2147483647 - 1), -2147483647, -2, 2147483647}; array_index_of_min(4, a); return 0; }
case 118: { int a[8] = {-100, -2, 0, 2, 100, 100, 2147483646, 2147483647}; array_index_of_min(8, a); return 0; }
case 119: { int a[16] = {-2147483647, -2147483647, -2147483647, -2, -1, -1, 0, 0, 1, 1, 1, 2, 2, 100, 100, 2147483647}; array_index_of_min(16, a); return 0; }
case 120: { int a[1] = {1095855425}; array_index_of_min(1, a); return 0; }
case 121: { int a[2] = {-1153444952, -316466477}; array_index_of_min(2, a); return 0; }
case 122: { int a[3] = {-1522895720, 852710999, 2084105685}; array_index_of_min(3, a); return 0; }
case 123: { int a[4] = {233137520, -337062465, -1172095830, -268479557}; array_index_of_min(4, a); return 0; }
case 124: { int a[8] = {-780427405, -1460333914, -1839703333, -680640243, -2005772941, -499696307, -1586496354, 1852105981}; array_index_of_min(8, a); return 0; }
case 125: { int a[16] = {-1426678154, -1891207262, 787790455, -1472570231, -327449500, -1612594943, 1182243097, -246558382, 34658714, 1953417002, 1377651849, -1837035599, -2115529950, -248841112, 1169399141, -1880465423}; array_index_of_min(16, a); return 0; }
case 126: { int a[1] = {668639790}; array_index_of_min(1, a); return 0; }
case 127: { int a[2] = {1, 2}; array_index_of_min(2, a); return 0; }
default: return 13; } }
