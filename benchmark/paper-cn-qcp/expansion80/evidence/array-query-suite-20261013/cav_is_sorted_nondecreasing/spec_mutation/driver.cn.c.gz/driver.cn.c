/*@
function [rec] (integer) Sorted(map<integer,integer> a, integer n) { if(n < 2) {1} else { if(a[n-2] <= a[n-1]) {Sorted(a,n-1)} else {0} } }
@*/
int is_sorted_nondecreasing(int n, int *a)
/*@ requires 0 <= n; take A = each(integer i; 0 <= i && i < n) {RW<int>(array_shift<int>(a,i))}; ensures take B = each(integer i; 0 <= i && i < n) {RW<int>(array_shift<int>(a,i))}; B == A; (return == 0 && Sorted(A,n) == 1) || (return == 0 && Sorted(A,n) == 0); @*/
{
    int i;

    for (i = 0; i + 1 < n; ++i) {
        if (a[i] > a[i + 1]) {
            return 0;
        }
    }

    return 1;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: { int a[1] = {0}; is_sorted_nondecreasing(0, a); return 0; }
case 1: { int a[1] = {(-2147483647 - 1)}; is_sorted_nondecreasing(1, a); return 0; }
case 2: { int a[2] = {(-2147483647 - 1), (-2147483647 - 1)}; is_sorted_nondecreasing(2, a); return 0; }
case 3: { int a[3] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)}; is_sorted_nondecreasing(3, a); return 0; }
case 4: { int a[4] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)}; is_sorted_nondecreasing(4, a); return 0; }
case 5: { int a[8] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)}; is_sorted_nondecreasing(8, a); return 0; }
case 6: { int a[16] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)}; is_sorted_nondecreasing(16, a); return 0; }
case 7: { int a[1] = {0}; is_sorted_nondecreasing(1, a); return 0; }
case 8: { int a[2] = {0, 0}; is_sorted_nondecreasing(2, a); return 0; }
case 9: { int a[3] = {0, 0, 0}; is_sorted_nondecreasing(3, a); return 0; }
case 10: { int a[4] = {0, 0, 0, 0}; is_sorted_nondecreasing(4, a); return 0; }
case 11: { int a[8] = {0, 0, 0, 0, 0, 0, 0, 0}; is_sorted_nondecreasing(8, a); return 0; }
case 12: { int a[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; is_sorted_nondecreasing(16, a); return 0; }
case 13: { int a[1] = {-1}; is_sorted_nondecreasing(1, a); return 0; }
case 14: { int a[2] = {0, 1}; is_sorted_nondecreasing(2, a); return 0; }
case 15: { int a[3] = {1, 2, 100}; is_sorted_nondecreasing(3, a); return 0; }
case 16: { int a[4] = {2, 100, 2147483646, 2147483647}; is_sorted_nondecreasing(4, a); return 0; }
case 17: { int a[8] = {100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1}; is_sorted_nondecreasing(8, a); return 0; }
case 18: { int a[16] = {2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1, 0, 1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100}; is_sorted_nondecreasing(16, a); return 0; }
case 19: { int a[1] = {1}; is_sorted_nondecreasing(1, a); return 0; }
case 20: { int a[2] = {-100, 2147483646}; is_sorted_nondecreasing(2, a); return 0; }
case 21: { int a[3] = {-2, 0, 2147483647}; is_sorted_nondecreasing(3, a); return 0; }
case 22: { int a[4] = {-1, 1, 1, 2147483646}; is_sorted_nondecreasing(4, a); return 0; }
case 23: { int a[8] = {(-2147483647 - 1), -2147483647, -100, -100, 2, 2147483646, 2147483646, 2147483646}; is_sorted_nondecreasing(8, a); return 0; }
case 24: { int a[16] = {(-2147483647 - 1), -2147483647, -100, -2, -1, -1, 0, 0, 1, 1, 1, 2, 2, 2, 100, 2147483647}; is_sorted_nondecreasing(16, a); return 0; }
case 25: { int a[1] = {1683155869}; is_sorted_nondecreasing(1, a); return 0; }
case 26: { int a[2] = {-833421548, 1456915023}; is_sorted_nondecreasing(2, a); return 0; }
case 27: { int a[3] = {806008623, 1368451539, 2087782113}; is_sorted_nondecreasing(3, a); return 0; }
case 28: { int a[4] = {-1845620830, -208350282, -2038743611, 1309130943}; is_sorted_nondecreasing(4, a); return 0; }
case 29: { int a[8] = {1950106030, -1271326959, 1466066651, 2136620527, 2081350927, -1979372692, -882356487, 223406556}; is_sorted_nondecreasing(8, a); return 0; }
case 30: { int a[16] = {617865469, 1266513166, 1114208779, 394273271, 1180827568, 1726544480, 374059776, -662961268, -69631889, 1392402695, 924985941, 2095640952, -594437444, 423149033, 190991604, 939240215}; is_sorted_nondecreasing(16, a); return 0; }
case 31: { int a[1] = {-2147483647}; is_sorted_nondecreasing(1, a); return 0; }
case 32: { int a[2] = {-2147483647, -2147483647}; is_sorted_nondecreasing(2, a); return 0; }
case 33: { int a[3] = {-2147483647, -2147483647, -2147483647}; is_sorted_nondecreasing(3, a); return 0; }
case 34: { int a[4] = {-2147483647, -2147483647, -2147483647, -2147483647}; is_sorted_nondecreasing(4, a); return 0; }
case 35: { int a[8] = {-2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647}; is_sorted_nondecreasing(8, a); return 0; }
case 36: { int a[16] = {-2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647}; is_sorted_nondecreasing(16, a); return 0; }
case 37: { int a[2] = {2, 100}; is_sorted_nondecreasing(2, a); return 0; }
case 38: { int a[3] = {100, 2147483646, 2147483647}; is_sorted_nondecreasing(3, a); return 0; }
case 39: { int a[4] = {2147483646, 2147483647, (-2147483647 - 1), -2147483647}; is_sorted_nondecreasing(4, a); return 0; }
case 40: { int a[8] = {2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1, 0, 1}; is_sorted_nondecreasing(8, a); return 0; }
case 41: { int a[16] = {(-2147483647 - 1), -2147483647, -100, -2, -1, 0, 1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1}; is_sorted_nondecreasing(16, a); return 0; }
case 42: { int a[2] = {1, 2147483647}; is_sorted_nondecreasing(2, a); return 0; }
case 43: { int a[3] = {2, 2147483646, 2147483647}; is_sorted_nondecreasing(3, a); return 0; }
case 44: { int a[4] = {-100, -100, -2, 1}; is_sorted_nondecreasing(4, a); return 0; }
case 45: { int a[8] = {(-2147483647 - 1), -100, -100, -2, -1, 1, 2, 2147483646}; is_sorted_nondecreasing(8, a); return 0; }
case 46: { int a[16] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), -100, -100, -2, -2, -1, -1, -1, -1, 1, 1, 2, 2, 100}; is_sorted_nondecreasing(16, a); return 0; }
case 47: { int a[1] = {2086214534}; is_sorted_nondecreasing(1, a); return 0; }
case 48: { int a[2] = {265588704, 1316886265}; is_sorted_nondecreasing(2, a); return 0; }
case 49: { int a[3] = {180316251, 1101037346, -1357943129}; is_sorted_nondecreasing(3, a); return 0; }
case 50: { int a[4] = {-385745401, -1036584957, -578059497, 701236369}; is_sorted_nondecreasing(4, a); return 0; }
case 51: { int a[8] = {1629498510, -983082501, 992478129, -2085416551, -569155800, -226780370, -1874312103, 2146483821}; is_sorted_nondecreasing(8, a); return 0; }
case 52: { int a[16] = {1863533231, 2065963835, -2034977911, -1693996271, 2024847753, 772856760, 213633940, 1834165143, -648283412, -1822171305, -1436904439, -27507951, 664021708, -1446294794, -1069282466, -200547056}; is_sorted_nondecreasing(16, a); return 0; }
case 53: { int a[1] = {-100}; is_sorted_nondecreasing(1, a); return 0; }
case 54: { int a[2] = {-100, -100}; is_sorted_nondecreasing(2, a); return 0; }
case 55: { int a[3] = {-100, -100, -100}; is_sorted_nondecreasing(3, a); return 0; }
case 56: { int a[4] = {-100, -100, -100, -100}; is_sorted_nondecreasing(4, a); return 0; }
case 57: { int a[8] = {-100, -100, -100, -100, -100, -100, -100, -100}; is_sorted_nondecreasing(8, a); return 0; }
case 58: { int a[16] = {-100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100}; is_sorted_nondecreasing(16, a); return 0; }
case 59: { int a[1] = {100}; is_sorted_nondecreasing(1, a); return 0; }
case 60: { int a[2] = {2147483646, 2147483647}; is_sorted_nondecreasing(2, a); return 0; }
case 61: { int a[3] = {2147483647, (-2147483647 - 1), -2147483647}; is_sorted_nondecreasing(3, a); return 0; }
case 62: { int a[4] = {(-2147483647 - 1), -2147483647, -100, -2}; is_sorted_nondecreasing(4, a); return 0; }
case 63: { int a[8] = {-2147483647, -100, -2, -1, 0, 1, 2, 100}; is_sorted_nondecreasing(8, a); return 0; }
case 64: { int a[16] = {-100, -2, -1, 0, 1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1, 0, 1}; is_sorted_nondecreasing(16, a); return 0; }
case 65: { int a[1] = {2147483647}; is_sorted_nondecreasing(1, a); return 0; }
case 66: { int a[2] = {(-2147483647 - 1), 2147483647}; is_sorted_nondecreasing(2, a); return 0; }
case 67: { int a[3] = {2147483646, 2147483646, 2147483646}; is_sorted_nondecreasing(3, a); return 0; }
case 68: { int a[4] = {-100, 0, 2, 2}; is_sorted_nondecreasing(4, a); return 0; }
case 69: { int a[8] = {(-2147483647 - 1), -2, -1, -1, -1, 1, 2, 2147483647}; is_sorted_nondecreasing(8, a); return 0; }
case 70: { int a[16] = {(-2147483647 - 1), (-2147483647 - 1), -2147483647, -2147483647, -100, -2, -1, 0, 2, 2, 2, 100, 2147483646, 2147483646, 2147483646, 2147483647}; is_sorted_nondecreasing(16, a); return 0; }
case 71: { int a[1] = {-756053316}; is_sorted_nondecreasing(1, a); return 0; }
case 72: { int a[2] = {720630002, -106400218}; is_sorted_nondecreasing(2, a); return 0; }
case 73: { int a[3] = {2095158344, -1759107479, 934108658}; is_sorted_nondecreasing(3, a); return 0; }
case 74: { int a[4] = {-579500865, 1628019954, 592919359, -2050622355}; is_sorted_nondecreasing(4, a); return 0; }
case 75: { int a[8] = {114559393, 52264846, 1654188971, -1933844997, -1158074238, 1159592373, 208891740, 1940001134}; is_sorted_nondecreasing(8, a); return 0; }
case 76: { int a[16] = {-1846391616, 1395749025, -509314459, -179718819, -1979051088, -1179049931, 1882448808, -548542552, 1208135172, 2067871768, 1808180369, 1562695090, 1736259565, -665934555, -950905118, 1036621963}; is_sorted_nondecreasing(16, a); return 0; }
case 77: { int a[1] = {-2}; is_sorted_nondecreasing(1, a); return 0; }
case 78: { int a[2] = {-2, -2}; is_sorted_nondecreasing(2, a); return 0; }
case 79: { int a[3] = {-2, -2, -2}; is_sorted_nondecreasing(3, a); return 0; }
case 80: { int a[4] = {-2, -2, -2, -2}; is_sorted_nondecreasing(4, a); return 0; }
case 81: { int a[8] = {-2, -2, -2, -2, -2, -2, -2, -2}; is_sorted_nondecreasing(8, a); return 0; }
case 82: { int a[16] = {-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2}; is_sorted_nondecreasing(16, a); return 0; }
case 83: { int a[2] = {(-2147483647 - 1), -2147483647}; is_sorted_nondecreasing(2, a); return 0; }
case 84: { int a[3] = {-2147483647, -100, -2}; is_sorted_nondecreasing(3, a); return 0; }
case 85: { int a[4] = {-100, -2, -1, 0}; is_sorted_nondecreasing(4, a); return 0; }
case 86: { int a[8] = {-2, -1, 0, 1, 2, 100, 2147483646, 2147483647}; is_sorted_nondecreasing(8, a); return 0; }
case 87: { int a[16] = {-1, 0, 1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1, 0, 1, 2, 100}; is_sorted_nondecreasing(16, a); return 0; }
case 88: { int a[1] = {2}; is_sorted_nondecreasing(1, a); return 0; }
case 89: { int a[2] = {-2, 2147483647}; is_sorted_nondecreasing(2, a); return 0; }
case 90: { int a[3] = {-1, 1, 100}; is_sorted_nondecreasing(3, a); return 0; }
case 91: { int a[4] = {-2, -2, 2, 100}; is_sorted_nondecreasing(4, a); return 0; }
case 92: { int a[8] = {0, 0, 2, 2, 2, 100, 2147483646, 2147483647}; is_sorted_nondecreasing(8, a); return 0; }
case 93: { int a[16] = {-2147483647, -2147483647, -2147483647, 0, 0, 1, 1, 2, 2, 2, 100, 2147483646, 2147483646, 2147483646, 2147483647, 2147483647}; is_sorted_nondecreasing(16, a); return 0; }
case 94: { int a[1] = {-1334221323}; is_sorted_nondecreasing(1, a); return 0; }
case 95: { int a[2] = {95870864, -111984043}; is_sorted_nondecreasing(2, a); return 0; }
case 96: { int a[3] = {1507399079, 839741405, 404854496}; is_sorted_nondecreasing(3, a); return 0; }
case 97: { int a[4] = {744974972, -1272459911, 737268112, -1068229680}; is_sorted_nondecreasing(4, a); return 0; }
case 98: { int a[8] = {-1451172589, -101780263, -1258234898, -152320547, -291012452, -1848074038, 663289720, 815642197}; is_sorted_nondecreasing(8, a); return 0; }
case 99: { int a[16] = {-46694898, 1298010804, 1192953353, 224166788, -1599344655, 683818026, -219468548, 67120118, 385534353, 645458742, -1353089488, -1752403606, -114207157, -462996215, 1142464526, 105842754}; is_sorted_nondecreasing(16, a); return 0; }
case 100: { int a[2] = {-1, -1}; is_sorted_nondecreasing(2, a); return 0; }
case 101: { int a[3] = {-1, -1, -1}; is_sorted_nondecreasing(3, a); return 0; }
case 102: { int a[4] = {-1, -1, -1, -1}; is_sorted_nondecreasing(4, a); return 0; }
case 103: { int a[8] = {-1, -1, -1, -1, -1, -1, -1, -1}; is_sorted_nondecreasing(8, a); return 0; }
case 104: { int a[16] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}; is_sorted_nondecreasing(16, a); return 0; }
case 105: { int a[2] = {-100, -2}; is_sorted_nondecreasing(2, a); return 0; }
case 106: { int a[3] = {-2, -1, 0}; is_sorted_nondecreasing(3, a); return 0; }
case 107: { int a[4] = {-1, 0, 1, 2}; is_sorted_nondecreasing(4, a); return 0; }
case 108: { int a[8] = {0, 1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647}; is_sorted_nondecreasing(8, a); return 0; }
case 109: { int a[16] = {1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1, 0, 1, 2, 100, 2147483646, 2147483647}; is_sorted_nondecreasing(16, a); return 0; }
case 110: { int a[3] = {-100, -100, 100}; is_sorted_nondecreasing(3, a); return 0; }
case 111: { int a[4] = {(-2147483647 - 1), (-2147483647 - 1), 0, 2147483646}; is_sorted_nondecreasing(4, a); return 0; }
case 112: { int a[8] = {(-2147483647 - 1), -2, -2, -1, 0, 100, 100, 2147483647}; is_sorted_nondecreasing(8, a); return 0; }
case 113: { int a[16] = {(-2147483647 - 1), -2147483647, -2, -2, -2, -1, 0, 1, 1, 2, 100, 100, 2147483646, 2147483647, 2147483647, 2147483647}; is_sorted_nondecreasing(16, a); return 0; }
case 114: { int a[1] = {-412840401}; is_sorted_nondecreasing(1, a); return 0; }
case 115: { int a[2] = {-388879776, -2082202806}; is_sorted_nondecreasing(2, a); return 0; }
case 116: { int a[3] = {1395261730, -1840234795, -660211955}; is_sorted_nondecreasing(3, a); return 0; }
case 117: { int a[4] = {2076438553, 985761470, 1630505360, 68237932}; is_sorted_nondecreasing(4, a); return 0; }
case 118: { int a[8] = {1932686225, 1250578180, 204166652, -679678118, -1577037262, -182583881, 1915529852, 501108203}; is_sorted_nondecreasing(8, a); return 0; }
case 119: { int a[16] = {-1521616274, -1413067337, -205393849, 1095855425, -1153444952, -316466477, -1522895720, 852710999, 2084105685, 233137520, -337062465, -1172095830, -268479557, -780427405, -1460333914, -1839703333}; is_sorted_nondecreasing(16, a); return 0; }
case 120: { int a[2] = {-1, 0}; is_sorted_nondecreasing(2, a); return 0; }
case 121: { int a[3] = {0, 1, 2}; is_sorted_nondecreasing(3, a); return 0; }
case 122: { int a[4] = {1, 2, 100, 2147483646}; is_sorted_nondecreasing(4, a); return 0; }
case 123: { int a[8] = {2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2}; is_sorted_nondecreasing(8, a); return 0; }
case 124: { int a[16] = {100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -2, -1, 0, 1, 2, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647}; is_sorted_nondecreasing(16, a); return 0; }
case 125: { int a[2] = {-2, 2}; is_sorted_nondecreasing(2, a); return 0; }
case 126: { int a[3] = {(-2147483647 - 1), -100, 0}; is_sorted_nondecreasing(3, a); return 0; }
case 127: { int a[4] = {(-2147483647 - 1), -2147483647, -1, -1}; is_sorted_nondecreasing(4, a); return 0; }
default: return 13; } }
