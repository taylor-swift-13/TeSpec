/*@
function [rec] (integer) Count(map<integer,integer> a, integer n, integer v) { if(n <= 0) {0} else { if(a[n-1] == v) {1 + Count(a,n-1,v)} else {Count(a,n-1,v)} } }
@*/
void insertion_sort(int n, int *a)
/*@ requires 0 <= n; n <= 2147483647; take A = each(integer i; 0 <= i && i < n) {RW<int>(array_shift<int>(a,i))}; ensures take B = each(integer i; 0 <= i && i < n) {RW<int>(array_shift<int>(a,i))}; each(integer i; 0 <= i && i < n-1) {B[i] <= B[i+1]}; each(integer i; 0 <= i && i < n) {Count(A,n,A[i]) == Count(B,n,A[i])}; each(integer i; 0 <= i && i < n) {Count(A,n,B[i]) == Count(B,n,B[i])}; @*/
{
    int i;
    int j;
    int key;

    for (i = 1; i < n; ++i) {
        key = a[i];
        j = i - 1;
        while (j >= 0 && a[j] < key) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = key;
    }
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: { int a[1] = {0}; insertion_sort(0, a); return 0; }
case 1: { int a[1] = {(-2147483647 - 1)}; insertion_sort(1, a); return 0; }
case 2: { int a[2] = {(-2147483647 - 1), (-2147483647 - 1)}; insertion_sort(2, a); return 0; }
case 3: { int a[3] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)}; insertion_sort(3, a); return 0; }
case 4: { int a[4] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)}; insertion_sort(4, a); return 0; }
case 5: { int a[8] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)}; insertion_sort(8, a); return 0; }
case 6: { int a[16] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)}; insertion_sort(16, a); return 0; }
case 7: { int a[1] = {2147483647}; insertion_sort(1, a); return 0; }
case 8: { int a[2] = {(-2147483647 - 1), -2147483647}; insertion_sort(2, a); return 0; }
case 9: { int a[3] = {-2147483647, -100, -1}; insertion_sort(3, a); return 0; }
case 10: { int a[4] = {-100, -1, 0, 1}; insertion_sort(4, a); return 0; }
case 11: { int a[8] = {-1, 0, 1, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647}; insertion_sort(8, a); return 0; }
case 12: { int a[16] = {0, 1, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -1, 0, 1, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647}; insertion_sort(16, a); return 0; }
case 13: { int a[1] = {1}; insertion_sort(1, a); return 0; }
case 14: { int a[2] = {2147483646, -2147483647}; insertion_sort(2, a); return 0; }
case 15: { int a[3] = {2147483647, 0, -100}; insertion_sort(3, a); return 0; }
case 16: { int a[4] = {2147483646, 1, 1, -1}; insertion_sort(4, a); return 0; }
case 17: { int a[8] = {2147483646, 2147483646, 2147483646, 100, -100, -2147483647, (-2147483647 - 1), (-2147483647 - 1)}; insertion_sort(8, a); return 0; }
case 18: { int a[16] = {2147483647, 100, 100, 100, 100, 1, 1, 1, 0, 0, 0, -1, -100, -100, -2147483647, (-2147483647 - 1)}; insertion_sort(16, a); return 0; }
case 19: { int a[1] = {0}; insertion_sort(1, a); return 0; }
case 20: { int a[2] = {-100, 2147483647}; insertion_sort(2, a); return 0; }
case 21: { int a[3] = {-100, 100, 2147483646}; insertion_sort(3, a); return 0; }
case 22: { int a[4] = {(-2147483647 - 1), 1, 100, 2147483646}; insertion_sort(4, a); return 0; }
case 23: { int a[8] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), 0, 100, 2147483647, 2147483647, 2147483647}; insertion_sort(8, a); return 0; }
case 24: { int a[16] = {(-2147483647 - 1), (-2147483647 - 1), -2147483647, -2147483647, -2147483647, -100, -100, 0, 0, 2147483646, 2147483646, 2147483647, 2147483647, 2147483647, 2147483647, 2147483647}; insertion_sort(16, a); return 0; }
case 25: { int a[1] = {223406556}; insertion_sort(1, a); return 0; }
case 26: { int a[2] = {617865469, 1266513166}; insertion_sort(2, a); return 0; }
case 27: { int a[3] = {1114208779, 394273271, 1180827568}; insertion_sort(3, a); return 0; }
case 28: { int a[4] = {1726544480, 374059776, -662961268, -69631889}; insertion_sort(4, a); return 0; }
case 29: { int a[8] = {1392402695, 924985941, 2095640952, -594437444, 423149033, 190991604, 939240215, 2142139567}; insertion_sort(8, a); return 0; }
case 30: { int a[16] = {-997193837, -1303128720, -2060693665, 248560309, 1631517721, -210343047, -239065941, -1136420893, 1362524750, 712947170, -724675038, 453749520, -1291849024, -1816894818, 2086214534, 265588704}; insertion_sort(16, a); return 0; }
case 31: { int a[1] = {-2147483647}; insertion_sort(1, a); return 0; }
case 32: { int a[2] = {-2147483647, -2147483647}; insertion_sort(2, a); return 0; }
case 33: { int a[3] = {-2147483647, -2147483647, -2147483647}; insertion_sort(3, a); return 0; }
case 34: { int a[4] = {-2147483647, -2147483647, -2147483647, -2147483647}; insertion_sort(4, a); return 0; }
case 35: { int a[8] = {-2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647}; insertion_sort(8, a); return 0; }
case 36: { int a[16] = {-2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647}; insertion_sort(16, a); return 0; }
case 37: { int a[1] = {2147483646}; insertion_sort(1, a); return 0; }
case 38: { int a[2] = {2147483647, (-2147483647 - 1)}; insertion_sort(2, a); return 0; }
case 39: { int a[3] = {(-2147483647 - 1), -2147483647, -100}; insertion_sort(3, a); return 0; }
case 40: { int a[4] = {-2147483647, -100, -1, 0}; insertion_sort(4, a); return 0; }
case 41: { int a[8] = {-100, -1, 0, 1, 100, 2147483646, 2147483647, (-2147483647 - 1)}; insertion_sort(8, a); return 0; }
case 42: { int a[16] = {-1, 0, 1, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -1, 0, 1, 100, 2147483646, 2147483647, (-2147483647 - 1)}; insertion_sort(16, a); return 0; }
case 43: { int a[1] = {-1}; insertion_sort(1, a); return 0; }
case 44: { int a[2] = {-1, (-2147483647 - 1)}; insertion_sort(2, a); return 0; }
case 45: { int a[3] = {2147483646, 2147483646, (-2147483647 - 1)}; insertion_sort(3, a); return 0; }
case 46: { int a[4] = {2147483647, 100, 0, -100}; insertion_sort(4, a); return 0; }
case 47: { int a[8] = {2147483647, 2147483647, 100, 100, 0, -2147483647, (-2147483647 - 1), (-2147483647 - 1)}; insertion_sort(8, a); return 0; }
case 48: { int a[16] = {2147483647, 2147483646, 100, 100, 1, 1, 0, -1, -1, -1, -100, -100, -100, -100, (-2147483647 - 1), (-2147483647 - 1)}; insertion_sort(16, a); return 0; }
case 49: { int a[2] = {-2147483647, 0}; insertion_sort(2, a); return 0; }
case 50: { int a[3] = {-100, 0, 0}; insertion_sort(3, a); return 0; }
case 51: { int a[4] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), 0}; insertion_sort(4, a); return 0; }
case 52: { int a[8] = {(-2147483647 - 1), (-2147483647 - 1), 1, 1, 2147483647, 2147483647, 2147483647, 2147483647}; insertion_sort(8, a); return 0; }
case 53: { int a[16] = {(-2147483647 - 1), -2147483647, -100, -100, -1, 0, 0, 1, 1, 100, 2147483646, 2147483647, 2147483647, 2147483647, 2147483647, 2147483647}; insertion_sort(16, a); return 0; }
case 54: { int a[1] = {-27507951}; insertion_sort(1, a); return 0; }
case 55: { int a[2] = {664021708, -1446294794}; insertion_sort(2, a); return 0; }
case 56: { int a[3] = {-1069282466, -200547056, 2056106113}; insertion_sort(3, a); return 0; }
case 57: { int a[4] = {2006128915, 1521112263, -19994936, 854870091}; insertion_sort(4, a); return 0; }
case 58: { int a[8] = {-557894232, 918298044, -208703394, -431630919, 698507150, 951246702, 1613914206, -1074286399}; insertion_sort(8, a); return 0; }
case 59: { int a[16] = {1687535836, -756053316, 720630002, -106400218, 2095158344, -1759107479, 934108658, -579500865, 1628019954, 592919359, -2050622355, 114559393, 52264846, 1654188971, -1933844997, -1158074238}; insertion_sort(16, a); return 0; }
case 60: { int a[1] = {-100}; insertion_sort(1, a); return 0; }
case 61: { int a[2] = {-100, -100}; insertion_sort(2, a); return 0; }
case 62: { int a[3] = {-100, -100, -100}; insertion_sort(3, a); return 0; }
case 63: { int a[4] = {-100, -100, -100, -100}; insertion_sort(4, a); return 0; }
case 64: { int a[8] = {-100, -100, -100, -100, -100, -100, -100, -100}; insertion_sort(8, a); return 0; }
case 65: { int a[16] = {-100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100}; insertion_sort(16, a); return 0; }
case 66: { int a[1] = {100}; insertion_sort(1, a); return 0; }
case 67: { int a[2] = {2147483646, 2147483647}; insertion_sort(2, a); return 0; }
case 68: { int a[3] = {2147483647, (-2147483647 - 1), -2147483647}; insertion_sort(3, a); return 0; }
case 69: { int a[4] = {(-2147483647 - 1), -2147483647, -100, -1}; insertion_sort(4, a); return 0; }
case 70: { int a[8] = {-2147483647, -100, -1, 0, 1, 100, 2147483646, 2147483647}; insertion_sort(8, a); return 0; }
case 71: { int a[16] = {-100, -1, 0, 1, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -1, 0, 1, 100, 2147483646, 2147483647}; insertion_sort(16, a); return 0; }
case 72: { int a[2] = {100, -1}; insertion_sort(2, a); return 0; }
case 73: { int a[3] = {2147483647, 0, -1}; insertion_sort(3, a); return 0; }
case 74: { int a[4] = {2147483647, 1, -2147483647, (-2147483647 - 1)}; insertion_sort(4, a); return 0; }
case 75: { int a[8] = {2147483646, 100, 1, 0, 0, -1, -100, (-2147483647 - 1)}; insertion_sort(8, a); return 0; }
case 76: { int a[16] = {2147483647, 2147483647, 2147483647, 2147483647, 2147483647, 2147483646, 2147483646, 100, 100, 100, 1, -1, -1, -1, -100, -100}; insertion_sort(16, a); return 0; }
case 77: { int a[2] = {-100, -1}; insertion_sort(2, a); return 0; }
case 78: { int a[3] = {0, 100, 100}; insertion_sort(3, a); return 0; }
case 79: { int a[4] = {100, 100, 100, 2147483646}; insertion_sort(4, a); return 0; }
case 80: { int a[8] = {-2147483647, 0, 100, 2147483646, 2147483646, 2147483646, 2147483647, 2147483647}; insertion_sort(8, a); return 0; }
case 81: { int a[16] = {-2147483647, -2147483647, -2147483647, 0, 0, 0, 0, 1, 1, 1, 100, 100, 100, 2147483646, 2147483647, 2147483647}; insertion_sort(16, a); return 0; }
case 82: { int a[1] = {404854496}; insertion_sort(1, a); return 0; }
case 83: { int a[2] = {744974972, -1272459911}; insertion_sort(2, a); return 0; }
case 84: { int a[3] = {737268112, -1068229680, -1451172589}; insertion_sort(3, a); return 0; }
case 85: { int a[4] = {-101780263, -1258234898, -152320547, -291012452}; insertion_sort(4, a); return 0; }
case 86: { int a[8] = {-1848074038, 663289720, 815642197, -46694898, 1298010804, 1192953353, 224166788, -1599344655}; insertion_sort(8, a); return 0; }
case 87: { int a[16] = {683818026, -219468548, 67120118, 385534353, 645458742, -1353089488, -1752403606, -114207157, -462996215, 1142464526, 105842754, -206473950, 1868606285, -757973160, -1296226354, -1096721974}; insertion_sort(16, a); return 0; }
case 88: { int a[2] = {-1, -1}; insertion_sort(2, a); return 0; }
case 89: { int a[3] = {-1, -1, -1}; insertion_sort(3, a); return 0; }
case 90: { int a[4] = {-1, -1, -1, -1}; insertion_sort(4, a); return 0; }
case 91: { int a[8] = {-1, -1, -1, -1, -1, -1, -1, -1}; insertion_sort(8, a); return 0; }
case 92: { int a[16] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}; insertion_sort(16, a); return 0; }
case 93: { int a[2] = {100, 2147483646}; insertion_sort(2, a); return 0; }
case 94: { int a[3] = {2147483646, 2147483647, (-2147483647 - 1)}; insertion_sort(3, a); return 0; }
case 95: { int a[4] = {2147483647, (-2147483647 - 1), -2147483647, -100}; insertion_sort(4, a); return 0; }
case 96: { int a[8] = {(-2147483647 - 1), -2147483647, -100, -1, 0, 1, 100, 2147483646}; insertion_sort(8, a); return 0; }
case 97: { int a[16] = {-2147483647, -100, -1, 0, 1, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -1, 0, 1, 100, 2147483646}; insertion_sort(16, a); return 0; }
case 98: { int a[3] = {0, 0, -100}; insertion_sort(3, a); return 0; }
case 99: { int a[4] = {2147483647, -1, -1, (-2147483647 - 1)}; insertion_sort(4, a); return 0; }
case 100: { int a[8] = {2147483647, 2147483646, 100, 1, -1, -1, -2147483647, (-2147483647 - 1)}; insertion_sort(8, a); return 0; }
case 101: { int a[16] = {2147483647, 2147483647, 2147483646, 2147483646, 100, 1, 0, 0, -1, -1, -1, -1, -100, -2147483647, -2147483647, (-2147483647 - 1)}; insertion_sort(16, a); return 0; }
case 102: { int a[3] = {(-2147483647 - 1), -1, 100}; insertion_sort(3, a); return 0; }
case 103: { int a[4] = {-2147483647, 100, 2147483646, 2147483647}; insertion_sort(4, a); return 0; }
case 104: { int a[8] = {-100, -1, 0, 0, 0, 100, 2147483646, 2147483647}; insertion_sort(8, a); return 0; }
case 105: { int a[16] = {-2147483647, -2147483647, -2147483647, -100, -1, -1, 0, 0, 1, 1, 1, 1, 100, 100, 2147483646, 2147483647}; insertion_sort(16, a); return 0; }
case 106: { int a[1] = {-316466477}; insertion_sort(1, a); return 0; }
case 107: { int a[2] = {-1522895720, 852710999}; insertion_sort(2, a); return 0; }
case 108: { int a[3] = {2084105685, 233137520, -337062465}; insertion_sort(3, a); return 0; }
case 109: { int a[4] = {-1172095830, -268479557, -780427405, -1460333914}; insertion_sort(4, a); return 0; }
case 110: { int a[8] = {-1839703333, -680640243, -2005772941, -499696307, -1586496354, 1852105981, -1426678154, -1891207262}; insertion_sort(8, a); return 0; }
case 111: { int a[16] = {787790455, -1472570231, -327449500, -1612594943, 1182243097, -246558382, 34658714, 1953417002, 1377651849, -1837035599, -2115529950, -248841112, 1169399141, -1880465423, 668639790, 1948571610}; insertion_sort(16, a); return 0; }
case 112: { int a[2] = {0, 0}; insertion_sort(2, a); return 0; }
case 113: { int a[3] = {0, 0, 0}; insertion_sort(3, a); return 0; }
case 114: { int a[4] = {0, 0, 0, 0}; insertion_sort(4, a); return 0; }
case 115: { int a[8] = {0, 0, 0, 0, 0, 0, 0, 0}; insertion_sort(8, a); return 0; }
case 116: { int a[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; insertion_sort(16, a); return 0; }
case 117: { int a[2] = {1, 100}; insertion_sort(2, a); return 0; }
case 118: { int a[3] = {100, 2147483646, 2147483647}; insertion_sort(3, a); return 0; }
case 119: { int a[4] = {2147483646, 2147483647, (-2147483647 - 1), -2147483647}; insertion_sort(4, a); return 0; }
case 120: { int a[8] = {2147483647, (-2147483647 - 1), -2147483647, -100, -1, 0, 1, 100}; insertion_sort(8, a); return 0; }
case 121: { int a[16] = {(-2147483647 - 1), -2147483647, -100, -1, 0, 1, 100, 2147483646, 2147483647, (-2147483647 - 1), -2147483647, -100, -1, 0, 1, 100}; insertion_sort(16, a); return 0; }
case 122: { int a[2] = {-1, -2147483647}; insertion_sort(2, a); return 0; }
case 123: { int a[3] = {2147483647, -100, -2147483647}; insertion_sort(3, a); return 0; }
case 124: { int a[4] = {2147483647, 100, -100, (-2147483647 - 1)}; insertion_sort(4, a); return 0; }
case 125: { int a[8] = {100, 0, -1, -1, -1, -1, (-2147483647 - 1), (-2147483647 - 1)}; insertion_sort(8, a); return 0; }
case 126: { int a[16] = {2147483647, 2147483647, 2147483646, 100, 1, 1, 0, 0, -1, -1, -2147483647, -2147483647, -2147483647, -2147483647, (-2147483647 - 1), (-2147483647 - 1)}; insertion_sort(16, a); return 0; }
case 127: { int a[3] = {-1, 2147483646, 2147483647}; insertion_sort(3, a); return 0; }
default: return 13; } }
