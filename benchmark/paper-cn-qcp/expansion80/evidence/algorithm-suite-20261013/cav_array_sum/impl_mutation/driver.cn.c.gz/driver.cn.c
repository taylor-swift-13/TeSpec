/*@
function [rec] (integer) Sum(map<integer,integer> a, integer n) { if(n <= 0) {0} else {a[n-1] + Sum(a,n-1)} }
@*/
int array_sum(int n, int *a)
/*@ requires 0 <= n; n <= 10000; take A = each(integer i; 0 <= i && i < n) {RW<int>(array_shift<int>(a,i))}; each(integer i; 0 <= i && i < n) {-10000 <= A[i] && A[i] <= 10000}; -2147483648 <= Sum(A,n); Sum(A,n) <= 2147483647; ensures take B = each(integer i; 0 <= i && i < n) {RW<int>(array_shift<int>(a,i))}; B == A; return == Sum(A,n); @*/
{
    int i;
    int ret = 0;

    for (i = 0; i < n; ++i) {
        ret -= a[i];
    }

    return ret;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: { int a[1] = {0}; array_sum(0, a); return 0; }
case 1: { int a[1] = {-10000}; array_sum(1, a); return 0; }
case 2: { int a[2] = {-10000, -10000}; array_sum(2, a); return 0; }
case 3: { int a[3] = {-10000, -10000, -10000}; array_sum(3, a); return 0; }
case 4: { int a[4] = {-10000, -10000, -10000, -10000}; array_sum(4, a); return 0; }
case 5: { int a[8] = {-10000, -10000, -10000, -10000, -10000, -10000, -10000, -10000}; array_sum(8, a); return 0; }
case 6: { int a[16] = {-10000, -10000, -10000, -10000, -10000, -10000, -10000, -10000, -10000, -10000, -10000, -10000, -10000, -10000, -10000, -10000}; array_sum(16, a); return 0; }
case 7: { int a[1] = {1}; array_sum(1, a); return 0; }
case 8: { int a[2] = {10000, -10000}; array_sum(2, a); return 0; }
case 9: { int a[3] = {-10000, -1, 0}; array_sum(3, a); return 0; }
case 10: { int a[4] = {-1, 0, 1, 10000}; array_sum(4, a); return 0; }
case 11: { int a[8] = {0, 1, 10000, -10000, -1, 0, 1, 10000}; array_sum(8, a); return 0; }
case 12: { int a[16] = {1, 10000, -10000, -1, 0, 1, 10000, -10000, -1, 0, 1, 10000, -10000, -1, 0, 1}; array_sum(16, a); return 0; }
case 13: { int a[3] = {10000, 0, -1}; array_sum(3, a); return 0; }
case 14: { int a[4] = {10000, 1, 0, 0}; array_sum(4, a); return 0; }
case 15: { int a[8] = {10000, 10000, 10000, 1, -1, -1, -10000, -10000}; array_sum(8, a); return 0; }
case 16: { int a[16] = {10000, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, -1, -1, -10000, -10000}; array_sum(16, a); return 0; }
case 17: { int a[1] = {0}; array_sum(1, a); return 0; }
case 18: { int a[2] = {-1, 10000}; array_sum(2, a); return 0; }
case 19: { int a[3] = {-1, 1, 10000}; array_sum(3, a); return 0; }
case 20: { int a[4] = {-10000, 1, 1, 10000}; array_sum(4, a); return 0; }
case 21: { int a[8] = {-10000, -10000, -10000, 0, 1, 10000, 10000, 10000}; array_sum(8, a); return 0; }
case 22: { int a[16] = {-10000, -10000, -10000, -10000, -1, -1, -1, 0, 0, 10000, 10000, 10000, 10000, 10000, 10000, 10000}; array_sum(16, a); return 0; }
case 23: { int a[1] = {8088}; array_sum(1, a); return 0; }
case 24: { int a[2] = {1810, 3217}; array_sum(2, a); return 0; }
case 25: { int a[3] = {-5260, -7096, 7670}; array_sum(3, a); return 0; }
case 26: { int a[4] = {7802, -9716, 4692, -3720}; array_sum(4, a); return 0; }
case 27: { int a[8] = {9268, 5095, -7776, 7572, 9392, 2832, -6123, 4668}; array_sum(8, a); return 0; }
case 28: { int a[16] = {9237, 737, -766, 6516, 8740, 1326, 5229, 5852, 2548, -8496, -908, -2864, -2759, 1848, -623, 9612}; array_sum(16, a); return 0; }
case 29: { int a[1] = {-1}; array_sum(1, a); return 0; }
case 30: { int a[2] = {-1, -1}; array_sum(2, a); return 0; }
case 31: { int a[3] = {-1, -1, -1}; array_sum(3, a); return 0; }
case 32: { int a[4] = {-1, -1, -1, -1}; array_sum(4, a); return 0; }
case 33: { int a[8] = {-1, -1, -1, -1, -1, -1, -1, -1}; array_sum(8, a); return 0; }
case 34: { int a[16] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}; array_sum(16, a); return 0; }
case 35: { int a[2] = {1, -1}; array_sum(2, a); return 0; }
case 36: { int a[3] = {1, -1, -10000}; array_sum(3, a); return 0; }
case 37: { int a[4] = {10000, 1, 1, 0}; array_sum(4, a); return 0; }
case 38: { int a[8] = {10000, 10000, 10000, 1, 0, -1, -10000, -10000}; array_sum(8, a); return 0; }
case 39: { int a[16] = {10000, 10000, 1, 0, 0, 0, 0, -1, -1, -1, -1, -1, -10000, -10000, -10000, -10000}; array_sum(16, a); return 0; }
case 40: { int a[2] = {1, 10000}; array_sum(2, a); return 0; }
case 41: { int a[3] = {0, 10000, 10000}; array_sum(3, a); return 0; }
case 42: { int a[4] = {-1, 0, 1, 1}; array_sum(4, a); return 0; }
case 43: { int a[8] = {-10000, 1, 1, 1, 10000, 10000, 10000, 10000}; array_sum(8, a); return 0; }
case 44: { int a[16] = {-1, -1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 10000, 10000, 10000, 10000}; array_sum(16, a); return 0; }
case 45: { int a[1] = {-4484}; array_sum(1, a); return 0; }
case 46: { int a[2] = {1973, -2128}; array_sum(2, a); return 0; }
case 47: { int a[3] = {-4028, 6757, -6605}; array_sum(3, a); return 0; }
case 48: { int a[4] = {5270, 7847, -1117, -9034}; array_sum(4, a); return 0; }
case 49: { int a[8] = {146, -9527, 3631, 2041, -8926, -2034, -7945, 4653}; array_sum(8, a); return 0; }
case 50: { int a[16] = {-33, -4661, 7214, 5739, 6137, 41, -7511, -7916, -7849, -8947, 7449, 10000, 9681, -6723, -8860, -8607}; array_sum(16, a); return 0; }
case 51: { int a[2] = {0, 0}; array_sum(2, a); return 0; }
case 52: { int a[3] = {0, 0, 0}; array_sum(3, a); return 0; }
case 53: { int a[4] = {0, 0, 0, 0}; array_sum(4, a); return 0; }
case 54: { int a[8] = {0, 0, 0, 0, 0, 0, 0, 0}; array_sum(8, a); return 0; }
case 55: { int a[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; array_sum(16, a); return 0; }
case 56: { int a[2] = {0, -10000}; array_sum(2, a); return 0; }
case 57: { int a[16] = {10000, 10000, 10000, 10000, 10000, 1, 1, 1, 1, 0, 0, 0, -1, -10000, -10000, -10000}; array_sum(16, a); return 0; }
case 58: { int a[2] = {-10000, -1}; array_sum(2, a); return 0; }
case 59: { int a[4] = {-1, 0, 0, 1}; array_sum(4, a); return 0; }
case 60: { int a[8] = {-10000, -10000, -1, 1, 1, 10000, 10000, 10000}; array_sum(8, a); return 0; }
case 61: { int a[16] = {-10000, -10000, -1, -1, -1, 0, 0, 0, 0, 1, 1, 10000, 10000, 10000, 10000, 10000}; array_sum(16, a); return 0; }
case 62: { int a[1] = {9786}; array_sum(1, a); return 0; }
case 63: { int a[2] = {4163, 6649}; array_sum(2, a); return 0; }
case 64: { int a[3] = {-7037, 546, -9052}; array_sum(3, a); return 0; }
case 65: { int a[4] = {9564, 9394, 2293, 1962}; array_sum(4, a); return 0; }
case 66: { int a[8] = {-5774, 3304, -1922, 4791, -9262, -5080, 6701, 9079}; array_sum(8, a); return 0; }
case 67: { int a[16] = {7258, 815, 6782, -7051, 762, -8371, 144, -2452, 941, 9705, 4429, 3050, 7977, -9555, 1822, 7308}; array_sum(16, a); return 0; }
case 68: { int a[2] = {1, 1}; array_sum(2, a); return 0; }
case 69: { int a[3] = {1, 1, 1}; array_sum(3, a); return 0; }
case 70: { int a[4] = {1, 1, 1, 1}; array_sum(4, a); return 0; }
case 71: { int a[8] = {1, 1, 1, 1, 1, 1, 1, 1}; array_sum(8, a); return 0; }
case 72: { int a[16] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}; array_sum(16, a); return 0; }
case 73: { int a[3] = {10000, 1, -10000}; array_sum(3, a); return 0; }
case 74: { int a[4] = {0, 0, 0, -1}; array_sum(4, a); return 0; }
case 75: { int a[8] = {10000, 10000, 10000, 1, -1, -1, -1, -10000}; array_sum(8, a); return 0; }
case 76: { int a[16] = {10000, 10000, 10000, 1, 1, 1, 1, 1, 1, 0, -1, -1, -1, -1, -1, -1}; array_sum(16, a); return 0; }
case 77: { int a[3] = {1, 10000, 10000}; array_sum(3, a); return 0; }
case 78: { int a[4] = {0, 1, 10000, 10000}; array_sum(4, a); return 0; }
case 79: { int a[8] = {-10000, -10000, -10000, 0, 0, 0, 1, 10000}; array_sum(8, a); return 0; }
case 80: { int a[16] = {-10000, -10000, -1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 10000, 10000, 10000, 10000}; array_sum(16, a); return 0; }
case 81: { int a[1] = {9778}; array_sum(1, a); return 0; }
case 82: { int a[2] = {4903, 7879}; array_sum(2, a); return 0; }
case 83: { int a[3] = {-5423, 3929, -1766}; array_sum(3, a); return 0; }
case 84: { int a[4] = {2131, -9910, 5689, -4688}; array_sum(4, a); return 0; }
case 85: { int a[8] = {-6391, 7719, 5607, -2127, -3216, 4082, 5221, 2352}; array_sum(8, a); return 0; }
case 86: { int a[16] = {4163, 2128, -7716, -6373, -6643, 1998, 6027, 5082, -1349, -3950, 8094, 1640, -3553, 9841, -3182, 1506}; array_sum(16, a); return 0; }
case 87: { int a[1] = {10000}; array_sum(1, a); return 0; }
case 88: { int a[2] = {10000, 10000}; array_sum(2, a); return 0; }
case 89: { int a[3] = {10000, 10000, 10000}; array_sum(3, a); return 0; }
case 90: { int a[4] = {10000, 10000, 10000, 10000}; array_sum(4, a); return 0; }
case 91: { int a[8] = {10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000}; array_sum(8, a); return 0; }
case 92: { int a[16] = {10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000}; array_sum(16, a); return 0; }
case 93: { int a[2] = {10000, -1}; array_sum(2, a); return 0; }
case 94: { int a[3] = {10000, 10000, 1}; array_sum(3, a); return 0; }
case 95: { int a[4] = {0, 0, -1, -10000}; array_sum(4, a); return 0; }
case 96: { int a[8] = {10000, 1, 1, 1, 1, 0, -10000, -10000}; array_sum(8, a); return 0; }
case 97: { int a[16] = {10000, 10000, 10000, 10000, 10000, 10000, 10000, 1, 1, 1, 1, 0, 0, -1, -1, -10000}; array_sum(16, a); return 0; }
case 98: { int a[2] = {-10000, 1}; array_sum(2, a); return 0; }
case 99: { int a[3] = {-10000, -10000, 0}; array_sum(3, a); return 0; }
case 100: { int a[4] = {0, 0, 1, 1}; array_sum(4, a); return 0; }
case 101: { int a[8] = {-10000, -10000, -1, 0, 1, 1, 10000, 10000}; array_sum(8, a); return 0; }
case 102: { int a[16] = {-10000, -10000, -10000, -1, -1, -1, -1, -1, -1, 0, 1, 1, 1, 10000, 10000, 10000}; array_sum(16, a); return 0; }
case 103: { int a[1] = {8681}; array_sum(1, a); return 0; }
case 104: { int a[2] = {4884, 2678}; array_sum(2, a); return 0; }
case 105: { int a[3] = {3234, -5199, 3417}; array_sum(3, a); return 0; }
case 106: { int a[4] = {-1647, -6343, 8923, -4505}; array_sum(4, a); return 0; }
case 107: { int a[8] = {-9502, 5635, 1240, -7656, -6275, 1346, 3919, -5506}; array_sum(8, a); return 0; }
case 108: { int a[16] = {7387, 5513, -5221, -3083, 1869, 6904, 372, -1413, 1309, 6357, 7941, -1359, 7536, 1198, 4668, -5648}; array_sum(16, a); return 0; }
case 109: { int a[2] = {10000, 0}; array_sum(2, a); return 0; }
case 110: { int a[4] = {0, -1, -1, -10000}; array_sum(4, a); return 0; }
case 111: { int a[8] = {1, 0, 0, 0, -1, -1, -10000, -10000}; array_sum(8, a); return 0; }
case 112: { int a[16] = {10000, 10000, 10000, 10000, 10000, 10000, 1, 1, 0, -1, -1, -1, -1, -1, -10000, -10000}; array_sum(16, a); return 0; }
case 113: { int a[2] = {-1, 1}; array_sum(2, a); return 0; }
case 114: { int a[3] = {-10000, 1, 1}; array_sum(3, a); return 0; }
case 115: { int a[4] = {-10000, 10000, 10000, 10000}; array_sum(4, a); return 0; }
case 116: { int a[8] = {-10000, -10000, -1, -1, 0, 0, 1, 1}; array_sum(8, a); return 0; }
case 117: { int a[16] = {-10000, -10000, -10000, -10000, -10000, -10000, -1, -1, 0, 0, 0, 0, 1, 1, 1, 10000}; array_sum(16, a); return 0; }
case 118: { int a[1] = {4485}; array_sum(1, a); return 0; }
case 119: { int a[2] = {4237, 810}; array_sum(2, a); return 0; }
case 120: { int a[3] = {7992, 7324, -8683}; array_sum(3, a); return 0; }
case 121: { int a[4] = {9415, 7116, -6576, 202}; array_sum(4, a); return 0; }
case 122: { int a[8] = {-7963, -454, 5271, 239, -564, 1758, -5706, 5978}; array_sum(8, a); return 0; }
case 123: { int a[16] = {-6059, -871, -6588, 3763, -4711, -96, -1807, 7232, -9954, 3537, -619, 6781, 6465, 3521, 3802, 969}; array_sum(16, a); return 0; }
case 124: { int a[3] = {0, 0, -10000}; array_sum(3, a); return 0; }
case 125: { int a[4] = {0, -1, -10000, -10000}; array_sum(4, a); return 0; }
case 126: { int a[8] = {10000, 10000, 10000, 0, 0, -1, -10000, -10000}; array_sum(8, a); return 0; }
case 127: { int a[16] = {10000, 10000, 10000, 1, 1, 1, 0, 0, -1, -1, -10000, -10000, -10000, -10000, -10000, -10000}; array_sum(16, a); return 0; }
default: return 13; } }
