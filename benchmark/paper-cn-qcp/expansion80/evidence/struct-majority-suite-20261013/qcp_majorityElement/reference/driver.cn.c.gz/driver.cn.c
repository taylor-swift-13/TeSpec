/*@
function [rec] (integer) Count(map<integer,integer> a, integer n, integer v) { if(n <= 0) {0} else { if(a[n-1] == v) {1 + Count(a,n-1,v)} else {Count(a,n-1,v)} } }
function [rec] (integer) MaxCount(map<integer,integer> a, integer n) { if(n <= 0) {0} else { if(Count(a,n,a[n-1]) > MaxCount(a,n-1)) {Count(a,n,a[n-1])} else {MaxCount(a,n-1)} } }
@*/









int majorityElement(int* nums, int numsSize)
/*@ requires 1 <= numsSize; numsSize <= 50000; take A = each(integer i; 0 <= i && i < numsSize) {RW<int>(array_shift<int>(nums,i))}; 2 * MaxCount(A,numsSize) > numsSize; ensures take B = each(integer i; 0 <= i && i < numsSize) {RW<int>(array_shift<int>(nums,i))}; B == A; 2 * Count(A,numsSize,return) > numsSize; @*/
{
    int vote = 0;
    int candidate = 0;
    {
    int i;
    
    for (i = 0; i < numsSize; i++) {
        if (vote == 0) {
            candidate = nums[i];
        }
        vote += (nums[i] == candidate) ? 1 : -1;
    }
    }
    return candidate;
}
int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: { int nums[1] = {(-2147483647 - 1)}; majorityElement(nums, 1); return 0; }
case 1: { int nums[2] = {473873328, 473873328}; majorityElement(nums, 2); return 0; }
case 2: { int nums[3] = {(-2147483647 - 1), (-2147483647 - 1), 0}; majorityElement(nums, 3); return 0; }
case 3: { int nums[4] = {1955792097, 1955792097, 1955792097, 1955792097}; majorityElement(nums, 4); return 0; }
case 4: { int nums[5] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), -100, 2147483646}; majorityElement(nums, 5); return 0; }
case 5: { int nums[8] = {2147483647, 374171191, 374171191, 374171191, 374171191, 374171191, -1, (-2147483647 - 1)}; majorityElement(nums, 8); return 0; }
case 6: { int nums[16] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)}; majorityElement(nums, 16); return 0; }
case 7: { int nums[1] = {-442817132}; majorityElement(nums, 1); return 0; }
case 8: { int nums[2] = {-2147483647, -2147483647}; majorityElement(nums, 2); return 0; }
case 9: { int nums[3] = {925076251, 925076251, 925076251}; majorityElement(nums, 3); return 0; }
case 10: { int nums[4] = {-2147483647, -2147483647, -2147483647, 2147483647}; majorityElement(nums, 4); return 0; }
case 11: { int nums[5] = {-448650161, -448650161, -448650161, 0, (-2147483647 - 1)}; majorityElement(nums, 5); return 0; }
case 12: { int nums[8] = {-2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647}; majorityElement(nums, 8); return 0; }
case 13: { int nums[16] = {2147483646, 2147483646, 1456915023, 1456915023, 1456915023, 1456915023, 1456915023, 1456915023, 1456915023, 1456915023, 1456915023, 100, -1, -2147483647, -2147483647, (-2147483647 - 1)}; majorityElement(nums, 16); return 0; }
case 14: { int nums[1] = {-100}; majorityElement(nums, 1); return 0; }
case 15: { int nums[2] = {-208350282, -208350282}; majorityElement(nums, 2); return 0; }
case 16: { int nums[3] = {(-2147483647 - 1), -100, -100}; majorityElement(nums, 3); return 0; }
case 17: { int nums[4] = {1, -340361175, -340361175, -340361175}; majorityElement(nums, 4); return 0; }
case 18: { int nums[5] = {-100, -100, -100, -100, -100}; majorityElement(nums, 5); return 0; }
case 19: { int nums[8] = {2081350927, 2081350927, 2081350927, 2081350927, 2081350927, 0, (-2147483647 - 1), -1}; majorityElement(nums, 8); return 0; }
case 20: { int nums[16] = {-100, -100, -100, -100, -100, -100, -100, -100, -100, -1, -1, -1, 1, 100, 2147483646, 2147483647}; majorityElement(nums, 16); return 0; }
case 21: { int nums[1] = {773647602}; majorityElement(nums, 1); return 0; }
case 22: { int nums[2] = {-1, -1}; majorityElement(nums, 2); return 0; }
case 23: { int nums[3] = {1505164665, 1505164665, 2147483646}; majorityElement(nums, 3); return 0; }
case 24: { int nums[4] = {-1, -1, -1, -1}; majorityElement(nums, 4); return 0; }
case 25: { int nums[5] = {2147483647, 1114208779, 1114208779, 1114208779, 100}; majorityElement(nums, 5); return 0; }
case 26: { int nums[8] = {-1, -1, -1, -1, 2147483647, 100, -2147483647, -1}; majorityElement(nums, 8); return 0; }
case 27: { int nums[16] = {616164628, 616164628, 616164628, 616164628, 616164628, 616164628, 616164628, 616164628, 616164628, 616164628, 616164628, 616164628, 616164628, 616164628, 616164628, 616164628}; majorityElement(nums, 16); return 0; }
case 28: { int nums[1] = {0}; majorityElement(nums, 1); return 0; }
case 29: { int nums[2] = {-1198357268, -1198357268}; majorityElement(nums, 2); return 0; }
case 30: { int nums[3] = {0, 0, 0}; majorityElement(nums, 3); return 0; }
case 31: { int nums[4] = {190991604, 190991604, 190991604, -100}; majorityElement(nums, 4); return 0; }
case 32: { int nums[5] = {0, 0, 0, 1, 100}; majorityElement(nums, 5); return 0; }
case 33: { int nums[8] = {-1306193384, -1306193384, -1306193384, -1306193384, -1306193384, -1306193384, -1306193384, -1306193384}; majorityElement(nums, 8); return 0; }
case 34: { int nums[16] = {0, 0, (-2147483647 - 1), -1, -1, 100, 0, 100, -1, 0, 0, 0, 0, 0, -2147483647, 0}; majorityElement(nums, 16); return 0; }
case 35: { int nums[1] = {-724675038}; majorityElement(nums, 1); return 0; }
case 36: { int nums[2] = {1, 1}; majorityElement(nums, 2); return 0; }
case 37: { int nums[3] = {453749520, 453749520, -1}; majorityElement(nums, 3); return 0; }
case 38: { int nums[4] = {1, 1, 1, -2147483647}; majorityElement(nums, 4); return 0; }
case 39: { int nums[5] = {772859443, 772859443, 772859443, 772859443, 772859443}; majorityElement(nums, 5); return 0; }
case 40: { int nums[8] = {-2147483647, -2147483647, 1, 1, 1, 1, 1, 2147483646}; majorityElement(nums, 8); return 0; }
case 41: { int nums[16] = {2147483647, 226413706, 226413706, 226413706, 226413706, 226413706, 226413706, 226413706, 226413706, 226413706, 100, 1, 1, -100, (-2147483647 - 1), (-2147483647 - 1)}; majorityElement(nums, 16); return 0; }
case 42: { int nums[1] = {100}; majorityElement(nums, 1); return 0; }
case 43: { int nums[2] = {1003718877, 1003718877}; majorityElement(nums, 2); return 0; }
case 44: { int nums[3] = {100, 100, 2147483647}; majorityElement(nums, 3); return 0; }
case 45: { int nums[4] = {180316251, 180316251, 180316251, 180316251}; majorityElement(nums, 4); return 0; }
case 46: { int nums[5] = {100, 100, -100, 100, -1}; majorityElement(nums, 5); return 0; }
case 47: { int nums[8] = {-422928039, -422928039, -422928039, -422928039, -422928039, 0, -100, 1}; majorityElement(nums, 8); return 0; }
case 48: { int nums[16] = {100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100}; majorityElement(nums, 16); return 0; }
case 49: { int nums[1] = {1746369206}; majorityElement(nums, 1); return 0; }
case 50: { int nums[2] = {2147483646, 2147483646}; majorityElement(nums, 2); return 0; }
case 51: { int nums[3] = {-817611124, -817611124, -817611124}; majorityElement(nums, 3); return 0; }
case 52: { int nums[4] = {100, 2147483646, 2147483646, 2147483646}; majorityElement(nums, 4); return 0; }
case 53: { int nums[5] = {-1, -569155800, -569155800, -569155800, -2147483647}; majorityElement(nums, 5); return 0; }
case 54: { int nums[8] = {2147483646, 2147483646, 2147483646, 2147483646, 2147483646, 2147483646, 2147483646, 2147483646}; majorityElement(nums, 8); return 0; }
case 55: { int nums[16] = {2089814605, 2089814605, 2089814605, 2089814605, 2089814605, 2089814605, 2089814605, 2089814605, 2089814605, -2147483647, -2147483647, (-2147483647 - 1), 2147483647, -2147483647, (-2147483647 - 1), (-2147483647 - 1)}; majorityElement(nums, 16); return 0; }
case 56: { int nums[1] = {2147483647}; majorityElement(nums, 1); return 0; }
case 57: { int nums[2] = {-2034977911, -2034977911}; majorityElement(nums, 2); return 0; }
case 58: { int nums[3] = {2147483647, -2147483647, 2147483647}; majorityElement(nums, 3); return 0; }
case 59: { int nums[4] = {-590014282, -590014282, -590014282, -100}; majorityElement(nums, 4); return 0; }
case 60: { int nums[5] = {2147483647, 2147483647, 2147483647, 2147483647, 2147483647}; majorityElement(nums, 5); return 0; }
case 61: { int nums[8] = {2147483646, 2147483646, 213633940, 213633940, 213633940, 213633940, 213633940, 1}; majorityElement(nums, 8); return 0; }
case 62: { int nums[16] = {2147483647, 2147483647, -1, 2147483647, 0, 2147483647, 2147483647, 2147483647, 2147483647, -100, 2147483647, 100, 2147483646, 2147483646, 2147483647, -2147483647}; majorityElement(nums, 16); return 0; }
case 63: { int nums[1] = {-653564425}; majorityElement(nums, 1); return 0; }
case 64: { int nums[2] = {(-2147483647 - 1), (-2147483647 - 1)}; majorityElement(nums, 2); return 0; }
case 65: { int nums[3] = {-476090976, -476090976, (-2147483647 - 1)}; majorityElement(nums, 3); return 0; }
case 66: { int nums[4] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1)}; majorityElement(nums, 4); return 0; }
case 67: { int nums[5] = {-208703394, -208703394, -208703394, 100, 100}; majorityElement(nums, 5); return 0; }
case 68: { int nums[8] = {(-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), (-2147483647 - 1), -1, 100, 2147483647}; majorityElement(nums, 8); return 0; }
case 69: { int nums[16] = {-313309811, -313309811, -313309811, -313309811, -313309811, -313309811, -313309811, -313309811, -313309811, -313309811, -313309811, -313309811, -313309811, -313309811, -313309811, -313309811}; majorityElement(nums, 16); return 0; }
case 70: { int nums[1] = {-2147483647}; majorityElement(nums, 1); return 0; }
case 71: { int nums[2] = {73551514, 73551514}; majorityElement(nums, 2); return 0; }
case 72: { int nums[3] = {-2147483647, -2147483647, -2147483647}; majorityElement(nums, 3); return 0; }
case 73: { int nums[4] = {2147483647, -506156122, -506156122, -506156122}; majorityElement(nums, 4); return 0; }
case 74: { int nums[5] = {-2147483647, 2147483647, -2147483647, 2147483647, -2147483647}; majorityElement(nums, 5); return 0; }
case 75: { int nums[8] = {720630002, 720630002, 720630002, 720630002, 720630002, 720630002, 720630002, 720630002}; majorityElement(nums, 8); return 0; }
case 76: { int nums[16] = {-2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -2147483647, -100, -100, 1, 1, 100, 2147483646, 2147483647}; majorityElement(nums, 16); return 0; }
case 77: { int nums[1] = {934108658}; majorityElement(nums, 1); return 0; }
case 78: { int nums[2] = {-100, -100}; majorityElement(nums, 2); return 0; }
case 79: { int nums[3] = {803627450, 803627450, -100}; majorityElement(nums, 3); return 0; }
case 80: { int nums[4] = {-100, -100, -100, 2147483646}; majorityElement(nums, 4); return 0; }
case 81: { int nums[5] = {592919359, 592919359, 592919359, 592919359, 592919359}; majorityElement(nums, 5); return 0; }
case 82: { int nums[8] = {(-2147483647 - 1), -100, -100, 100, -1, -100, -100, -100}; majorityElement(nums, 8); return 0; }
case 83: { int nums[16] = {208891740, 208891740, 208891740, 208891740, 208891740, 208891740, 208891740, 208891740, 208891740, 1, 2147483647, -100, -2147483647, 2147483646, -2147483647, 2147483646}; majorityElement(nums, 16); return 0; }
case 84: { int nums[1] = {-1}; majorityElement(nums, 1); return 0; }
case 85: { int nums[2] = {-509314459, -509314459}; majorityElement(nums, 2); return 0; }
case 86: { int nums[3] = {2147483647, -1, -1}; majorityElement(nums, 3); return 0; }
case 87: { int nums[4] = {-1799521464, -1799521464, -1799521464, -1799521464}; majorityElement(nums, 4); return 0; }
case 88: { int nums[5] = {-1, -1, -1, 0, 0}; majorityElement(nums, 5); return 0; }
case 89: { int nums[8] = {-100, -932697150, -932697150, -932697150, -932697150, -932697150, -2147483647, -2147483647}; majorityElement(nums, 8); return 0; }
case 90: { int nums[16] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}; majorityElement(nums, 16); return 0; }
case 91: { int nums[1] = {-610261274}; majorityElement(nums, 1); return 0; }
case 92: { int nums[2] = {0, 0}; majorityElement(nums, 2); return 0; }
case 93: { int nums[3] = {1150703960, 1150703960, 1150703960}; majorityElement(nums, 3); return 0; }
case 94: { int nums[4] = {0, 0, 0, 2147483646}; majorityElement(nums, 4); return 0; }
case 95: { int nums[5] = {155196249, 155196249, 155196249, (-2147483647 - 1), -100}; majorityElement(nums, 5); return 0; }
case 96: { int nums[8] = {0, 0, 0, 0, 0, 0, 0, 0}; majorityElement(nums, 8); return 0; }
case 97: { int nums[16] = {2147483646, 2147483646, 1424013753, 1424013753, 1424013753, 1424013753, 1424013753, 1424013753, 1424013753, 1424013753, 1424013753, 100, -100, -100, (-2147483647 - 1), (-2147483647 - 1)}; majorityElement(nums, 16); return 0; }
case 98: { int nums[1] = {1}; majorityElement(nums, 1); return 0; }
case 99: { int nums[2] = {850460846, 850460846}; majorityElement(nums, 2); return 0; }
case 100: { int nums[3] = {1, 1, 2147483646}; majorityElement(nums, 3); return 0; }
case 101: { int nums[4] = {2147483647, -1334221323, -1334221323, -1334221323}; majorityElement(nums, 4); return 0; }
case 102: { int nums[5] = {1, 1, 1, 1, 1}; majorityElement(nums, 5); return 0; }
case 103: { int nums[8] = {839741405, 839741405, 839741405, 839741405, 839741405, (-2147483647 - 1), 1, 0}; majorityElement(nums, 8); return 0; }
case 104: { int nums[16] = {-2147483647, -100, -1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2147483646, 2147483647, 2147483647}; majorityElement(nums, 16); return 0; }
case 105: { int nums[1] = {-557424419}; majorityElement(nums, 1); return 0; }
case 106: { int nums[2] = {100, 100}; majorityElement(nums, 2); return 0; }
case 107: { int nums[3] = {1843694529, 1843694529, -2147483647}; majorityElement(nums, 3); return 0; }
case 108: { int nums[4] = {100, 100, 100, 100}; majorityElement(nums, 4); return 0; }
case 109: { int nums[5] = {100, -1, -101780263, -101780263, -101780263}; majorityElement(nums, 5); return 0; }
case 110: { int nums[8] = {100, 100, 100, 100, 2147483646, 2147483646, 100, 2147483647}; majorityElement(nums, 8); return 0; }
case 111: { int nums[16] = {1298010804, 1298010804, 1298010804, 1298010804, 1298010804, 1298010804, 1298010804, 1298010804, 1298010804, 1298010804, 1298010804, 1298010804, 1298010804, 1298010804, 1298010804, 1298010804}; majorityElement(nums, 16); return 0; }
case 112: { int nums[1] = {2147483646}; majorityElement(nums, 1); return 0; }
case 113: { int nums[2] = {1192953353, 1192953353}; majorityElement(nums, 2); return 0; }
case 114: { int nums[3] = {2147483646, 2147483646, 2147483646}; majorityElement(nums, 3); return 0; }
case 115: { int nums[4] = {-1599344655, -1599344655, -1599344655, -100}; majorityElement(nums, 4); return 0; }
case 116: { int nums[5] = {(-2147483647 - 1), 1, 2147483646, 2147483646, 2147483646}; majorityElement(nums, 5); return 0; }
case 117: { int nums[8] = {-219468548, -219468548, -219468548, -219468548, -219468548, -219468548, -219468548, -219468548}; majorityElement(nums, 8); return 0; }
case 118: { int nums[16] = {(-2147483647 - 1), -2147483647, 2147483646, 1, 2147483646, 100, 2147483646, 2147483646, -2147483647, 1, 2147483646, 100, 2147483646, 2147483646, 2147483646, 2147483646}; majorityElement(nums, 16); return 0; }
case 119: { int nums[1] = {-206473950}; majorityElement(nums, 1); return 0; }
case 120: { int nums[2] = {2147483647, 2147483647}; majorityElement(nums, 2); return 0; }
case 121: { int nums[3] = {1868606285, 1868606285, 1}; majorityElement(nums, 3); return 0; }
case 122: { int nums[4] = {2147483647, 2147483647, (-2147483647 - 1), 2147483647}; majorityElement(nums, 4); return 0; }
case 123: { int nums[5] = {1189571782, 1189571782, 1189571782, 1189571782, 1189571782}; majorityElement(nums, 5); return 0; }
case 124: { int nums[8] = {(-2147483647 - 1), 100, 2147483646, 2147483647, 2147483647, 2147483647, 2147483647, 2147483647}; majorityElement(nums, 8); return 0; }
case 125: { int nums[16] = {1305716375, 1305716375, 1305716375, 1305716375, 1305716375, 1305716375, 1305716375, 1305716375, 1305716375, 100, 1, 1, -100, -2147483647, (-2147483647 - 1), (-2147483647 - 1)}; majorityElement(nums, 16); return 0; }
case 126: { int nums[2] = {1100648095, 1100648095}; majorityElement(nums, 2); return 0; }
case 127: { int nums[3] = {(-2147483647 - 1), (-2147483647 - 1), 1}; majorityElement(nums, 3); return 0; }
default: return 13; } }
