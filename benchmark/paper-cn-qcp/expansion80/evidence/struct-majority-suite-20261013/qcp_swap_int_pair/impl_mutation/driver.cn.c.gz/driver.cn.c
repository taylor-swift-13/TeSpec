struct int_pair {
    int a;
    int b;
};






void swap_int_pair(struct int_pair *p)
/*@ requires take P = RW<struct int_pair>(p); ensures take Q = RW<struct int_pair>(p); Q.a == P.b; Q.b == P.a; @*/
{
    int temp = p->a;
    p->a = p->b;
    p->b = p->a;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: { struct int_pair p = {(-2147483647 - 1), (-2147483647 - 1)}; swap_int_pair(&p); return 0; }
case 1: { struct int_pair p = {(-2147483647 - 1), 4}; swap_int_pair(&p); return 0; }
case 2: { struct int_pair p = {(-2147483647 - 1), 2004}; swap_int_pair(&p); return 0; }
case 3: { struct int_pair p = {-2147483647, -1}; swap_int_pair(&p); return 0; }
case 4: { struct int_pair p = {-2147483647, 401}; swap_int_pair(&p); return 0; }
case 5: { struct int_pair p = {-2085416551, -569155800}; swap_int_pair(&p); return 0; }
case 6: { struct int_pair p = {-2020781338, -817611124}; swap_int_pair(&p); return 0; }
case 7: { struct int_pair p = {-1979372692, -1213984678}; swap_int_pair(&p); return 0; }
case 8: { struct int_pair p = {-1964832359, -2034977911}; swap_int_pair(&p); return 0; }
case 9: { struct int_pair p = {-1874312103, -1865426505}; swap_int_pair(&p); return 0; }
case 10: { struct int_pair p = {-1816894818, -368513359}; swap_int_pair(&p); return 0; }
case 11: { struct int_pair p = {-1798817410, -509348492}; swap_int_pair(&p); return 0; }
case 12: { struct int_pair p = {-1704322025, -385745401}; swap_int_pair(&p); return 0; }
case 13: { struct int_pair p = {-1639313221, -224889489}; swap_int_pair(&p); return 0; }
case 14: { struct int_pair p = {-1614077301, -739126141}; swap_int_pair(&p); return 0; }
case 15: { struct int_pair p = {-1489931730, 760812310}; swap_int_pair(&p); return 0; }
case 16: { struct int_pair p = {-1424438364, -578059497}; swap_int_pair(&p); return 0; }
case 17: { struct int_pair p = {-1372959571, -749478676}; swap_int_pair(&p); return 0; }
case 18: { struct int_pair p = {-1324309362, -168916292}; swap_int_pair(&p); return 0; }
case 19: { struct int_pair p = {-1284518892, -206899815}; swap_int_pair(&p); return 0; }
case 20: { struct int_pair p = {-1254340058, 1234136023}; swap_int_pair(&p); return 0; }
case 21: { struct int_pair p = {-1198357268, -594437444}; swap_int_pair(&p); return 0; }
case 22: { struct int_pair p = {-1197286771, -1698718698}; swap_int_pair(&p); return 0; }
case 23: { struct int_pair p = {-1182778868, 384909148}; swap_int_pair(&p); return 0; }
case 24: { struct int_pair p = {-1153350431, -1842281490}; swap_int_pair(&p); return 0; }
case 25: { struct int_pair p = {-1136564614, -1707355839}; swap_int_pair(&p); return 0; }
case 26: { struct int_pair p = {-1136420893, 1362524750}; swap_int_pair(&p); return 0; }
case 27: { struct int_pair p = {-1103299341, -1878031518}; swap_int_pair(&p); return 0; }
case 28: { struct int_pair p = {-943452480, -472078869}; swap_int_pair(&p); return 0; }
case 29: { struct int_pair p = {-882356487, 223406556}; swap_int_pair(&p); return 0; }
case 30: { struct int_pair p = {-833421548, -2103008460}; swap_int_pair(&p); return 0; }
case 31: { struct int_pair p = {-771270019, -724675038}; swap_int_pair(&p); return 0; }
case 32: { struct int_pair p = {-739633975, -1303128720}; swap_int_pair(&p); return 0; }
case 33: { struct int_pair p = {-590014282, -778282331}; swap_int_pair(&p); return 0; }
case 34: { struct int_pair p = {-539259348, -1301003036}; swap_int_pair(&p); return 0; }
case 35: { struct int_pair p = {-527930645, -1436904439}; swap_int_pair(&p); return 0; }
case 36: { struct int_pair p = {-517820055, -1906908972}; swap_int_pair(&p); return 0; }
case 37: { struct int_pair p = {-442817132, 925076251}; swap_int_pair(&p); return 0; }
case 38: { struct int_pair p = {-422928039, 1193296589}; swap_int_pair(&p); return 0; }
case 39: { struct int_pair p = {-415021520, -1526126834}; swap_int_pair(&p); return 0; }
case 40: { struct int_pair p = {-365177303, -1918129191}; swap_int_pair(&p); return 0; }
case 41: { struct int_pair p = {-295441907, -448650161}; swap_int_pair(&p); return 0; }
case 42: { struct int_pair p = {-239065941, -1420082841}; swap_int_pair(&p); return 0; }
case 43: { struct int_pair p = {-184254817, -918186301}; swap_int_pair(&p); return 0; }
case 44: { struct int_pair p = {-121626301, -208350282}; swap_int_pair(&p); return 0; }
case 45: { struct int_pair p = {-107942484, -106392811}; swap_int_pair(&p); return 0; }
case 46: { struct int_pair p = {-84499789, -32313518}; swap_int_pair(&p); return 0; }
case 47: { struct int_pair p = {-69631889, -502702748}; swap_int_pair(&p); return 0; }
case 48: { struct int_pair p = {-16074954, 1083878576}; swap_int_pair(&p); return 0; }
case 49: { struct int_pair p = {-400, -2147483647}; swap_int_pair(&p); return 0; }
case 50: { struct int_pair p = {-400, 10}; swap_int_pair(&p); return 0; }
case 51: { struct int_pair p = {-400, 2400}; swap_int_pair(&p); return 0; }
case 52: { struct int_pair p = {-100, 0}; swap_int_pair(&p); return 0; }
case 53: { struct int_pair p = {-100, 1600}; swap_int_pair(&p); return 0; }
case 54: { struct int_pair p = {-10, -100}; swap_int_pair(&p); return 0; }
case 55: { struct int_pair p = {-10, 100}; swap_int_pair(&p); return 0; }
case 56: { struct int_pair p = {-10, 2147483646}; swap_int_pair(&p); return 0; }
case 57: { struct int_pair p = {-2, 2}; swap_int_pair(&p); return 0; }
case 58: { struct int_pair p = {-2, 2000}; swap_int_pair(&p); return 0; }
case 59: { struct int_pair p = {-1, -10}; swap_int_pair(&p); return 0; }
case 60: { struct int_pair p = {-1, 400}; swap_int_pair(&p); return 0; }
case 61: { struct int_pair p = {0, (-2147483647 - 1)}; swap_int_pair(&p); return 0; }
case 62: { struct int_pair p = {0, 4}; swap_int_pair(&p); return 0; }
case 63: { struct int_pair p = {0, 2004}; swap_int_pair(&p); return 0; }
case 64: { struct int_pair p = {1, -1}; swap_int_pair(&p); return 0; }
case 65: { struct int_pair p = {1, 800}; swap_int_pair(&p); return 0; }
case 66: { struct int_pair p = {2, -2147483647}; swap_int_pair(&p); return 0; }
case 67: { struct int_pair p = {2, 10}; swap_int_pair(&p); return 0; }
case 68: { struct int_pair p = {2, 2400}; swap_int_pair(&p); return 0; }
case 69: { struct int_pair p = {4, 0}; swap_int_pair(&p); return 0; }
case 70: { struct int_pair p = {4, 1600}; swap_int_pair(&p); return 0; }
case 71: { struct int_pair p = {9, -100}; swap_int_pair(&p); return 0; }
case 72: { struct int_pair p = {9, 399}; swap_int_pair(&p); return 0; }
case 73: { struct int_pair p = {9, 2147483646}; swap_int_pair(&p); return 0; }
case 74: { struct int_pair p = {10, 2}; swap_int_pair(&p); return 0; }
case 75: { struct int_pair p = {10, 2000}; swap_int_pair(&p); return 0; }
case 76: { struct int_pair p = {100, -10}; swap_int_pair(&p); return 0; }
case 77: { struct int_pair p = {100, 400}; swap_int_pair(&p); return 0; }
case 78: { struct int_pair p = {399, (-2147483647 - 1)}; swap_int_pair(&p); return 0; }
case 79: { struct int_pair p = {399, 9}; swap_int_pair(&p); return 0; }
case 80: { struct int_pair p = {399, 2004}; swap_int_pair(&p); return 0; }
case 81: { struct int_pair p = {400, -1}; swap_int_pair(&p); return 0; }
case 82: { struct int_pair p = {400, 800}; swap_int_pair(&p); return 0; }
case 83: { struct int_pair p = {401, -2147483647}; swap_int_pair(&p); return 0; }
case 84: { struct int_pair p = {401, 10}; swap_int_pair(&p); return 0; }
case 85: { struct int_pair p = {401, 2400}; swap_int_pair(&p); return 0; }
case 86: { struct int_pair p = {800, 1}; swap_int_pair(&p); return 0; }
case 87: { struct int_pair p = {800, 1600}; swap_int_pair(&p); return 0; }
case 88: { struct int_pair p = {1600, -100}; swap_int_pair(&p); return 0; }
case 89: { struct int_pair p = {1600, 399}; swap_int_pair(&p); return 0; }
case 90: { struct int_pair p = {1600, 2147483646}; swap_int_pair(&p); return 0; }
case 91: { struct int_pair p = {1900, 2}; swap_int_pair(&p); return 0; }
case 92: { struct int_pair p = {1900, 2000}; swap_int_pair(&p); return 0; }
case 93: { struct int_pair p = {2000, -2}; swap_int_pair(&p); return 0; }
case 94: { struct int_pair p = {2000, 400}; swap_int_pair(&p); return 0; }
case 95: { struct int_pair p = {2004, (-2147483647 - 1)}; swap_int_pair(&p); return 0; }
case 96: { struct int_pair p = {2004, 9}; swap_int_pair(&p); return 0; }
case 97: { struct int_pair p = {2004, 2004}; swap_int_pair(&p); return 0; }
case 98: { struct int_pair p = {2100, -1}; swap_int_pair(&p); return 0; }
case 99: { struct int_pair p = {2100, 800}; swap_int_pair(&p); return 0; }
case 100: { struct int_pair p = {2400, -400}; swap_int_pair(&p); return 0; }
case 101: { struct int_pair p = {2400, 10}; swap_int_pair(&p); return 0; }
case 102: { struct int_pair p = {2400, 2400}; swap_int_pair(&p); return 0; }
case 103: { struct int_pair p = {113621998, 772859443}; swap_int_pair(&p); return 0; }
case 104: { struct int_pair p = {123091116, -340361175}; swap_int_pair(&p); return 0; }
case 105: { struct int_pair p = {374059776, -662961268}; swap_int_pair(&p); return 0; }
case 106: { struct int_pair p = {473873328, -113257487}; swap_int_pair(&p); return 0; }
case 107: { struct int_pair p = {594602771, -1306193384}; swap_int_pair(&p); return 0; }
case 108: { struct int_pair p = {773647602, 916477127}; swap_int_pair(&p); return 0; }
case 109: { struct int_pair p = {933450800, -840986556}; swap_int_pair(&p); return 0; }
case 110: { struct int_pair p = {1014105484, -870926028}; swap_int_pair(&p); return 0; }
case 111: { struct int_pair p = {1090403763, 1841413406}; swap_int_pair(&p); return 0; }
case 112: { struct int_pair p = {1114208779, 394273271}; swap_int_pair(&p); return 0; }
case 113: { struct int_pair p = {1292042063, 993863069}; swap_int_pair(&p); return 0; }
case 114: { struct int_pair p = {1372079459, 1003718877}; swap_int_pair(&p); return 0; }
case 115: { struct int_pair p = {1392402695, 924985941}; swap_int_pair(&p); return 0; }
case 116: { struct int_pair p = {1456915023, 806008623}; swap_int_pair(&p); return 0; }
case 117: { struct int_pair p = {1641115217, -1831128050}; swap_int_pair(&p); return 0; }
case 118: { struct int_pair p = {1746369206, 191871627}; swap_int_pair(&p); return 0; }
case 119: { struct int_pair p = {1841535299, 2089814605}; swap_int_pair(&p); return 0; }
case 120: { struct int_pair p = {2086214534, 265588704}; swap_int_pair(&p); return 0; }
case 121: { struct int_pair p = {2100409804, 429543933}; swap_int_pair(&p); return 0; }
case 122: { struct int_pair p = {2146483821, 1863533231}; swap_int_pair(&p); return 0; }
case 123: { struct int_pair p = {2147483646, 1}; swap_int_pair(&p); return 0; }
case 124: { struct int_pair p = {2147483646, 1600}; swap_int_pair(&p); return 0; }
case 125: { struct int_pair p = {2147483647, -100}; swap_int_pair(&p); return 0; }
case 126: { struct int_pair p = {2147483647, 399}; swap_int_pair(&p); return 0; }
case 127: { struct int_pair p = {2147483647, 2147483647}; swap_int_pair(&p); return 0; }
default: return 13; } }
