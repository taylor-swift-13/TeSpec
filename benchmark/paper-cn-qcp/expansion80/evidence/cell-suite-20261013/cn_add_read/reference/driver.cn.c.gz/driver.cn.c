unsigned int add (unsigned int *p, unsigned int *q)
/*@ requires take P = RW<unsigned int>(p);
             take Q = RW<unsigned int>(q);
	     P + Q <= MAXu32();
    ensures take P_post = RW<unsigned int>(p);
            take Q_post = RW<unsigned int>(q);
            P == P_post && Q == Q_post;
            return == P + Q;
@*/
{
  unsigned int m = *p;
  unsigned int n = *q;
  return m+n;
}

int getchar(void);
int main(void) /*@ ensures return == 0; @*/ { int index = getchar(); switch(index) {
case 0: { unsigned int p = 0U; unsigned int q = 0U; add(&p, &q); return 0; }
case 1: { unsigned int p = 0U; unsigned int q = 9U; add(&p, &q); return 0; }
case 2: { unsigned int p = 0U; unsigned int q = 401U; add(&p, &q); return 0; }
case 3: { unsigned int p = 0U; unsigned int q = 2004U; add(&p, &q); return 0; }
case 4: { unsigned int p = 0U; unsigned int q = 4294967295U; add(&p, &q); return 0; }
case 5: { unsigned int p = 1U; unsigned int q = 9U; add(&p, &q); return 0; }
case 6: { unsigned int p = 1U; unsigned int q = 401U; add(&p, &q); return 0; }
case 7: { unsigned int p = 1U; unsigned int q = 2000U; add(&p, &q); return 0; }
case 8: { unsigned int p = 2U; unsigned int q = 0U; add(&p, &q); return 0; }
case 9: { unsigned int p = 2U; unsigned int q = 10U; add(&p, &q); return 0; }
case 10: { unsigned int p = 2U; unsigned int q = 401U; add(&p, &q); return 0; }
case 11: { unsigned int p = 2U; unsigned int q = 2004U; add(&p, &q); return 0; }
case 12: { unsigned int p = 4U; unsigned int q = 2U; add(&p, &q); return 0; }
case 13: { unsigned int p = 4U; unsigned int q = 100U; add(&p, &q); return 0; }
case 14: { unsigned int p = 4U; unsigned int q = 1600U; add(&p, &q); return 0; }
case 15: { unsigned int p = 4U; unsigned int q = 2400U; add(&p, &q); return 0; }
case 16: { unsigned int p = 9U; unsigned int q = 4U; add(&p, &q); return 0; }
case 17: { unsigned int p = 9U; unsigned int q = 400U; add(&p, &q); return 0; }
case 18: { unsigned int p = 9U; unsigned int q = 2000U; add(&p, &q); return 0; }
case 19: { unsigned int p = 10U; unsigned int q = 0U; add(&p, &q); return 0; }
case 20: { unsigned int p = 10U; unsigned int q = 10U; add(&p, &q); return 0; }
case 21: { unsigned int p = 10U; unsigned int q = 800U; add(&p, &q); return 0; }
case 22: { unsigned int p = 10U; unsigned int q = 2004U; add(&p, &q); return 0; }
case 23: { unsigned int p = 100U; unsigned int q = 2U; add(&p, &q); return 0; }
case 24: { unsigned int p = 100U; unsigned int q = 399U; add(&p, &q); return 0; }
case 25: { unsigned int p = 100U; unsigned int q = 1600U; add(&p, &q); return 0; }
case 26: { unsigned int p = 100U; unsigned int q = 2400U; add(&p, &q); return 0; }
case 27: { unsigned int p = 191U; unsigned int q = 3031U; add(&p, &q); return 0; }
case 28: { unsigned int p = 241U; unsigned int q = 2536U; add(&p, &q); return 0; }
case 29: { unsigned int p = 320U; unsigned int q = 1780U; add(&p, &q); return 0; }
case 30: { unsigned int p = 348U; unsigned int q = 214U; add(&p, &q); return 0; }
case 31: { unsigned int p = 399U; unsigned int q = 9U; add(&p, &q); return 0; }
case 32: { unsigned int p = 399U; unsigned int q = 400U; add(&p, &q); return 0; }
case 33: { unsigned int p = 399U; unsigned int q = 2000U; add(&p, &q); return 0; }
case 34: { unsigned int p = 400U; unsigned int q = 1U; add(&p, &q); return 0; }
case 35: { unsigned int p = 400U; unsigned int q = 10U; add(&p, &q); return 0; }
case 36: { unsigned int p = 400U; unsigned int q = 800U; add(&p, &q); return 0; }
case 37: { unsigned int p = 400U; unsigned int q = 2100U; add(&p, &q); return 0; }
case 38: { unsigned int p = 401U; unsigned int q = 2U; add(&p, &q); return 0; }
case 39: { unsigned int p = 401U; unsigned int q = 399U; add(&p, &q); return 0; }
case 40: { unsigned int p = 401U; unsigned int q = 1900U; add(&p, &q); return 0; }
case 41: { unsigned int p = 401U; unsigned int q = 2400U; add(&p, &q); return 0; }
case 42: { unsigned int p = 521U; unsigned int q = 537U; add(&p, &q); return 0; }
case 43: { unsigned int p = 630U; unsigned int q = 3393U; add(&p, &q); return 0; }
case 44: { unsigned int p = 665U; unsigned int q = 3124U; add(&p, &q); return 0; }
case 45: { unsigned int p = 737U; unsigned int q = 2690U; add(&p, &q); return 0; }
case 46: { unsigned int p = 800U; unsigned int q = 9U; add(&p, &q); return 0; }
case 47: { unsigned int p = 800U; unsigned int q = 401U; add(&p, &q); return 0; }
case 48: { unsigned int p = 800U; unsigned int q = 2000U; add(&p, &q); return 0; }
case 49: { unsigned int p = 845U; unsigned int q = 3360U; add(&p, &q); return 0; }
case 50: { unsigned int p = 969U; unsigned int q = 3667U; add(&p, &q); return 0; }
case 51: { unsigned int p = 982U; unsigned int q = 2550U; add(&p, &q); return 0; }
case 52: { unsigned int p = 994U; unsigned int q = 2046U; add(&p, &q); return 0; }
case 53: { unsigned int p = 1017U; unsigned int q = 2686U; add(&p, &q); return 0; }
case 54: { unsigned int p = 1379U; unsigned int q = 2993U; add(&p, &q); return 0; }
case 55: { unsigned int p = 1477U; unsigned int q = 2666U; add(&p, &q); return 0; }
case 56: { unsigned int p = 1570U; unsigned int q = 3773U; add(&p, &q); return 0; }
case 57: { unsigned int p = 1600U; unsigned int q = 1U; add(&p, &q); return 0; }
case 58: { unsigned int p = 1600U; unsigned int q = 100U; add(&p, &q); return 0; }
case 59: { unsigned int p = 1600U; unsigned int q = 800U; add(&p, &q); return 0; }
case 60: { unsigned int p = 1600U; unsigned int q = 2100U; add(&p, &q); return 0; }
case 61: { unsigned int p = 1645U; unsigned int q = 3701U; add(&p, &q); return 0; }
case 62: { unsigned int p = 1810U; unsigned int q = 2962U; add(&p, &q); return 0; }
case 63: { unsigned int p = 1812U; unsigned int q = 855U; add(&p, &q); return 0; }
case 64: { unsigned int p = 1900U; unsigned int q = 4U; add(&p, &q); return 0; }
case 65: { unsigned int p = 1900U; unsigned int q = 399U; add(&p, &q); return 0; }
case 66: { unsigned int p = 1900U; unsigned int q = 1900U; add(&p, &q); return 0; }
case 67: { unsigned int p = 1928U; unsigned int q = 839U; add(&p, &q); return 0; }
case 68: { unsigned int p = 1991U; unsigned int q = 513U; add(&p, &q); return 0; }
case 69: { unsigned int p = 2000U; unsigned int q = 0U; add(&p, &q); return 0; }
case 70: { unsigned int p = 2000U; unsigned int q = 9U; add(&p, &q); return 0; }
case 71: { unsigned int p = 2000U; unsigned int q = 401U; add(&p, &q); return 0; }
case 72: { unsigned int p = 2000U; unsigned int q = 2004U; add(&p, &q); return 0; }
case 73: { unsigned int p = 2004U; unsigned int q = 1U; add(&p, &q); return 0; }
case 74: { unsigned int p = 2004U; unsigned int q = 100U; add(&p, &q); return 0; }
case 75: { unsigned int p = 2004U; unsigned int q = 1600U; add(&p, &q); return 0; }
case 76: { unsigned int p = 2004U; unsigned int q = 2100U; add(&p, &q); return 0; }
case 77: { unsigned int p = 2019U; unsigned int q = 3697U; add(&p, &q); return 0; }
case 78: { unsigned int p = 2039U; unsigned int q = 2380U; add(&p, &q); return 0; }
case 79: { unsigned int p = 2100U; unsigned int q = 4U; add(&p, &q); return 0; }
case 80: { unsigned int p = 2100U; unsigned int q = 400U; add(&p, &q); return 0; }
case 81: { unsigned int p = 2100U; unsigned int q = 1900U; add(&p, &q); return 0; }
case 82: { unsigned int p = 2328U; unsigned int q = 321U; add(&p, &q); return 0; }
case 83: { unsigned int p = 2400U; unsigned int q = 0U; add(&p, &q); return 0; }
case 84: { unsigned int p = 2400U; unsigned int q = 10U; add(&p, &q); return 0; }
case 85: { unsigned int p = 2400U; unsigned int q = 401U; add(&p, &q); return 0; }
case 86: { unsigned int p = 2400U; unsigned int q = 2004U; add(&p, &q); return 0; }
case 87: { unsigned int p = 2506U; unsigned int q = 84U; add(&p, &q); return 0; }
case 88: { unsigned int p = 2624U; unsigned int q = 2713U; add(&p, &q); return 0; }
case 89: { unsigned int p = 2636U; unsigned int q = 237U; add(&p, &q); return 0; }
case 90: { unsigned int p = 2685U; unsigned int q = 1610U; add(&p, &q); return 0; }
case 91: { unsigned int p = 2970U; unsigned int q = 2611U; add(&p, &q); return 0; }
case 92: { unsigned int p = 3067U; unsigned int q = 1614U; add(&p, &q); return 0; }
case 93: { unsigned int p = 3089U; unsigned int q = 1355U; add(&p, &q); return 0; }
case 94: { unsigned int p = 3108U; unsigned int q = 458U; add(&p, &q); return 0; }
case 95: { unsigned int p = 3296U; unsigned int q = 3921U; add(&p, &q); return 0; }
case 96: { unsigned int p = 3304U; unsigned int q = 1185U; add(&p, &q); return 0; }
case 97: { unsigned int p = 3399U; unsigned int q = 437U; add(&p, &q); return 0; }
case 98: { unsigned int p = 3478U; unsigned int q = 4057U; add(&p, &q); return 0; }
case 99: { unsigned int p = 3596U; unsigned int q = 462U; add(&p, &q); return 0; }
case 100: { unsigned int p = 3607U; unsigned int q = 3262U; add(&p, &q); return 0; }
case 101: { unsigned int p = 3640U; unsigned int q = 1387U; add(&p, &q); return 0; }
case 102: { unsigned int p = 3713U; unsigned int q = 2675U; add(&p, &q); return 0; }
case 103: { unsigned int p = 3744U; unsigned int q = 2344U; add(&p, &q); return 0; }
case 104: { unsigned int p = 3864U; unsigned int q = 3698U; add(&p, &q); return 0; }
case 105: { unsigned int p = 3873U; unsigned int q = 992U; add(&p, &q); return 0; }
case 106: { unsigned int p = 3890U; unsigned int q = 3893U; add(&p, &q); return 0; }
case 107: { unsigned int p = 3934U; unsigned int q = 4034U; add(&p, &q); return 0; }
case 108: { unsigned int p = 3963U; unsigned int q = 3137U; add(&p, &q); return 0; }
case 109: { unsigned int p = 62067097U; unsigned int q = 1578327848U; add(&p, &q); return 0; }
case 110: { unsigned int p = 96861293U; unsigned int q = 2262043041U; add(&p, &q); return 0; }
case 111: { unsigned int p = 196708748U; unsigned int q = 162658236U; add(&p, &q); return 0; }
case 112: { unsigned int p = 213638651U; unsigned int q = 989409410U; add(&p, &q); return 0; }
case 113: { unsigned int p = 657551918U; unsigned int q = 2908295958U; add(&p, &q); return 0; }
case 114: { unsigned int p = 701188854U; unsigned int q = 1078201182U; add(&p, &q); return 0; }
case 115: { unsigned int p = 893143590U; unsigned int q = 3381619671U; add(&p, &q); return 0; }
case 116: { unsigned int p = 964704780U; unsigned int q = 2532392796U; add(&p, &q); return 0; }
case 117: { unsigned int p = 994133217U; unsigned int q = 305202158U; add(&p, &q); return 0; }
case 118: { unsigned int p = 1204031168U; unsigned int q = 1675404779U; add(&p, &q); return 0; }
case 119: { unsigned int p = 1265127161U; unsigned int q = 2370890204U; add(&p, &q); return 0; }
case 120: { unsigned int p = 1493919223U; unsigned int q = 1671392672U; add(&p, &q); return 0; }
case 121: { unsigned int p = 1641327526U; unsigned int q = 2274570162U; add(&p, &q); return 0; }
case 122: { unsigned int p = 1852041741U; unsigned int q = 1698833487U; add(&p, &q); return 0; }
case 123: { unsigned int p = 2147483647U; unsigned int q = 2147483648U; add(&p, &q); return 0; }
case 124: { unsigned int p = 2270574764U; unsigned int q = 1807122473U; add(&p, &q); return 0; }
case 125: { unsigned int p = 2521543424U; unsigned int q = 1484522380U; add(&p, &q); return 0; }
case 126: { unsigned int p = 2742086419U; unsigned int q = 841290264U; add(&p, &q); return 0; }
case 127: { unsigned int p = 4294967295U; unsigned int q = 0U; add(&p, &q); return 0; }
default: return 13; } }
